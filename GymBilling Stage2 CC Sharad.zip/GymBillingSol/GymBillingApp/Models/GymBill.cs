﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GymBillingApp.Models
{
    public enum Gender { Select, Male, Female, Others }    
    public enum PaymentMode { Select, CreditCard, DebitCard, UPI };
    public enum HoursPerMonth { Select, Beginner15, Regular30, BodyBuilder45 };

    public class GymBill
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }
        [Required]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfJoin field is required.")]
        [Display(Name = "Date Of Joining")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfJoin { get; set; }

        [Required(ErrorMessage = "The PaymentMode field is required.")]
        [Display(Name = "Payment Mode")]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public PaymentMode PaymentMode { get; set; }

        public bool Bike { get; set; }
        public bool Rowing { get; set; }
        public bool Treadmill { get; set; }
        public bool Tampoline { get; set; }
        public bool Stepper { get; set; }
        public bool Dumbles { get; set; }

        [Required]
        [Display(Name = "Hours/Month")]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public HoursPerMonth HoursPerMonth { get; set; }

        [Display(Name = "Bill Amount")]
        public int BillAmount { get; set; }

        public void CalculateBill()
        {
            BillAmount = 0;

            int monthlyServices = 0;
            if (Bike == true) monthlyServices += 250;
            if (Rowing == true) monthlyServices += 150;
            if (Treadmill == true) monthlyServices += 650;
            if (Tampoline == true) monthlyServices += 300;
            if (Stepper == true) monthlyServices += 200;
            if (Dumbles == true) monthlyServices += 200;

            BillAmount += monthlyServices + 500 + (int)HoursPerMonth * 1500;
         
            int gst = (int)(BillAmount * 18.0 / 100);
            BillAmount += gst;
        }      
    }
}

