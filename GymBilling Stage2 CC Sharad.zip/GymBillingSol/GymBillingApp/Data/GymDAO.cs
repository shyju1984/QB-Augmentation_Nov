﻿using GymBillingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymBillingApp.Data
{
    public class GymDAO
    {
        public static List<GymBill> Bills = null;

        public GymDAO()
        {
            Bills = new List<GymBill>
            {
                new GymBill{  Name ="Anubhav", Mobile = "7766889955", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,10,11 ),
                                         HoursPerMonth  = HoursPerMonth.Beginner15, PaymentMode = PaymentMode.CreditCard,
                                             Bike=true, Dumbles=true, Rowing=true,
                                                Stepper=false, Tampoline=false, Treadmill=true, BillAmount=3835
                            },
                new GymBill{  Name ="Suresh", Mobile = "7687987665", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,09,05 ),
                                         HoursPerMonth  = HoursPerMonth.BodyBuilder45, PaymentMode = PaymentMode.CreditCard,
                                             Bike=true, Dumbles=true, Rowing=true,
                                                Stepper=true, Tampoline=false, Treadmill=true, BillAmount=7611
                            },
                new GymBill{  Name ="Manisha", Mobile = "9758674859", Gender =  Gender.Female, DateOfJoin=new DateTime(2020,10,05 ),
                                         HoursPerMonth  = HoursPerMonth.Regular30, PaymentMode = PaymentMode.CreditCard,
                                             Bike=true, Dumbles=true, Rowing=true,
                                                Stepper=false, Tampoline=true, Treadmill=true, BillAmount=5959
                            }
            };
        }

        public List<GymBill> GetData()
        {
            return Bills;
        }

        public void AddData(GymBill gymBill)
        {
            Bills.Add(gymBill);
        }
    }
}