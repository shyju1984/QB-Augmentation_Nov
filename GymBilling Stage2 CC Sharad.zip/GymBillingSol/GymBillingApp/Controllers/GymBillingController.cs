﻿using GymBillingApp.Data;
using GymBillingApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GymBillingApp.Controllers
{
    public class GymBillingController : Controller
    {
        static GymDAO dao = new GymDAO();
        public ActionResult Index()
        {
            var data = dao.GetData().OrderBy(b=>b.Name).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(GymBill gymBill)
        {
            if (ModelState.IsValid)
            {
                gymBill.CalculateBill();
                dao.AddData(gymBill);
                return RedirectToAction("Index");
            }
            else
                return View();
        }
    }
}