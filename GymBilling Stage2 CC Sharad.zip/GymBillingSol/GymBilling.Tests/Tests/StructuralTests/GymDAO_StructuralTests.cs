﻿using NUnit.Framework;
using GymBillingApp.Models;
using GymBilling.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymBilling.Tests.StructuralTests
{
    [Order(4), TestFixture("GymBillingApp", "GymBillingApp.Data", "GymDAO")]
    class GymDAO_StructuralTests : TestBase
    {
        public GymDAO_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {

        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("Bills", "List`1");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "Bills", fieldType: "List<Gym>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "Bills"));
            }
        }

        [Test]
        public void AddGymDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddData", new Type[] { typeof(GymBill) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddData() which accepts Gym entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void GetGymDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("GetData", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines GetData() which accepts no parameter");
                Assert.AreEqual(Method.ReturnType, typeof(List<GymBill>), "Return type is not as expected");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check GetGymData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

    }
}
