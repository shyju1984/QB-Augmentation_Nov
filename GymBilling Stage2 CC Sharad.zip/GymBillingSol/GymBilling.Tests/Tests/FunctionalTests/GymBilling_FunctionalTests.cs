﻿using NUnit.Framework;
using GymBillingApp.Models;
using GymBilling.Tests.TestExtensions;
using System;
using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using GymBillingApp.Data;
using GymBillingApp.Controllers;
using System.Collections.Specialized;
using System.Globalization;
using System.Web.Mvc;

namespace CarMileage.Tests.Tests.FunctionalTests
{
    [TestFixture]
    class GymBillingController_FunctionalTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("GymBillingApp");
            className = assembly.GetType("GymBillingApp.Controllers.GymBillingController");
            modelClassName = assembly.GetType("GymBillingApp.Models.GymBill");
            dbContextclassName = assembly.GetType("GymBillingApp.Data.GymDAO");
        }

        [Test]

        [TestCase(HoursPerMonth.Beginner15, true, true, true, false, false, true, 3835)]
        [TestCase(HoursPerMonth.Regular30, true, true, true, false, false, true, 5605)]
        [TestCase(HoursPerMonth.BodyBuilder45, true, true, true, false, false, true, 7375)]
        [TestCase(HoursPerMonth.Beginner15, true, true, true, false, false, false, 3068)]
        [TestCase(HoursPerMonth.Regular30, true, true, true, false, false, false, 4838)]
        [TestCase(HoursPerMonth.BodyBuilder45, true, true, true, false, false, false, 6608)]
        [TestCase(HoursPerMonth.Beginner15, false, false, false, false, false, true, 3127)]
        [TestCase(HoursPerMonth.Regular30, false, false, false, false, false, true, 4897)]
        [TestCase(HoursPerMonth.BodyBuilder45, false, false, false, false, false, true, 6667)]
        [TestCase(HoursPerMonth.Beginner15, false, false, false, false, false, false, 2360)]
        [TestCase(HoursPerMonth.Regular30, false, false, false, false, false, false, 4130)]        
        [TestCase(HoursPerMonth.BodyBuilder45, false, false, false, false, false, false, 5900)]

        [Order(1)]
        public void GymBill_CalculateBill_ShouldCalculateCorrectValue(HoursPerMonth hpm, 
                                                bool bike, bool dumbles, bool rowing,
                                                bool stepper, bool tampoline, bool treadmill, int gymBill)
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = modelClassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("CalculateBill"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'CalculateBill' NOT implemented OR check spelling");

                    GymBill bill = new GymBill
                    {
                        Name = "Anubhav",
                        Mobile = "7766889955",
                        Gender = Gender.Male,
                        DateOfJoin = new DateTime(2020, 10, 11),
                        HoursPerMonth = hpm,
                        PaymentMode = PaymentMode.CreditCard,                
                        Bike = bike,
                        Dumbles = dumbles,
                        Rowing = rowing,
                        Stepper = stepper,
                        Tampoline = tampoline,
                        Treadmill = treadmill,
                        BillAmount = 0
                    };

                    object[] parameters = new object[] { };
                    testMethod.Invoke(bill, parameters);

                    Assert.AreEqual(gymBill, bill.BillAmount);
                }
                else
                    Assert.Fail("No class with the name 'GymDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("CalculateBill not returning correct value");
            }
        }


        [Test]
        [Order(2)]
        public void DAO_GetData_ShouldGetData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            GymDAO dao = new GymDAO();

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddMileageData' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;
                    int user1Count = dao.GetData().Where(u => u.Name == "Anubhav").Count();
                    int user2Count = dao.GetData().Where(u => u.Name == "Manisha").Count();

                    Assert.AreEqual(countAfter, 3);
                    Assert.AreEqual(user1Count, 1);
                    Assert.AreEqual(user2Count, 1);
                }
                else
                    Assert.Fail("No class with the name 'GymDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Getting GymBill data from collection failed. Is original data available?");
            }
        }

        [Test]
        [Order(3)]
        public void DAO_AddData_ShouldAddData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            GymDAO dao = new GymDAO();
            GymBill bill = new GymBill
            {
                Name = "AAAA",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                HoursPerMonth = HoursPerMonth.Regular30,
                PaymentMode = PaymentMode.CreditCard,        
                Bike = true,
                Dumbles = true,
                Rowing = false,
                Stepper = false,
                Tampoline = true,
                Treadmill = false,
                BillAmount = 0
            };
            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("AddData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddData' NOT implemented OR check spelling");

                    int countBefore = dao.GetData().Count;
                    object[] parameters = new object[] { bill };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;

                    Assert.AreEqual(countAfter, countBefore + 1);
                }
                else
                    Assert.Fail("No class with the name 'GymDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data to the collection failed.");
            }
        }


        ////----------------------------- Check GymBillingController -------------------------------------------

        [Test]
        [Order(4)]
        public void IndexAction_When_Invoked_Return_SortedList()
        {
            //Arrange 
            GymDAO dao = new GymDAO();
            GymDAO.Bills.Clear();
            GymBill bill1 = new GymBill
            {
                Name = "AAAA",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                HoursPerMonth = HoursPerMonth.Regular30,
                PaymentMode = PaymentMode.CreditCard,     
                Bike = true,
                Dumbles = true,
                Rowing = false,
                Stepper = false,
                Tampoline = true,
                Treadmill = false,
                BillAmount = 0
            };
            GymBill bill2 = new GymBill
            {
                Name = "CCCC",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                HoursPerMonth = HoursPerMonth.Regular30,
                PaymentMode = PaymentMode.CreditCard,                
                Bike = true,
                Dumbles = true,
                Rowing = false,
                Stepper = false,
                Tampoline = true,
                Treadmill = false,
                BillAmount = 0
            };
            GymBill bill3 = new GymBill
            {
                Name = "BBBB",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                HoursPerMonth = HoursPerMonth.Regular30,
                PaymentMode = PaymentMode.CreditCard,                
                Bike = true,
                Dumbles = true,
                Rowing = false,
                Stepper = false,
                Tampoline = true,
                Treadmill = false,
                BillAmount = 0
            };
            GymDAO.Bills.Add(bill1);
            GymDAO.Bills.Add(bill2);
            GymDAO.Bills.Add(bill3);

            try
            {
                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var list = (IEnumerable<GymBill>)viewResult.ViewData.Model;

                    Assert.AreEqual(3, list.Count(),
                        "Verify whether you fetched the data from the collection correctly or not");

                    //to test list is sorted
                    var dataList = dao.GetData().OrderBy(b => b.Name).ToList();

                    bool isSorted = dataList.SequenceEqual(list);
                    Assert.That(isSorted, "List should be sorted properly");
                }
                else
                    Assert.Fail("No class with the name 'GymBillingController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        [Order(5)]
        public void CreateBill_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var gymBillingController = new GymBillingController();
            GymDAO db = new GymDAO();

            GymBill bill = new GymBill
            {
                Name = "DDDD",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                HoursPerMonth = HoursPerMonth.Regular30,
                PaymentMode = PaymentMode.CreditCard,                
                Bike = true,
                Dumbles = true,
                Rowing = false,
                Stepper = false,
                Tampoline = true,
                Treadmill = false,
                BillAmount = 0
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => bill, bill.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("GymBillingApp.Controllers.GymBillingController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("Create")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'GymBillingController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data failed. verify the state of model object");
            }
        }



    }

}
