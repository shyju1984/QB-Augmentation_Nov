﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GymBillingApp.Models
{
    public enum Gender { Select, Male, Female, Others }    
    public enum PaymentMode { Select, CreditCard, DebitCard, UPI };
    public enum HoursPerMonth { Select, Beginner15, Regular30, BodyBuilder45 };

    public class GymBill
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }

        [Required]
        /*implement Range attribute*/

        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfJoin field is required.")]
        [Display(Name = "Date Of Joining")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfJoin { get; set; }

        [Required(ErrorMessage = "The PaymentMode field is required.")]
        [Display(Name = "Payment Mode")]
        /*implement Range attribute*/

        public PaymentMode PaymentMode { get; set; }

        public bool Bike { get; set; }
        public bool Rowing { get; set; }
        public bool Treadmill { get; set; }
        public bool Tampoline { get; set; }
        public bool Stepper { get; set; }
        public bool Dumbles { get; set; }

        [Required]
        [Display(Name = "Hours/Month")]
        /*implement Range attribute*/

        public HoursPerMonth HoursPerMonth { get; set; }

        [Display(Name = "Bill Amount")]
        public int BillAmount { get; set; }

        public void CalculateBill()
        {
           //Implement your code
        }      
    }
}

