﻿using GymBillingApp.Data;
using GymBillingApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GymBillingApp.Controllers
{
    public class GymBillingController : Controller
    {
        static GymDAO dao = new GymDAO();
        public ActionResult Index()
        {
            //Implement your code
            return View();
        }

        public ActionResult Create()
        {
            //Implement your code
            return View();
        }

        //Implement your code and Action Method
    }
}