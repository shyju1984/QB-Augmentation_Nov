﻿using NUnit.Framework;
using DTHBilling.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTHBillingApp.Models;

namespace DTHBilling.Tests.StructuralTests
{
    [Order(4), TestFixture("DTHBillingApp", "DTHBillingApp.Data", "DTHDAO")]
    class DTHDAO_StructuralTests : TestBase
    {
        public DTHDAO_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {

        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("Bills", "List`1");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "Bills", fieldType: "List<DTHBill>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "Bills"));
            }
        }

        [Test]
        public void AddDTHDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddData", new Type[] { typeof(DTHBill) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddData() which accepts DTHBill entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void GetDTHDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("GetData", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines GetData() which accepts no parameter");
                Assert.AreEqual(Method.ReturnType, typeof(List<DTHBill>), "Return type is not as expected");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check GetDTHData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

    }
}
