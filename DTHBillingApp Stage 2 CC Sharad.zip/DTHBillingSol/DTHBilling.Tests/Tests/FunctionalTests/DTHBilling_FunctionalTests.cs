﻿using NUnit.Framework;
using DTHBillingApp.Models;
using DTHBilling.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using DTHBillingApp.Data;
using DTHBillingApp.Controllers;
using System.Collections.Specialized;
using System.Globalization;
using System.Web.Mvc;

namespace DTHBilling.Tests.FunctionalTests
{
    [TestFixture]
    class DTHBillingController_FunctionalTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("DTHBillingApp");
            className = assembly.GetType("DTHBillingApp.Controllers.DTHBillingController");
            modelClassName = assembly.GetType("DTHBillingApp.Models.DTHBill");
            dbContextclassName = assembly.GetType("DTHBillingApp.Data.DTHDAO");
        }

        [Test]

        [TestCase(DTHPlans.FamilyKidsSports, true, true, true, true, true, true, 1528)]
        [TestCase(DTHPlans.FamilyKidsSports, true, true, true, true, false, true, 1480)]
        [TestCase(DTHPlans.FamilyKidsSports, false, true, true, true, false, true, 1421)]
        [TestCase(DTHPlans.FamilyKidsSports, false, true, true, false, false, true, 1339)]
        [TestCase(DTHPlans.FamilyKidsSports, false, false, true, false, false, true, 1244)]
        [TestCase(DTHPlans.FamilyKidsSports, false, false, false, false, false, true, 1174)]
        [TestCase(DTHPlans.FamilyKidsSports, false, false, false, false, false, false, 1138)]
        [TestCase(DTHPlans.FamilyKids, true, true, true, true, true, true, 1411)]
        [TestCase(DTHPlans.FamilyKids, true, true, true, true, false, true, 1364)]
        [TestCase(DTHPlans.FamilyKids, false, true, true, true, false, true, 1305)]
        [TestCase(DTHPlans.FamilyKids, false, true, true, false, false, true, 1222)]
        [TestCase(DTHPlans.FamilyKids, false, false, true, false, false, true, 1128)]
        [TestCase(DTHPlans.FamilyKids, false, false, false, false, false, true, 1057)]
        [TestCase(DTHPlans.FamilyKids, false, false, false, false, false, false, 1021)]
        [TestCase(DTHPlans.FamilySports, true, true, true, true, true, true, 1517)]
        [TestCase(DTHPlans.FamilySports, true, true, true, true, false, true, 1470)]
        [TestCase(DTHPlans.FamilySports, false, true, true, true, false, true, 1411)]
        [TestCase(DTHPlans.FamilySports, false, true, true, false, false, true, 1328)]
        [TestCase(DTHPlans.FamilySports, false, false, true, false, false, true, 1234)]
        [TestCase(DTHPlans.FamilySports, false, false, false, false, false, true, 1163)]
        [TestCase(DTHPlans.FamilySports, false, false, false, false, false, false, 1128)]
        [TestCase(DTHPlans.Basic, true, true, true, true, true, true, 1373)]
        [TestCase(DTHPlans.Basic, true, true, true, true, false, true, 1326)]
        [TestCase(DTHPlans.Basic, false, true, true, true, false, true, 1267)]
        [TestCase(DTHPlans.Basic, false, true, true, false, false, true, 1184)]
        [TestCase(DTHPlans.Basic, false, false, true, false, false, true, 1090)]
        [TestCase(DTHPlans.Basic, false, false, false, false, false, true, 1019)]
        [TestCase(DTHPlans.Basic, false, false, false, false, false, false, 984)]

        [Order(1)]
        public void DTHBill_CalculateBill_ShouldCalculateCorrectValue(DTHPlans plan,
                                                bool music, bool lifestyle, bool knowledge,
                                                bool movies, bool news, bool cricket, int dthBill)
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = modelClassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("CalculateBill"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'CalculateBill' NOT implemented OR check spelling");

                    DTHBill bill = new DTHBill
                    {
                        Name = "Anubhav",
                        Mobile = "7766889955",
                        Gender = Gender.Male,
                        DateOfJoin = new DateTime(2020, 10, 11),
                        DTHPlans = plan,                        
                        Music = music,
                        LifeStyle = lifestyle,
                        Knowledge = knowledge,
                        Movies = movies,
                        News = news,
                        Cricket = cricket,
                        BillAmount = 0
                    };

                    object[] parameters = new object[] { };
                    testMethod.Invoke(bill, parameters);

                    Assert.AreEqual(dthBill, bill.BillAmount);
                }
                else
                    Assert.Fail("No class with the name 'DTHDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("CalculateBill not returning correct value");
            }
        }


        [Test]
        [Order(2)]
        public void DAO_GetData_ShouldGetData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            DTHDAO dao = new DTHDAO();

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddMileageData' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;
                    int user1Count = dao.GetData().Where(u => u.Name == "Anubhav").Count();
                    int user2Count = dao.GetData().Where(u => u.Name == "Manisha").Count();

                    Assert.AreEqual(countAfter, 3);
                    Assert.AreEqual(user1Count, 1);
                    Assert.AreEqual(user2Count, 1);
                }
                else
                    Assert.Fail("No class with the name 'DTHDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Getting DTHBill data from collection failed. Is original data available?");
            }
        }

        [Test]
        [Order(3)]
        public void DAO_AddData_ShouldAddData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            DTHDAO dao = new DTHDAO();
            DTHBill bill = new DTHBill
            {
                Name = "AAA",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                DTHPlans = DTHPlans.FamilyKidsSports,
                Music = true,
                LifeStyle = false,
                Knowledge = true,
                Movies = false,
                News = true,
                Cricket = false,
                BillAmount = 0
            };
            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("AddData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddData' NOT implemented OR check spelling");

                    int countBefore = dao.GetData().Count;
                    object[] parameters = new object[] { bill };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;

                    Assert.AreEqual(countAfter, countBefore + 1);
                }
                else
                    Assert.Fail("No class with the name 'DTHDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data to the collection failed.");
            }
        }


        ////----------------------------- Check DTHBillingController -------------------------------------------

        [Test]
        [Order(4)]
        public void IndexAction_When_Invoked_Return_SortedList()
        {
            //Arrange 
            DTHDAO dao = new DTHDAO();
            DTHDAO.Bills.Clear();
            DTHBill bill1 = new DTHBill
            {
                Name = "AAA",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                DTHPlans = DTHPlans.FamilyKidsSports,
                Music = true,
                LifeStyle = false,
                Knowledge = true,
                Movies = false,
                News = true,
                Cricket = false,
                BillAmount = 0
            };
            DTHBill bill2 = new DTHBill
            {
                Name = "CCC",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                DTHPlans = DTHPlans.FamilyKidsSports,
                Music = true,
                LifeStyle = false,
                Knowledge = true,
                Movies = false,
                News = true,
                Cricket = false,
                BillAmount = 0
            };
            DTHBill bill3 = new DTHBill
            {
                Name = "BBB",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                DTHPlans = DTHPlans.FamilyKidsSports,
                Music = true,
                LifeStyle = false,
                Knowledge = true,
                Movies = false,
                News = true,
                Cricket = false,
                BillAmount = 0
            };
            DTHDAO.Bills.Add(bill1);
            DTHDAO.Bills.Add(bill2);
            DTHDAO.Bills.Add(bill3);

            try
            {
                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var list = (IEnumerable<DTHBill>)viewResult.ViewData.Model;

                    Assert.AreEqual(3, list.Count(),
                        "Verify whether you fetched the data from the collection correctly or not");

                    //to test list is sorted
                    var dataList = dao.GetData().OrderBy(b => b.Name).ToList();

                    bool isSorted = dataList.SequenceEqual(list);
                    Assert.That(isSorted, "List should be sorted properly");
                }
                else
                    Assert.Fail("No class with the name 'DTHBillingController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        [Order(5)]
        public void CreateBill_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var gymBillingController = new DTHBillingController();
            DTHDAO db = new DTHDAO();

            DTHBill bill = new DTHBill
            {
                Name = "DDD",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                DTHPlans = DTHPlans.FamilyKidsSports,
                Music = true,
                LifeStyle = false,
                Knowledge = true,
                Movies = false,
                News = true,
                Cricket = false,
                BillAmount = 0
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => bill, bill.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("DTHBillingApp.Controllers.DTHBillingController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("Create")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'DTHBillingController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data failed. verify the state of model object");
            }
        }
    }
}
