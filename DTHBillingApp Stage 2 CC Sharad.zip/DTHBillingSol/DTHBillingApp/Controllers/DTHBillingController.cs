﻿using DTHBillingApp.Data;
using DTHBillingApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DTHBillingApp.Controllers
{
    public class DTHBillingController : Controller
    {        
        static DTHDAO dao = new DTHDAO();
        public ActionResult Index()
        {
            var data = dao.GetData().OrderBy(b=>b.Name).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(DTHBill dthBill)
        {
            if (ModelState.IsValid)
            {
                dthBill.CalculateBill();
                dao.AddData(dthBill);
                return RedirectToAction("Index");
            }
            else
                return View();
        }
    }
}