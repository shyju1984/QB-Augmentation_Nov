﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DTHBillingApp.Models
{
    public enum Gender { Select, Male, Female, Others }    
    public enum DTHPlans { Select, Basic, FamilyKids, FamilySports, FamilyKidsSports };

    public class DTHBill
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }
        [Required]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfJoin field is required.")]
        [Display(Name = "Date Of Joining")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfJoin { get; set; }

        //Add-On packs

        public bool Music { get; set; }
        public bool LifeStyle { get; set; }
        public bool Knowledge { get; set; }
        public bool Movies { get; set; }
        public bool News { get; set; }
        public bool Cricket { get; set; }

        [Required]
        [Display(Name = "DTH Plan")]
        [Range(1, 4, ErrorMessage = "Must be selected")]
        public DTHPlans DTHPlans { get; set; }

        [Display(Name = "Bill Amount")]
        public int BillAmount { get; set; }

        public void CalculateBill()
        {
            //Implement your code
        }
    }
}

