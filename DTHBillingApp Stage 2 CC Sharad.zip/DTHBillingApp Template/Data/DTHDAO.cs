﻿using DTHBillingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DTHBillingApp.Data
{
    public class DTHDAO
    {
        public static List<DTHBill> Bills = null;       

        public DTHDAO()
        {
            Bills = new List<DTHBill>
            {
                new DTHBill{  Name ="Anubhav", Mobile = "7766889955", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,10,11),
                                         DTHPlans  = DTHPlans.FamilyKids,
                                          Cricket = true, Knowledge=true, LifeStyle=true,
                                             Movies=true, Music=true, News=true, BillAmount=1411
                            },
                new DTHBill{  Name ="Suresh", Mobile = "7687987665", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,09,05),
                                         DTHPlans  = DTHPlans.FamilyKidsSports,
                                             Cricket = true, Knowledge=true, LifeStyle=true,
                                             Movies=false, Music=false, News=false, BillAmount=1339
                            },
                new DTHBill{  Name ="Manisha", Mobile = "9758674859", Gender =  Gender.Female, DateOfJoin=new DateTime(2020,10,05),
                                         DTHPlans  = DTHPlans.Basic,
                                             Cricket = false, Knowledge=false, LifeStyle=false,
                                             Movies=true, Music=true, News=true, BillAmount=1172
                            }
            };
        }

        public List<DTHBill> GetData()
        {
            return Bills;
        }

        public void AddData(DTHBill dthBill)
        {

            Bills.Add(dthBill);
        }
    }
}