﻿using DTHBillingApp.Data;
using DTHBillingApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DTHBillingApp.Controllers
{
    public class DTHBillingController : Controller
    {        
        static DTHDAO dao = new DTHDAO();

        //Implement your methods 
    }
}