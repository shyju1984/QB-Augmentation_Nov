﻿using CinemaTicketApp.Data;
using CinemaTicketApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CinemaTicketApp.Controllers
{
    public class CinemaTicketController : Controller
    {
        static TicketDAO dao = new TicketDAO();
        public ActionResult Index()
        {
            var data = dao.GetData().OrderBy(b => b.Name).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(CinemaTicket cinemaTicket)
        {
            if (ModelState.IsValid)
            {
                cinemaTicket.CalculateTicket();
                dao.AddData(cinemaTicket);
                return RedirectToAction("Index");
            }
            else
                return View();
        }

    }
}
