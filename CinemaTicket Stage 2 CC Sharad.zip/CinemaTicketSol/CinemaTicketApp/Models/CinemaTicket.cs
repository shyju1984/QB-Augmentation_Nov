﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CinemaTicketApp.Models
{
    public enum Gender { Select, Male, Female, Others }
    public enum TicketPlans { Select, Classic, Gold, Platinum, VIP };

    public class CinemaTicket
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }
        [Required]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfTicket field is required.")]
        [Display(Name = "Date Of Ticket")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfTicket { get; set; }

        //Services 
        public bool PopCorn { get; set; }
        public bool ColdDrink { get; set; }
        public bool Burger { get; set; }
        public bool Nachos { get; set; }
        public bool Coffee { get; set; }
        public bool Sandwich { get; set; }        

        [Required]
        [Display(Name = "Ticket Plan")]
        [Range(1, 4, ErrorMessage = "Must be selected")]
        public TicketPlans TicketPlans { get; set; }

        [Display(Name = "Ticket Amount")]
        public int TicketAmount { get; set; }

        public void CalculateTicket()
        {
            TicketAmount = 0;

            int services = 0;

            if (PopCorn == true) services += 180;
            if (ColdDrink == true) services += 200;            
            if (Burger == true) services += 250;            
            if (Nachos == true) services += 150;
            if (Coffee == true) services += 200;
            if (Sandwich == true) services += 170;                   

            //Corona Surplus
            TicketAmount += services + 100;

            int TicketCost = 0;
            switch ((int)TicketPlans)
            {
                case 1:
                    TicketCost = 250;
                    break;
                case 2:
                    TicketCost = 350;
                    break;
                case 3:
                    TicketCost = 450;
                    break;
                case 4:
                    TicketCost = 550;
                    break;
            }
            TicketAmount += TicketCost;

            int gst = (int)(TicketAmount * 18.0 / 100);
            TicketAmount += gst;
        }
    }
}

