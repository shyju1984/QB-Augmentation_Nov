﻿using CinemaTicketApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CinemaTicketApp.Data
{
    public class TicketDAO
    {
        public static List<CinemaTicket> Tickets = null;
        
        public TicketDAO()
        {
            Tickets = new List<CinemaTicket>
            {
                new CinemaTicket{  Name ="Monika", Mobile = "7766889955", Gender =  Gender.Female, DateOfTicket=new DateTime(2020,10,11),
                                         TicketPlans  = TicketPlans.Classic,
                                          PopCorn = true, ColdDrink=true, Burger=true,
                                             Nachos=true, Coffee=true, Sandwich=true, TicketAmount=1770
                            },
                new CinemaTicket{  Name ="Abhishek", Mobile = "7687987665", Gender =  Gender.Male, DateOfTicket=new DateTime(2020,09,05),
                                         TicketPlans  = TicketPlans.Gold,
                                             PopCorn = true, ColdDrink=true, Burger=true,
                                             Nachos=false, Coffee=false, Sandwich=false, TicketAmount=1274
                            },
                new CinemaTicket{  Name ="Sudhakar", Mobile = "9758674859", Gender =  Gender.Male, DateOfTicket=new DateTime(2020,10,05),
                                         TicketPlans  = TicketPlans.VIP,
                                             PopCorn = false, ColdDrink=false, Burger=false,
                                             Nachos=true, Coffee=true, Sandwich=true, TicketAmount=1380
                            }
            };
        }

        public List<CinemaTicket> GetData()
        {
            return Tickets;
        }

        public void AddData(CinemaTicket cinemaTicket)
        {

            Tickets.Add(cinemaTicket);
        }
    }
}