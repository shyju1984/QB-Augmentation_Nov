﻿using CinemaTicketApp.Data;
using CinemaTicketApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CinemaTicketApp.Controllers
{
    public class CinemaTicketController : Controller
    {
        static TicketDAO dao = new TicketDAO();
        
        //implement action methods

    }
}
