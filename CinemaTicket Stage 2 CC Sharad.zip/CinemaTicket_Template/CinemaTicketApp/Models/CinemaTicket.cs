﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CinemaTicketApp.Models
{
    public enum Gender { Select, Male, Female, Others }
    public enum TicketPlans { Select, Classic, Gold, Platinum, VIP };

    public class CinemaTicket
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }
        [Required]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfTicket field is required.")]
        [Display(Name = "Date Of Ticket")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfTicket { get; set; }

        //Services 
        public bool PopCorn { get; set; }
        public bool ColdDrink { get; set; }
        public bool Burger { get; set; }
        public bool Nachos { get; set; }
        public bool Coffee { get; set; }
        public bool Sandwich { get; set; }        

        [Required]
        [Display(Name = "Ticket Plan")]
        [Range(1, 4, ErrorMessage = "Must be selected")]
        public TicketPlans TicketPlans { get; set; }

        [Display(Name = "Ticket Amount")]
        public int TicketAmount { get; set; }

        public void CalculateTicket()
        {
           //implement your code
        }
    }
}

