﻿using LPGDealersApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

// Do not change the namespace
namespace LPGDealersApp.Controllers
{
    // Do not change the class name
    public class LPGDealersController : Controller
    {
        LPGDealersRepository repository;
        static List<string> DealerCategories = new List<string>
                { "Cooperative", "Rural", "Urban", "WomenQuota", "DefenceQuota", "SportsQuota"};


        public LPGDealersController()
        {
            // Initialize fields here
        }
                
        public ActionResult Add()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Add(LPGDealers dealer)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Search()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Search(SearchDealerViewModel model)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Index()
        {
            // Implement code here 
            return View();
        }

    }
}