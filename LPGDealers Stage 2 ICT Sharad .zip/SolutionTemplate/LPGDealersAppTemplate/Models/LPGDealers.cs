﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace LPGDealersApp.Models
{
    // Do not change the class name
    public class LPGDealers
    {
        // Implement the properties here

    }
}