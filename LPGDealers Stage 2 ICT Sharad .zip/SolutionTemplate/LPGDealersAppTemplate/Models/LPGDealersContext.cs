﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace LPGDealersApp.Models
{
    // Do not change the class name
    public class LPGDealersContext : DbContext
    {
        // Implement the code here
    }
}