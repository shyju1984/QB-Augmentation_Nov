﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace LPGDealersApp.Models
{
    // Do not change the class name
    public class LPGDealersRepository
    {
        // Create fields here

        public LPGDealersRepository()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public bool AddDealer(LPGDealers dealer)
        {
            bool IsAdded = false;

            // Implement code here 

            return IsAdded;
        }

        // Do not change the method signature
        public List<LPGDealers> Search(string city, string travelCategory)
        {
            // Implement code here 
        }

        // Do not change the method signature
        public List<LPGDealers> ListDealers()
        {
            // Implement code here 
        }
    }
}