﻿using LPGDealersApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LPGDealersApp.Controllers
{
    public class LPGDealersController : Controller
    {
        LPGDealersRepository repository;
        static List<string> DealerCategories = new List<string> 
                { "Cooperative", "Rural", "Urban", "WomenQuota", "DefenceQuota", "SportsQuota"};
        public LPGDealersController()
        {
            repository = new LPGDealersRepository();
        }

        public ActionResult Index()
        {            
            var list = repository.ListDealers();
            return View(list);
        }

        public ActionResult Add()
        {        
            ViewBag.DealerCategories = new SelectList(DealerCategories);
            return View();
        }

        [HttpPost]
        public ActionResult Add(LPGDealers dealer)
        {            
            ViewBag.DealerCategories = new SelectList(DealerCategories);

            if (!ModelState.IsValid)
                return View(dealer);
 
            var Added = repository.AddDealer(dealer);
            if (Added)
                ViewBag.Message = "Dealer details added successfully";
            else
                ViewBag.Message = "Failed to add dealer details. Try again later";

            return View(dealer);
        }

        public ActionResult Search()
        {            
            ViewBag.DealerCategories = new SelectList(DealerCategories);
            return View(new SearchDealerViewModel());
        }

        [HttpPost]

        public ActionResult Search(SearchDealerViewModel model)
        {
            ViewBag.DealerCategories = new SelectList(DealerCategories);

            if (!ModelState.IsValid)
                return View(model);

            model.Dealers = repository.Search(model.City, model.DealerCategory);
            return View(model);
        }
    }
}