﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LPGDealersApp.Models
{
    public class LPGDealersRepository
    {
        LPGDealersContext context;

        public LPGDealersRepository()
        {
            context = new LPGDealersContext();
        }

        public bool AddDealer(LPGDealers dealer)
        {
            bool IsAdded = false;

            var isPresent = context.Dealers.SingleOrDefault(d => d.ContactMobileNo == dealer.ContactMobileNo
                                                        && d.City == dealer.City
                                                        && dealer.DealerName == dealer.DealerName);
            if (isPresent != null)
                return IsAdded;

            context.Dealers.Add(dealer);
            IsAdded = context.SaveChanges() > 0;

            return IsAdded;
        }

        public List<LPGDealers> Search(string city, string travelCategory)
        {
            var list = from dealer in context.Dealers
                             where dealer.City.ToLower().Contains(city.ToLower())
                             && dealer.DealerCategory.Equals(travelCategory)
                             select dealer;
            return list.ToList();
        }

        public List<LPGDealers> ListDealers()
        {
            var list = from dealer in context.Dealers
                                   select dealer;
            return list.ToList();
        }
    }
}