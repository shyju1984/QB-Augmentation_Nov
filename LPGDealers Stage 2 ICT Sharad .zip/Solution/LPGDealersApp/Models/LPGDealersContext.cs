﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace LPGDealersApp.Models
{
    public class LPGDealersContext : DbContext
    {
        public LPGDealersContext() : base("LPGDealersConnection")
        {

        }

        public DbSet<LPGDealers> Dealers { get; set; }
    }
}