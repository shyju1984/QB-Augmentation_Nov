﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LPGDealersApp.Models
{
    public class SearchDealerViewModel
    {
        [Required(ErrorMessage = "Please provide city name to search")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")] 
        public string City { get; set; }

        [Required(ErrorMessage = "Please provide dealer category to search")]        
        public string DealerCategory { get; set; }

        public List<LPGDealers> Dealers { get; set; }
    }
}