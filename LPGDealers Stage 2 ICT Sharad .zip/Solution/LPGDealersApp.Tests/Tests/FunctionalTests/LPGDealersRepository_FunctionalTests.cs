﻿using NUnit.Framework;
using LPGDealersApp.Models;
using LPGDealersApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPGDealersApp.FunctionalTests
{
    [Order(6), TestFixture("LPGDealersApp", "LPGDealersApp.Models", "LPGDealersRepository")]
    class LPGDealersRepository_FunctionalTests : TestBase
    {
        public LPGDealersRepository_FunctionalTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        public void AddDealer_Test()
        {
            string MethodName = "AddDealer";
            try
            {
                var Obj = new LPGDealers
                {
                    DealerName = "Dealer",
                    DealerCategory = "Rural",
                    StartDate = DateTime.Now,
                    City = "Kochi",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.IsTrue(Result, $"{MethodName} method of class {typeName} doesnot returns true on saving the data");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(2)]
        public void Add_DuplicateDealer_Test()
        {
            string MethodName = "AddDealer";
            try
            {
                var Context = new LPGDealersContext();

                var Obj = Context.Dealers.First();
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.False(Result, $"{MethodName} method of class {typeName} doesnot returns false on trying to add a duplicate dealer");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(3)]
        public void Search_Test()
        {
            string MethodName = "Search";
            try
            {

                var Result = InvokeMethod<List<LPGDealers>>(MethodName, type, new object[] { "Kochi", "Rural" });
                Assert.IsNotNull(Result, $"{MethodName} method of class {typeName} doesnot returns list of Dealers saved in the database");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(4)]
        public void AddDealer_SearchDealer_Test()
        {
            string MethodName = "AddDealer";
            string MethodName1 = "Search";
            try
            {

                var CountBeforeAdd = InvokeMethod<List<LPGDealers>>(MethodName1, type, "Pune", "Rural").Count;

                var Obj = new LPGDealers
                {
                    DealerName = "Dealer",
                    DealerCategory = "Rural",
                    StartDate = DateTime.Now,
                    City = "Pune",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var AddResult = InvokeMethod<bool>(MethodName, type, Obj);

                var CountAfterAdd = InvokeMethod<List<LPGDealers>>(MethodName1, type, "pune", "rural").Count;

                Assert.AreEqual(CountBeforeAdd + 1, CountAfterAdd, $"{MethodName} method of class {typeName} doesnot returns newly added records.");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName + " and " + MethodName1));
            }
        }

    }
}
