﻿using NUnit.Framework;
using LPGDealersApp.Models;
using LPGDealersApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPGDealersApp.StructuralTests
{
     
     [Order(4), TestFixture("LPGDealersApp", "LPGDealersApp.Models", "LPGDealersRepository")]
    public class LPGDealersRepository_StructuralTests : TestBase
    {
        public LPGDealersRepository_StructuralTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("context", "LPGDealersContext");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "context", fieldType: "LPGDealersContext"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "context"));
            }
        }

        [Test]
        public void AddDealers_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddDealer", new Type[] { typeof(LPGDealers) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddDealer() which accepts Dealer entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddDealer() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(string), typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search() method which accepts 2  string parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void ListDealers_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("ListDealers", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines ListDealers() method which accepts no parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check ListDealers() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
