﻿using NUnit.Framework;
using LPGDealersApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LPGDealersApp.StructuralTests
{
    
    [Order(2), TestFixture("LPGDealersApp", "LPGDealersApp.Models", "LPGDealersContext")]
    public class LPGDealersContext_StructuralTests : TestBase
    {
        public LPGDealersContext_StructuralTests(string assemblyName, string namespaceName, string typeName) 
                                                    : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void DbSet_Dealers_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("Dealers", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("Dealers", "DbSet<Dealer>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "Dealers"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} doesnot inherits from DbContext base class");
        }
    }
}
