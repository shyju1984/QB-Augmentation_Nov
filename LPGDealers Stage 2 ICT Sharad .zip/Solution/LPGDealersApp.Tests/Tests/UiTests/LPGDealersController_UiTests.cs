﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using LPGDealersApp.Models;
using LPGDealersApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace LPGDealersApp.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    public class LPGDealersController_UiTests
    {
        private readonly string appURL;
        private IWebDriver driver;

        public LPGDealersController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }


        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Add", title, $"Application doesnot start with the page titled Add");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(2)]
        public void AddDealer_SearchDealer_NavigationLinksTest()
        {
            try
            {
                driver.ClickElement("lnkSearch");
                string SearchPageTitle = driver.Title;

                driver.ClickElement("lnkAdd");
               
                string AddPageTitle = driver.Title;


                StringAssert.Contains("Add", AddPageTitle, $"Application doesnot navigates to Add page on clicking Add Dealer hyperlink");

                StringAssert.Contains("Search", SearchPageTitle, $"Application doesnot navigates to Search page on clicking Search Dealer hyperlink");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Add Dealer and Search dealer navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }


        [Test, Order(3)]
        [Rollback]
        public void AddDealer_Test()
        {
            try
            {
                var ExpectedSuccessMessage = "Dealer details added successfully";
                var ExpectedFailureMessage = "Failed to add dealer details. Try again later";
                driver.ClickElement("lnkAdd");
                
                var Element = driver.FindElement(By.Id("DealerCategory"));
                Assert.IsNotNull(Element, $"Add Dealers page doesn't displays the dropdown list for Dealer Category types");
                var DropDown = new SelectElement(Element);
               
                var DealerCategories = new List<string> { "Select Dealer Category", "Cooperative", "Rural", "Urban", "WomenQuota", "DefenceQuota", "SportsQuota" };
                foreach (var group in DealerCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"DealerCategories dropdown doesn't contains the value {group}");
                }
                string MobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8);
                driver.SetElementText("DealerName", "Abcde");
                driver.SetElementText("StartDate", DateTime.Now.Date.ToShortDateString());
                driver.SetElementText("ContactMobileNo", MobileNo);
                driver.SetElementText("City", "Pune");
                driver.SelectDropDownItemByText("DealerCategory", "Rural");

                driver.ClickElement("btnSubmit");
               
                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Add dealer page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid dealer object");

                driver.ClickElement("btnSubmit");
                
                ActualMessage= driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedFailureMessage, ActualMessage, $"Add dealer page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag on trying to save a duplicate dealer object");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save dealer details from Add Dealer page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        public void SearchDealer_Test()
        {
            try
            {
                var WelcomeMessage = "Provide the search criteria to start looking for a dealer";
                var notFound = "No dealer found with the given search criteria";
                driver.ClickElement("lnkSearch");             
             

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(WelcomeMessage, ActualMessage, $"Search dealer page doesnot displays the message - '{WelcomeMessage}' in h2 tag on opening the page");

                var Element = driver.FindElement(By.Id("DealerCategory"));
                Assert.IsNotNull(Element, $"Search Dealers page doesn't displays the dropdown list for Dealer Category types");
                var DropDown = new SelectElement(Element);

                var DealerCategories = new List<string> {"Select Dealer Category", "Cooperative", "Rural", "Urban", "WomenQuota", "DefenceQuota", "SportsQuota" };
                foreach (var group in DealerCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"DealerCategories dropdown doesn't contains the value {group}");
                }
                
                driver.SetElementText("City", "Test City");
                driver.SelectDropDownItemByText("DealerCategory", "Rural");
                driver.ClickElement("btnSubmit");

                ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(notFound, ActualMessage, $"Search dealer page doesnot displays the message - '{notFound}' in h2 tag when there are no Dealers for given search criteria");

                driver.SetElementText("City", "Pune");
                driver.SelectDropDownItemByText("DealerCategory", "Rural");
                driver.ClickElement("btnSubmit");

                var context = new LPGDealersContext();
                var counts = context.Dealers.Count(d => d.City.ToLower() == "pune" && d.DealerCategory == "Rural");

                var TableRowCount = driver.GetTableRowsCount("tblDealers") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search dealer page doesnot includes all the records in tblDealers html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search dealer details from Search Dealer page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(5)]
        public void Index_Test()
        {
            try
            {
                driver.ClickElement("lnkIndex");

                var context = new LPGDealersContext();                
                var counts = context.Dealers.Count();

                var TableRowCount = driver.GetTableRowsCount("tblDealers") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search dealer page doesnot includes all the records in tblDealers html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search dealer details from Search Dealer page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
