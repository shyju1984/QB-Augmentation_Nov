using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace BMITracker.NUnitTests
{
    [TestFixture]
    public abstract class IISServerTest
    {
        private const int WebAppPort = 49779;

        private Process _webHostProcess;
        private readonly string _applicationName;

        protected IISServerTest(string applicationName)
        {
            _applicationName = applicationName;
        }

        [SetUp]
        public void TestInitialize()
        {
            // Start IISExpress here
            StartIIS();

            Initialize();
        }

        [TearDown]
        public void TestCleanup()
        {
            Cleanup();
            // Make sure that IISExpress is stopped here
            if (_webHostProcess.HasExited == false)
            {
                _webHostProcess.Kill();
            }
        }

        public abstract void Initialize();

        public abstract void Cleanup();

        private void StartIIS()
        {
            var applicationPath = GetApplicationPath(_applicationName);
            var key = Environment.Is64BitOperatingSystem ? "programfiles(x86)" : "programfiles";
            var programfiles = Environment.GetEnvironmentVariable(key);

            var iisExpressStartInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Normal,
                ErrorDialog = true,
                LoadUserProfile = true,
                CreateNoWindow = false,
                UseShellExecute = false,
                Arguments = String.Format("/path:\"{0}\" /port:{1}", applicationPath, WebAppPort),
                FileName = string.Format("{0}\\IIS Express\\iisexpress.exe", programfiles)
            };
            _webHostProcess = Process.Start(iisExpressStartInfo);
        }

        protected virtual string GetApplicationPath(string applicationName)
        {
            var solutionFolder = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)));
            return Path.Combine(solutionFolder, applicationName);
        }

        public string GetAbsoluteUrl(string relativeUrl)
        {
            return String.Format(@"http://localhost:{0}/{1}", WebAppPort, relativeUrl);
        }
    }

    public abstract class SeleniumTest : IISServerTest
    {
        private RemoteWebDriver _remoteWebDriver;
        protected IWebDriver WebDriver
        {
            get { return _remoteWebDriver; }
        }

        protected SeleniumTest(string applicationName) : base(applicationName)
        {
        }

        public override void Initialize()
        {
            _remoteWebDriver = new ChromeDriver();
        }

        public override void Cleanup()
        {
            _remoteWebDriver.Dispose();
        }
    }

    [TestFixture]
    public class BMITrackerUITests : SeleniumTest, IDisposable
    {
        public BMITrackerUITests() : base("BMI Tracker")
        {

        }

        [Test]
        [Order(1)]
        public void Test_IndexView()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Index"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Index - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.XPath("//*[text() = 'Index']")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));



                var link = WebDriver.FindElement(By.LinkText("Create New"));
                link.Click();
                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }


        [Test]
        [Order(2)]
        public void Test_CreateView()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Person Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date of Record']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Height In CM']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Weight In Kg']"));
                IWebElement btnCheck = WebDriver.FindElement(By.Id("check"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                btnCheck.Click();
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Person Name']"));

                btnSubmit.Click();
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Select Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Provide Date of Record']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Weight in KG']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Height in CM']"));
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(3)]
        public void Test_CreateViewValidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Person Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date of Record']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Height In CM']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Weight In Kg']"));
                IWebElement btnCheck = WebDriver.FindElement(By.Id("check"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                WebDriver.FindElement(By.Id("PersonName")).SendKeys("Murthi");
                btnCheck.Click();

                WebDriver.FindElement(By.Id("Age")).Clear();
                WebDriver.FindElement(By.Id("Age")).SendKeys("35");

                WebDriver.FindElement(By.Id("Gender")).SendKeys("Male");

                WebDriver.FindElement(By.Id("DateOfRecord")).SendKeys("11-11-2020");

                WebDriver.FindElement(By.Id("WeightInKg")).Clear();
                WebDriver.FindElement(By.Id("WeightInKg")).SendKeys("76");
                WebDriver.FindElement(By.Id("HeightInCm")).Clear();
                WebDriver.FindElement(By.Id("HeightInCm")).SendKeys("182");


                btnCheck = WebDriver.FindElement(By.Id("check"));
                btnSubmit = WebDriver.FindElement(By.Id("submit"));

                btnSubmit.Click();

                Assert.AreEqual("Index - BMI Tracker", WebDriver.Title);

                heading = WebDriver.FindElement(By.XPath("//*[text() = 'Index']")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));

                var name = WebDriver.FindElements(By.XPath("//td[contains(text(),'Murthi')]"));
                Assert.AreEqual(name.Count, 1);


            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(6)]
        public void Test_CreateViewExistingData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Person Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date of Record']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Height In CM']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Weight In Kg']"));
                IWebElement btnCheck = WebDriver.FindElement(By.Id("check"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                WebDriver.FindElement(By.Id("PersonName")).SendKeys("Aman");
                btnCheck.Click();

                string age = WebDriver.FindElement(By.Id("Age")).GetAttribute("value");
                string gender = WebDriver.FindElement(By.Id("Gender")).GetAttribute("value");
                string height = WebDriver.FindElement(By.Id("HeightInCm")).GetAttribute("value");

                Assert.AreEqual("25", age);
                Assert.AreEqual("1", gender);
                Assert.AreEqual("176", height);

                WebDriver.FindElement(By.Id("DateOfRecord")).SendKeys("11-11-2020");

                WebDriver.FindElement(By.Id("WeightInKg")).Clear();
                WebDriver.FindElement(By.Id("WeightInKg")).SendKeys("76");

                btnCheck = WebDriver.FindElement(By.Id("check"));
                btnSubmit = WebDriver.FindElement(By.Id("submit"));

                btnSubmit.Click();

                Assert.AreEqual("Index - BMI Tracker", WebDriver.Title);

                heading = WebDriver.FindElement(By.XPath("//*[text() = 'Index']")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));

                var name = WebDriver.FindElements(By.XPath("//td[contains(text(),'Aman')]"));
                Assert.AreEqual(name.Count, 3);


            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(5)]
        public void Test_CreateViewInvalidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Person Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date of Record']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Height In CM']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Weight In Kg']"));
                IWebElement btnCheck = WebDriver.FindElement(By.Id("check"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                WebDriver.FindElement(By.Id("PersonName")).SendKeys("Aman");
                btnCheck.Click();

                WebDriver.FindElement(By.Id("Age")).Clear();
                WebDriver.FindElement(By.Id("Age")).SendKeys("15");

                WebDriver.FindElement(By.Id("WeightInKg")).Clear();
                WebDriver.FindElement(By.Id("WeightInKg")).SendKeys("16");
                WebDriver.FindElement(By.Id("HeightInCm")).Clear();
                WebDriver.FindElement(By.Id("HeightInCm")).SendKeys("82");

                WebDriver.FindElement(By.Id("DateOfRecord")).SendKeys("11-11-2020");

                btnCheck = WebDriver.FindElement(By.Id("check"));
                btnSubmit = WebDriver.FindElement(By.Id("submit"));

                btnSubmit.Click();

                Assert.AreEqual("Create - BMI Tracker", WebDriver.Title);

                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Age']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Weight in KG']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Please Enter Height in CM']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(4)]
        public void Test_AnalyseView()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Analyse"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Analyse - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                IWebElement ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                IWebElement btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                btnSubmit.Click();

                var head1 = WebDriver.FindElements(By.XPath("//th[contains(text(),'Person Name')]"));
                Assert.AreEqual(head1.Count, 0);

                ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                ddPersonName.SendKeys("Aman");
                btnSubmit.Click();

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));

                var nameRepeated = WebDriver.FindElements(By.XPath("//td[contains(text(),'Aman')]"));
                Assert.AreEqual(nameRepeated.Count, 1);

                WebDriver.FindElement(By.XPath("//*[text() = 'Ideal weight should be - 69.3 kg']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'You are gaining weight']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'BMI - 21.3 kg/m�']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Your BMI Level - Normal']"));

                ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                ddPersonName.SendKeys("Ruchi");
                btnSubmit.Click();
                nameRepeated = WebDriver.FindElements(By.XPath("//td[contains(text(),'Ruchi')]"));
                Assert.AreEqual(nameRepeated.Count, 1);

                WebDriver.FindElement(By.XPath("//*[text() = 'Ideal weight should be - 55.0 kg']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'You are losing weight']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'BMI - 22.2 kg/m�']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Your BMI Level - Normal']"));
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(7)]
        public void Test_AnalyseViewSingleRecord()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Analyse"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Analyse - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                IWebElement ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                IWebElement btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                btnSubmit.Click();

                var head1 = WebDriver.FindElements(By.XPath("//th[contains(text(),'Person Name')]"));
                Assert.AreEqual(head1.Count, 0);

                ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                ddPersonName.SendKeys("Murthi");
                btnSubmit.Click();

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));

                var nameRepeated = WebDriver.FindElements(By.XPath("//td[contains(text(),'Murthi')]"));
                Assert.AreEqual(nameRepeated.Count, 1);
                                      
                WebDriver.FindElement(By.XPath("//*[text() = 'Ideal weight should be - 72.6 kg']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Need more data to analyse weight trend']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'BMI - 22.9 kg/m�']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Your BMI Level - Normal']"));
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(8)]
        public void Test_AnalyseViewMultipleRecords()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            IWebElement btnCheck = WebDriver.FindElement(By.Id("check"));
            IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

            WebDriver.FindElement(By.Id("PersonName")).SendKeys("Murthi");
            btnCheck.Click();

            
            WebDriver.FindElement(By.Id("DateOfRecord")).SendKeys("11-12-2020");

            WebDriver.FindElement(By.Id("WeightInKg")).Clear();
            WebDriver.FindElement(By.Id("WeightInKg")).SendKeys("77");           

            btnCheck = WebDriver.FindElement(By.Id("check"));
            btnSubmit = WebDriver.FindElement(By.Id("submit"));

            btnSubmit.Click();            

            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("BMI/Analyse"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("BMI Tracker"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));
                WebDriver.FindElement(By.LinkText("Analyse"));

                Assert.AreEqual("Analyse - BMI Tracker", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                IWebElement ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                btnSubmit.Click();

                var head1 = WebDriver.FindElements(By.XPath("//th[contains(text(),'Person Name')]"));
                Assert.AreEqual(head1.Count, 0);

                ddPersonName = WebDriver.FindElement(By.Id("PersonName"));
                btnSubmit = WebDriver.FindElement(By.XPath("//input[@type='submit' and @value='Get Analysis']"));

                ddPersonName.SendKeys("Murthi");
                btnSubmit.Click();

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Person Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Age')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date of Record')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Height In CM')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Weight In Kg')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Calculated BMI')]"));

                var nameRepeated = WebDriver.FindElements(By.XPath("//td[contains(text(),'Murthi')]"));
                Assert.AreEqual(nameRepeated.Count, 1);

                WebDriver.FindElement(By.XPath("//*[text() = 'Ideal weight should be - 72.6 kg']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'You are gaining weight']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'BMI - 23.2 kg/m�']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Your BMI Level - Normal']"));
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }


        public void Dispose()
        {
            WebDriver.Quit();
            WebDriver.Dispose();
        }
    }
}
