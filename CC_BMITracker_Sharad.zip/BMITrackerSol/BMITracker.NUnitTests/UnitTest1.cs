﻿using BMITrackerApp.Controllers;
using BMITrackerApp.Data;
using BMITrackerApp.Models;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;

namespace BMITrackerUnitTests
{
    [TestFixture]
    public class NUnitTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("BMITrackerApp");
            className = assembly.GetType("BMITrackerApp.Controllers.BMIController");
            modelClassName = assembly.GetType("BMITrackerApp.Models.BMI");
            dbContextclassName = assembly.GetType("BMITrackerApp.Data.BMIDAO");
        }

        //============================== Non Functional ===========================================================


        //----------------------------- Check BMIDAO -------------------------------------------

        [TestCase]
        [Order(1)]
        public void BMIDAO_WhenNoSuchClassFound_WarnsUser()
        {
            if (dbContextclassName == null)
                Assert.Fail("No DAO class with the name 'BMIDAO' is implemented as required OR Did you change the class name");
        }

        [TestCase]
        [Order(2)]
        public void BMIDAO_InitalizesDb()
        {
            try
            {
                if (dbContextclassName != null)
                {
                    ConstructorInfo classConstructor = dbContextclassName.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public |
                                            BindingFlags.NonPublic | BindingFlags.Static;

                    FieldInfo field = dbContextclassName.GetField("bmiData", allBindings);
                    var data = (List<BMI>)field.GetValue(null);
                    Assert.AreEqual(4, data.Count, "Initial Data is changed");
                    Assert.IsNotNull(field);
                }
                else
                    Assert.Fail("No class with the name 'BMIDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Checking existing data failed. Exception should not be thrown.");
            }
        }

        [TestCase]
        [Order(3)]
        public void DAO_GetBMIData_WhenNoSuchMethodFound_WarnsUser()
        {
            if (dbContextclassName != null)
            {
                MethodInfo testMethod = dbContextclassName.GetMethods().Where(x => x.Name.Equals("GetBMIData")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(List<BMI>)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method GetBMIData NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIDAO' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(4)]
        public void DAO_GetBMIReport_WhenNoSuchMethodFound_WarnsUser()
        {
            if (dbContextclassName != null)
            {
                MethodInfo testMethod = dbContextclassName.GetMethods().Where(x => x.Name.Equals("GetBMIReport")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(string)
                                           && x.ReturnType == typeof(List<string>)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method GetBMIReport NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIDAO' is implemented  as per the requirement OR Did you change the class name");
        }



        //----------------------------- Check BMI Model -------------------------------------------

        [TestCase]
        [Order(5)]
        public void Model_BMI_WhenNoSuchClassFound_WarnsUser()
        {
            if (modelClassName == null)
                Assert.Fail("No model class with the name 'BMI' is implemented as required OR Did you change the class name");
        }

        [TestCase]
        [Order(6)]
        public void Model_GetIdealWeight_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("GetIdealWeight")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(double)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method GetIdealWeight NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMI' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(7)]
        public void Model_GetBMI_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods().Where(x => x.Name.Equals("GetBMI")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(double)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method GetBMI NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMI' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(8)]
        public void Model_CmToInch_WhenNoSuchMethodFound_WarnsUser()
        {
            if (modelClassName != null)
            {
                MethodInfo testMethod = modelClassName.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance).Where(x => x.Name.Equals("CmToInch")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(double)
                                           && x.ReturnType == typeof(double)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Private Method CmToInch NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMI' is implemented  as per the requirement OR Did you change the class name");
        }



        //----------------------------- Check BMIController -------------------------------------------

        [TestCase]
        [Order(9)]
        public void BMIController_WhenNoSuchClassFound_WarnsUser()
        {
            if (className == null)
                Assert.Fail("No controller class with the name 'BMIController' is implemented OR Did you change the class name");
        }


        [TestCase]
        [Order(10)]
        public void Index_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();
                Assert.IsNotNull(testMethod, "Method Index NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(11)]
        public void Create_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Create")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Create NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(12)]
        public void Create_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Create")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(BMI)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Post Method Create NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(13)]
        public void Analyse_WhenNoSuchActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Analyse")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Method Analyse NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIController' is implemented  as per the requirement OR Did you change the class name");
        }

        [TestCase]
        [Order(14)]
        public void Analyse_WhenNoSuchPostActionMethodFound_WarnsUser()
        {
            if (className != null)
            {
                MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Analyse")
                                           && x.GetParameters().Count() == 1
                                           && x.GetParameters().First().ParameterType == typeof(string)
                                           && x.ReturnType == typeof(ActionResult)
                                           && x.CustomAttributes.First().AttributeType.Name
                                                    .Equals("HttpPostAttribute")).FirstOrDefault();

                Assert.IsNotNull(testMethod, "Post Method Analyse NOT implemented as per the requirement OR check the spelling");
            }
            else
                Assert.Fail("No class with the name 'BMIController' is implemented  as per the requirement OR Did you change the class name");
        }


        //============================== Functional ===========================================================


        //----------------------------- Check BMIDAO -------------------------------------------
        [Test]
        [Order(15)]
        public void DAO_GetBMIData_ShouldGetData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BMIDAO dao = new BMIDAO();

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetBMIData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddBMIData' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetBMIData().Count;

                    Assert.AreEqual(countAfter, 4);
                }
                else
                    Assert.Fail("No class with the name 'BMIDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Getting bmi data from collection failed.");
            }
        }

        [Test]
        [Order(16)]
        public void DAO_AddBMIData_ShouldAddData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BMIDAO dao = new BMIDAO();
            BMI bmi = new BMI()
            {
                PersonName = "Ruchi",
                Age = 21,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 156,
                WeightInKg = 53,
                CalculatedBMI = 21.8
            };

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("AddBMIData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddBMIData' NOT implemented OR check spelling");

                    int countBefore = dao.GetBMIData().Count;
                    object[] parameters = new object[] { bmi };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetBMIData().Count;

                    Assert.AreEqual(countAfter, countBefore + 1);
                }
                else
                    Assert.Fail("No class with the name 'BMIDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new bmi data to the collection failed.");
            }
        }

        [Test]
        [Order(17)]
        public void DAO_GetBMIReport_ShouldReturnCorrectReport()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            BMIDAO dao = new BMIDAO();
            BMI bmi1 = new BMI()
            {
                PersonName = "AAAA",
                Age = 21,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 126,
                WeightInKg = 53,
                CalculatedBMI = 21.8
            };
            BMI bmi2 = new BMI()
            {
                PersonName = "AAAA",
                Age = 21,
                DateOfRecord = new DateTime(2001, 05, 15),
                Gender = Gender.Female,
                HeightInCm = 126,
                WeightInKg = 54,
                CalculatedBMI = 21.8
            };
            BMIDAO.bmiData.Add(bmi1);
            BMIDAO.bmiData.Add(bmi2);

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;
                                        
                    testMethods = dbContextclassName.GetMethods(allBindings);
                    testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetBMIReport"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'GetBMIReport' NOT implemented OR check spelling");

                    object[] parameters = new object[] { "AAAA" };
                    List<string> report = (List<string>)testMethod.Invoke(dao, parameters);

                    Assert.AreEqual(report[0], "Ideal weight should be - 39.0 kg");
                    Assert.AreEqual(report[1], "You are gaining weight");
                    Assert.AreEqual(report[2], "BMI - 34.0 kg/m²");
                    Assert.AreEqual(report[3], "Your BMI Level - Obese");
                }
                else
                    Assert.Fail("No class with the name 'BMIDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("GetBMIReport not returning correct report.");
            }
        }

        //----------------------------- Check BMI -------------------------------------------

        [Test]
        [Order(18)]
        public void BMI_GetIdealWeight_ShouldCalculateCorrectly()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            BMI bmi = new BMI()
            {
                PersonName = "Ruchi",
                Age = 26,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 140,
                WeightInKg = 53,
                CalculatedBMI = 21.8
            };

            try
            {
                if (modelClassName != null)
                {
                    MethodInfo[] testMethods = modelClassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetIdealWeight"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'GetIdealWeight' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    double actual = (double)testMethod.Invoke(bmi, parameters);

                    Assert.AreEqual(Math.Round(actual, 2), Math.Round(46.46, 2));
                }
                else
                    Assert.Fail("No class with the name 'BMI' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("GetIdealWeight method not implemented correctly.");
            }
        }

        [Test]
        [Order(19)]
        public void BMI_GetBMI_ShouldCalculateCorrectly()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            BMI bmi = new BMI()
            {
                PersonName = "Ruchi",
                Age = 26,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 140,
                WeightInKg = 57,
                CalculatedBMI = 21.8
            };

            try
            {
                if (modelClassName != null)
                {
                    MethodInfo[] testMethods = modelClassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetBMI"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'GetBMI' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    double actual = (double)testMethod.Invoke(bmi, parameters);

                    Assert.AreEqual(Math.Round(actual, 2), Math.Round(29.08, 2));
                }
                else
                    Assert.Fail("No class with the name 'BMI' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("GetBMI method not implemented correctly.");
            }
        }

        //----------------------------- Check BMIController -------------------------------------------

        [Test]
        [Order(20)]
        public void IndexAction_When_Invoked_Return_SortedList()
        {
            //Arrange 
            BMIDAO dao = new BMIDAO();
            BMIDAO.bmiData.Clear();
            BMI bmi1 = new BMI()
            {
                PersonName = "AAAA",
                Age = 21,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 126,
                WeightInKg = 53,
                CalculatedBMI = 21.8
            };
            BMI bmi2 = new BMI()
            {
                PersonName = "AAAA",
                Age = 21,
                DateOfRecord = new DateTime(2001, 03, 15),
                Gender = Gender.Female,
                HeightInCm = 126,
                WeightInKg = 54,
                CalculatedBMI = 21.8
            };
            BMIDAO.bmiData.Add(bmi1);
            BMIDAO.bmiData.Add(bmi2);

            try
            {
                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var bmiList = (IEnumerable<BMI>)viewResult.ViewData.Model;

                    Assert.AreEqual(2, bmiList.Count(),
                        "Verify whether you fetched the data from the collection correctly or not");

                    //to test list is sorted
                    var dataList = dao.GetBMIData().OrderBy(b => b.PersonName).ThenBy(b => b.DateOfRecord).ToList();

                    bool isSorted = dataList.SequenceEqual(bmiList);
                    Assert.That(isSorted, "List should be sorted properly");
                }
                else
                    Assert.Fail("No class with the name 'BMIController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        [Order(21)]
        public void CreateBMI_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var BMIController = new BMIController();
            BMIDAO db = new BMIDAO();
            BMI bmi = new BMI()
            {
                PersonName = "Ruchi",
                Age = 26,
                DateOfRecord = new DateTime(2001, 04, 15),
                Gender = Gender.Female,
                HeightInCm = 140,
                WeightInKg = 57,
                CalculatedBMI = 21.8
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => bmi, bmi.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("BMITrackerApp.Controllers.BMIController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("Create")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'BMIController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new bmi data failed. verify the state of model object");
            }
        }

        [Test]
        public void AnalysePostAction_When_Invoked_Return_CorrectReport()
        {
            //Arrange 
            BMIDAO dao = new BMIDAO();
            BMIDAO.bmiData.Add(new BMI
            {
                PersonName = "BBBB",
                Age = 21,
                DateOfRecord = new DateTime(2019, 12, 11),
                Gender = Gender.Female,
                HeightInCm = 145,
                WeightInKg = 54
            });

            BMIDAO.bmiData.Add(new BMI
            {
                PersonName = "BBBB",
                Age = 21,
                DateOfRecord = new DateTime(2019, 11, 11),
                Gender = Gender.Female,
                HeightInCm = 145,
                WeightInKg = 55
            });
            try
            {
                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Analyse")
                                           && x.GetParameters().Count() == 1
                                            && x.CustomAttributes.First().AttributeType
                                                        .Name.Equals("HttpPostAttribute")
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Analyse' Post NOT implemented with parameter or return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { "BBBB" });
                    var bmiList = (IEnumerable<BMI>)viewResult.ViewData.Model;

                    Assert.AreEqual(2, bmiList.Count(),
                        "Verify whether you fetched the data from the collection correctly or not");


                    //to test list is sorted
                    var dataList = dao.GetBMIData().Where(b => b.PersonName == "BBBB").OrderBy(b => b.PersonName).ThenBy(b => b.DateOfRecord).ToList();

                    bool isSorted = dataList.SequenceEqual(bmiList);
                    Assert.That(isSorted, "List should be sorted properly");
                }
                else
                    Assert.Fail("No class with the name 'BMIController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

       
    }
}
