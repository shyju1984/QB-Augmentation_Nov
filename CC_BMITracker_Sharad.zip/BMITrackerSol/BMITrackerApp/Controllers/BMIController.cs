﻿using BMITrackerApp.Data;
using BMITrackerApp.Models;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BMITrackerApp.Controllers
{
    public class BMIController : Controller
    {
        BMIDAO dao = null;

        public BMIController()
        {
            dao = new BMIDAO();
        }

        // GET: BMI
        public ActionResult Index()
        {
            //List<BMI> list = dao.GetBMIData();
            //for (int i = 0; i < 4; i++)
            //{
            //    list[i].CalculatedBMI = Math.Round(list[i].GetBMI(), 1);
            //}

            return View(dao.GetBMIData()
                            .OrderBy(d => d.PersonName)
                            .ThenBy(d => d.DateOfRecord).ToList());
        }
        public ActionResult Create()
        {
            BMI bmi = new BMI();
            return View(bmi);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult CheckExisting(string PersonName)
        {
            BMI bmi = dao.GetBMIData().Where(p => p.PersonName == PersonName).FirstOrDefault();
            if (bmi != null)
            {
                BMI newBmi = new BMI();
                newBmi.PersonName = bmi.PersonName;
                newBmi.HeightInCm = bmi.HeightInCm;
                newBmi.Age = bmi.Age;
                newBmi.Gender = bmi.Gender;
                newBmi.DateOfRecord = null;
                newBmi.WeightInKg = 0;

                return View("Create", newBmi);
            }
            else
            {
                return View("Create", new BMI { PersonName = PersonName });
            }
        }

        [HttpPost]
        public ActionResult Create(BMI bmi)
        {
            if (ModelState.IsValid)
            {
                bmi.CalculatedBMI = bmi.GetBMI();
                dao.AddBMIData(bmi);
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Analyse()
        {
            List<string> names = dao.GetBMIData().Select(p => p.PersonName).Distinct().ToList();
            ViewBag.PersonName = new SelectList(names);

            return View(dao.GetBMIData().OrderBy(d => d.PersonName).ThenBy(d => d.DateOfRecord));
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Analyse(string PersonName)
        {
            if (PersonName == "")
            {
                return RedirectToAction("Analyse");
            }

            List<string> names = dao.GetBMIData().Select(p => p.PersonName).Distinct().ToList();
            ViewBag.PersonName = new SelectList(names);

            List<string> report = dao.GetBMIReport(PersonName);

            ViewBag.Report = report;
            return View(dao.GetBMIData().Where(p => p.PersonName == PersonName)
                                        .OrderBy(d => d.PersonName)
                                        .ThenBy(d => d.DateOfRecord));
        }
    }
}