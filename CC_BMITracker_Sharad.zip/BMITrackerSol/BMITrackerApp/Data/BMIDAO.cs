﻿using BMITrackerApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BMITrackerApp.Data
{
    public class BMIDAO
    {
        public static List<BMI> bmiData = new List<BMI>
                {
                     new BMI{  PersonName="Ruchi", Age=21, DateOfRecord=new DateTime(2001,02,15), Gender=Gender.Female , HeightInCm=156, WeightInKg=55, CalculatedBMI=22.6 },
                     new BMI{  PersonName="Ruchi", Age=21, DateOfRecord=new DateTime(2001,03,15), Gender=Gender.Female , HeightInCm=156, WeightInKg=54, CalculatedBMI=22.2 },
                     new BMI{  PersonName="Aman", Age=25, DateOfRecord=new DateTime(2001,02,15), Gender=Gender.Male, HeightInCm=176, WeightInKg=65, CalculatedBMI=21.0 },
                     new BMI{  PersonName="Aman", Age=25, DateOfRecord=new DateTime(2001,03,15), Gender=Gender.Male, HeightInCm=176, WeightInKg=66, CalculatedBMI=21.3 }
                };

        public BMIDAO()
        {

        }
        public List<BMI> GetBMIData()
        {
            return bmiData;
        }
        public void AddBMIData(BMI bmi)
        {
            bmiData.Add(bmi);
        }
        public List<string> GetBMIReport(string personName)
        {
            var allData = GetBMIData().Where(p => p.PersonName == personName).ToList();
            string[] report = new string[4];

            report[0] = string.Format("Ideal weight should be - {0:0.0} kg", allData[0].GetIdealWeight());
            if (allData.Count == 1)
            {
                report[1] = "Need more data to analyse weight trend";
            }
            else
            {
                double prevDataAvg = GetBMIData()
                                        .Where(p => p.PersonName == personName)
                                        .Take(allData.Count - 1)
                                        .Average(a => a.WeightInKg);

                double secondLastData = GetBMIData()
                                        .Where(p => p.PersonName == personName)
                                        .Skip(allData.Count - 2).Take(1).FirstOrDefault().WeightInKg;

                double lastData = GetBMIData()
                                        .Where(p => p.PersonName == personName)
                                        .Skip(allData.Count - 1).Take(1).FirstOrDefault().WeightInKg;

                if (lastData > secondLastData)
                {
                    report[1] = "You are gaining weight";
                }
                else if (lastData < secondLastData)
                {
                    report[1] = "You are losing weight";
                }
            }
            double bmi = Math.Round(allData[allData.Count - 1].GetBMI(), 1);
            report[2] = string.Format("BMI - {0:0.0} kg/m\xB2", bmi);

            if (bmi < 18.5)
            {
                report[3] = string.Format("Your BMI Level - Thin");
            }
            else if (bmi >= 18.5 && bmi <= 25)
            {
                report[3] = string.Format("Your BMI Level - Normal");
            }
            else
            {
                report[3] = string.Format("Your BMI Level - Obese");
            }

            return new List<string>(report);
        }
    }
}