﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BMITrackerApp.Models
{
    public enum Gender { Select, Male, Female, Others }

    public class BMI
    {
        [MaxLength(20)]
        [Required(ErrorMessage = "Please Provide Person Name")]
        [Display(Name = "Person Name")]
        public string PersonName { get; set; }

        [Required, Range(1, 3, ErrorMessage = "Please Select Gender")]
        public Gender Gender { get; set; }

        [Required, Range(18, 60, ErrorMessage = "Please Enter Age")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Please Provide Date of Record")]
        [DataType(DataType.Date)]
        [Display(Name = "Date of Record")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? DateOfRecord { get; set; }

        [Required, Range(30.0, 100.0, ErrorMessage = "Please Enter Weight in KG")]
        [Display(Name = "Weight In Kg")]
        public double WeightInKg { get; set; }

        [Required, Range(100, 300, ErrorMessage = "Please Enter Height in CM")]
        [Display(Name = "Height In CM")]
        public int HeightInCm { get; set; }

        [Display(Name = "Calculated BMI")]
        [DisplayFormat(DataFormatString = "{0:0.0}", ApplyFormatInEditMode = true)]
        public double CalculatedBMI { get; set; }

        public double GetIdealWeight()
        {
            double ideal = 0.0;
            if (Gender == Gender.Male)
            {
                ideal = 56.2 + 1.41 * (CmToInch(HeightInCm) - 60);
            }
            else
            {
                ideal = 53.1 + 1.36 * (CmToInch(HeightInCm) - 60);
            }
            return ideal;
        }
        double CmToInch(double cm)
        {
            return cm / 2.54;
        }
        public double GetBMI()
        {
            double bmi = 0.0;
            double heightM = HeightInCm / 100.0;
            double cm2 = heightM * heightM;
            bmi = WeightInKg / cm2;
            return bmi;
        }
    }
}
