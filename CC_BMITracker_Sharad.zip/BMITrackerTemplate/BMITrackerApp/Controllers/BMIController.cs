﻿using BMITrackerApp.Data;
using BMITrackerApp.Models;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BMITrackerApp.Controllers
{
    public class BMIController : Controller
    {   

        public BMIController()
        {
           
        }
        
        //Implement your code

        public ActionResult Index()
        {
     
            return View();
        }
    }
}