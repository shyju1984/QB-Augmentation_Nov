﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BMITrackerApp.Models
{
    public enum Gender { Select, Male, Female, Others }

    public class BMI
    {
        //Implement your code

        public string PersonName { get; set; }

        
        public Gender Gender { get; set; }

       
        public int Age { get; set; }

       
        public DateTime? DateOfRecord { get; set; }

        
        public double WeightInKg { get; set; }

       
        public int HeightInCm { get; set; }

        
        public double CalculatedBMI { get; set; }

        //Implement your methods
    }
}
