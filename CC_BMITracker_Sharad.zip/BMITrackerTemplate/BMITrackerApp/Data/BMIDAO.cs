﻿using BMITrackerApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BMITrackerApp.Data
{
    public class BMIDAO
    {
        public static List<BMI> bmiData = new List<BMI>
                {
                     new BMI{  PersonName="Ruchi", Age=21, DateOfRecord=new DateTime(2001,02,15), Gender=Gender.Female , HeightInCm=156, WeightInKg=55, CalculatedBMI=22.6 },
                     new BMI{  PersonName="Ruchi", Age=21, DateOfRecord=new DateTime(2001,03,15), Gender=Gender.Female , HeightInCm=156, WeightInKg=54, CalculatedBMI=22.2 },
                     new BMI{  PersonName="Aman", Age=25, DateOfRecord=new DateTime(2001,02,15), Gender=Gender.Male, HeightInCm=176, WeightInKg=65, CalculatedBMI=21.0 },
                     new BMI{  PersonName="Aman", Age=25, DateOfRecord=new DateTime(2001,03,15), Gender=Gender.Male, HeightInCm=176, WeightInKg=66, CalculatedBMI=21.3 }
                };
                

        //Implement your code
    }
}