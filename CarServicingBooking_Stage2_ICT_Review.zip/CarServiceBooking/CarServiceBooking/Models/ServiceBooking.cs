﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace CarServiceBooking.Models
{    
    public class ServiceBooking
    {
        [Key]
        public int BookingId { get; set; }
        [Required(ErrorMessage = "Please Select Service Type")]
        public string ServiceType { get; set; }
        [Required(ErrorMessage = "Please Provide Customer Name")]
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "Please Provide Mobile Number")]
        [RegularExpression(@"^[9876]{1}[0-9]{9}$", ErrorMessage = "Please Enter Valid Mobile Number")]
        public string MobileNumber { get; set; }
        [Required(ErrorMessage = "Please Provide Car Registration Number")]
        [RegularExpression(@"^[A-Z]{2}[-]{1}[0-9]{2}[-]{1}[A-Z]{1}[-]{1}[0-9]{4}$", ErrorMessage = "Please Provide valid RTO Number")]
        public string CarRegistrationNumber { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Please Provide Valid Date")]
        public DateTime? BookingDate { get; set; }        
    }
}