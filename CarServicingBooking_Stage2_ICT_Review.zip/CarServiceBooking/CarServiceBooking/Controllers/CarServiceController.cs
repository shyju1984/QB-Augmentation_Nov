﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarServiceBooking.Models;

namespace CarServiceBooking.Controllers
{
    public class CarServiceController : Controller
    {
        private BookingContext db = new BookingContext();

        // GET: CarService
        public ActionResult Index()
        {
            var serviceType = new List<string> { "Car Washing", "Tyre Checkup", "Oil Change" };
            ViewBag.ServiceType = new SelectList(serviceType);
            return View(db.ServiceBookings.ToList());
        }

        [HttpPost]
        public ActionResult Index(string ServiceType)
        {
            var serviceType = new List<string> { "Car Washing", "Tyre Checkup", "Oil Change" };
            ViewBag.ServiceType = new SelectList(serviceType);
            return View(db.ServiceBookings.Where(s=>s.ServiceType == ServiceType).ToList());
        }

        // GET: CarService/Create
        public ActionResult Create()
        {
            var serviceType = new List<string> { "Car Washing","Tyre Checkup","Oil Change" };
            ViewBag.ServiceType = new SelectList(serviceType);
            return View();
        }

        // POST: CarService/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BookingId,ServiceType,CustomerName,MobileNumber,CarRegistrationNumber,BookingDate")] ServiceBooking serviceBooking)
        {
            var serviceType = new List<string> { "Car Washing", "Tyre Checkup", "Oil Change" };
            ViewBag.ServiceType = new SelectList(serviceType);
            
            
                if (ModelState.IsValid)
                {
                    if (serviceBooking.BookingDate < DateTime.Now)
                    {
                        ViewBag.BookingDateError = "Booking Date Should be greater than Current Date";
                    }
                    else
                    { 
                    db.ServiceBookings.Add(serviceBooking);
                    db.SaveChanges();
                    ViewBag.Message = "Booking Successful";
                    }
            }

            return View(serviceBooking);
        }
        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
