namespace CarServiceBooking.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CarServcingBookingMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ServiceBookings",
                c => new
                    {
                        BookingId = c.Int(nullable: false, identity: true),
                        ServiceType = c.String(nullable: false),
                        CustomerName = c.String(nullable: false),
                        MobileNumber = c.String(nullable: false),
                        CarRegistrationNumber = c.String(nullable: false),
                        BookingDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.BookingId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.ServiceBookings");
        }
    }
}
