﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using CarServiceBooking.Models;
using CarServiceBookingTests.TestExtensions;
using System.Web.Mvc;
using System.Reflection;

namespace CarServiceBookingTests.Tests.StructuralTests
{
    [Order(3), TestFixture("CarServiceBooking", "CarServiceBooking.Controllers", "CarServiceController")]
    public class CarServiceController_StructuralTests : TestBase
    {
        public CarServiceController_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void InheritsFrom_ControllerTest()
        {
            Assert.AreEqual("Controller", type.BaseType.Name, $"{base.type.Name} does not inherits from Controller base class");
        }

        [Test]
        public void Create_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Create", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} does not defines Create action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Create action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Create_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Create", new Type[] { typeof(ServiceBooking) });
                Assert.IsNotNull(Method, $"{base.type.Name} does not defines Create action method which accepts over object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Create action is not marked with attributes to run on http post request in {base.type.Name} controller");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Create action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Index_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Index", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} does not defines Index action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Index action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Index_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Index", new Type[] { typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} does not defines Index action method");

                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Index action is not marked with attributes to run on http post request in {base.type.Name} controller");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Index action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
