﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using CarServiceBookingTests.TestExtensions;

namespace CarServiceBookingTests.Tests.StructuralTests
{
    [Order(2), TestFixture("CarServiceBooking", "CarServiceBooking.Models", "BookingContext")]
    public class BookingContext_StructuralTests : TestBase
    {
        public BookingContext_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }
        [Test]
        public void DbSet_Property_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("ServiceBookings", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("ServiceBookings", "DbSet<ServiceBooking>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "ServiceBookings"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} does not inherits from DbContext base class");
        }
    }
}
