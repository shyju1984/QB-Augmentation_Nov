﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using CarServiceBooking.Models;
using CarServiceBookingTests.TestExtensions;
using System.Transactions;
using System.Globalization;

namespace CarServiceBookingTests.Tests.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    class CarServiceController_UiTests
    {
        private readonly string appURL;
        private IWebDriver driver;

        public IFormatProvider CultureInfo { get; private set; }

        public CarServiceController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }

        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Index", title, $"Application does not start with the page titled Index");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
        [Test, Order(2)]
        public void AddBookings_NavigationLinksTest()
        {
            try
            {          
                driver.ClickElement("lnkAdd");
                string AddPageTitle = driver.Title;
                StringAssert.Contains("Create", AddPageTitle, $"Application does not navigates to Create page on clicking Create Bookings hyperlink");
                    
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Create Booking navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(3)]
        [Rollback]
        public void CreateBooking_InvalidBookingDateException_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                var ExpectedBookingDateFailureMessage = "Booking Date Should be greater than Current Date";
                driver.ClickElement("lnkAdd");

                var Element = driver.FindElement(By.Id("ServiceType"));
                Assert.IsNotNull(Element, $"Create Booking page doesn't displays the dropdown list for service types");
                var DropDown = new SelectElement(Element);

                var ServiceTypes = new List<string> { "Select Service Type", "Car Washing", "Tyre Checkup", "Oil Change" };
                foreach (var serviceType in ServiceTypes)
                {
                    var Found = DropDown.Options.Any(option => option.Text == serviceType);
                    Assert.IsTrue(Found, $"ServiceType dropdown doesn't contains the value {serviceType}");
                }
                DateTime dt = DateTime.ParseExact("2020-01-31", "yyyy-MM-dd", null);
                driver.SelectDropDownItemByText("ServiceType", "Car Washing");
                driver.SetElementText("CustomerName", "Anita");
                driver.SetElementText("MobileNumber", "9600147821");
                driver.SetElementText("CarRegistrationNumber", "TN-88-C-7811");
                driver.SetElementText("BookingDate", dt.Date.ToShortDateString());

                driver.ClickElement("btnSubmit");                

                var ActualMessage = driver.GetElementInnerText("h5", "@Id='BookingDateError'");
                Assert.AreEqual(ExpectedBookingDateFailureMessage, ActualMessage, $"Create booking page does not displays the message - '{ExpectedBookingDateFailureMessage}' in h5 tag on trying to save a wrong booking date");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save booking details from Create Booking page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        [Rollback]
        public void CreateBooking_Test()
        {
            driver.Navigate().GoToUrl(appURL);
            try
            {
                var ExpectedSuccessMessage = "Booking Successful";                
                driver.ClickElement("lnkAdd");

                var Element = driver.FindElement(By.Id("ServiceType"));
                Assert.IsNotNull(Element, $"Create Booking page doesn't displays the dropdown list for service types");
                var DropDown = new SelectElement(Element);

                var ServiceTypes = new List<string> { "Select Service Type", "Car Washing", "Tyre Checkup", "Oil Change" };
                foreach (var serviceType in ServiceTypes)
                {
                    var Found = DropDown.Options.Any(option => option.Text == serviceType);
                    Assert.IsTrue(Found, $"ServiceType dropdown doesn't contains the value {serviceType}");
                }
                DateTime dt = DateTime.ParseExact("2022-12-31", "yyyy-MM-dd", null);
                driver.SelectDropDownItemByText("ServiceType", "Car Washing");
                driver.SetElementText("CustomerName","Anita");
                driver.SetElementText("MobileNumber", "9600147821");
                driver.SetElementText("CarRegistrationNumber", "TN-88-C-7811");
                driver.SetElementText("BookingDate",dt.Date.ToShortDateString());

                driver.ClickElement("btnSubmit");

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Create booking page does not displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid booking object");                
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save booking details from Create Booking page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(5)]
        [Rollback]
        public void DisplayBookingRecords_Test()
        {
            driver.Navigate().GoToUrl(appURL);
            // driver.ClickElement("lnkIndex");
            try
            {         
                var Element = driver.FindElement(By.Id("BookingTable"));
                Assert.IsNotNull(Element, $"Index page doesn't displays the bookings records when data is there in database table");

                var context = new BookingContext();
                var BookingsCount = context.ServiceBookings.Count();
                var TableRowCount = driver.GetTableRowsCount("BookingTable")-1;
                Assert.AreEqual(BookingsCount, TableRowCount, $"Index page does not display records in tblBookings html table. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to display booking details from Index page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(6)]
        [Rollback]
        public void DisplayBookingRecordsFilter_Test()
        {
            driver.Navigate().GoToUrl(appURL);
            // driver.ClickElement("lnkIndex");
            try
            {
                var filter = driver.FindElement(By.Id("ServiceType"));
                filter.SendKeys("Car Washing");
                var btnFilter = driver.FindElement(By.Id("filter"));                
                btnFilter.Click();

                var Element = driver.FindElement(By.Id("BookingTable"));
                Assert.IsNotNull(Element, $"Index page doesn't displays the bookings records when data is there in database table");

                var context = new BookingContext();
                var BookingsCount = context.ServiceBookings.Where(s=>s.ServiceType == "Car Washing").Count();
                var TableRowCount = driver.GetTableRowsCount("BookingTable") - 1;
                Assert.AreEqual(BookingsCount, TableRowCount, $"Index page does not display filter records in tblBookings html table. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to display booking details from Index page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
