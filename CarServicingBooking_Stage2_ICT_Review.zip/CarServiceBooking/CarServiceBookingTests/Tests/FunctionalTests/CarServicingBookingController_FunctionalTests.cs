﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using CarServiceBookingTests.TestExtensions;
using CarServiceBooking.Models;

namespace CarServiceBookingTests.Tests.FunctionalTests
{
    [Order(4), TestFixture("CarServiceBooking", "CarServiceBooking.Controllers", "CarServiceController")]
    public class CarServicingBookingController_FunctionalTests : TestBase
    {
        public CarServicingBookingController_FunctionalTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }
        [Test, Order(1)]
        [TestCase("Create")]
        public void GetRequestTest(string methodName)
        {
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { });

                var result = (ViewResult)method.Invoke(GetTypeInstance(), new Type[] { });
                Assert.IsNotNull(result, $"{methodName} httpget action method of class {typeName} does not returns a view.");
                Assert.IsNotNull(result.ViewBag.ServiceType, $"{methodName} http get action of {typeName} controller does not stores ServiceType in the ViewBag.ServiceType property");
                Assert.IsInstanceOf<SelectList>(result.ViewBag.ServiceType, $"{methodName} http get action of {typeName} controller does not stores a SelectList in ViewBag's ServiceType property");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(2)]
        public void Create_ValidBooking_PostRequestTest()
        {
            string methodName = "Create";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(ServiceBooking) });
                var Obj = new ServiceBooking
                {
                    ServiceType = "Car Washing",
                    CustomerName = "Venkatesh",
                    MobileNumber = "7358259111",
                    CarRegistrationNumber = "PD-45-A-1258",
                    BookingDate = DateTime.ParseExact("2022-12-30", "yyyy-MM-dd", null)
                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} does not returns a view on saving a valid booking object.");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} does not stores a message in viewbag");
                Assert.AreEqual("Booking Successful", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} does not stores the message 'Booking Successful' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }
        [Test, Order(3)]
        public void Create_InvalidBooking_PostRequestTest()
        {
            try
            {
                var Obj = new ServiceBooking
                {
                    ServiceType = null,
                    CustomerName = null,
                    MobileNumber = null,
                    CarRegistrationNumber = null,
                    BookingDate = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "ServiceType", "Please Select Service Type" },
                    { "CustomerName", "Please Provide Customer Name" },
                    { "MobileNumber", "Please Provide Mobile Number" },
                    { "CarRegistrationNumber", "Please Provide Car Registration Number" },
                    { "BookingDate", "Please Provide Valid Date" }
                };

                var Results = ValidateModel(Obj);
                TestValidations("Required", RequiredValidations, Results);

                Obj.ServiceType = "Car Washing";
                Obj.CustomerName = "Annie";
                Obj.MobileNumber = "1234567890";
                Obj.CarRegistrationNumber = "ABCD-123";
                Obj.BookingDate = DateTime.ParseExact("2022-12-30", "yyyy-MM-dd", null);

                var RegularExpressionValidations = new Dictionary<string, string>
                {
                    { "MobileNumber", "Please Enter Valid Mobile Number" },
                    { "CarRegistrationNumber", "Please Provide valid RTO Number" }
                };

                Results = ValidateModel(Obj);
                TestValidations("RegularExpression", RegularExpressionValidations, Results);

                string methodName = "Create";
                var method = base.type.GetMethod(methodName, new Type[] { typeof(ServiceBooking) });

                Obj.ServiceType = "Car Washing";
                Obj.CustomerName = "Venkatesh";
                Obj.MobileNumber = "7358259111";
                Obj.CarRegistrationNumber = "PD-45-A-1258";
                Obj.BookingDate = DateTime.ParseExact("2019-12-30", "yyyy-MM-dd", null);

                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} does not returns a view on for diaplaying error for an valid booking object.");
                Assert.IsNotNull(result.ViewBag.BookingDateError, $"{methodName} httppost action method of class {typeName} does not stores a message in viewbag");
                Assert.AreEqual("Booking Date Should be greater than Current Date", result.ViewBag.BookingDateError, $"{methodName} httppost action method of class {typeName} does not stores the message 'Booking Date Should be greater than Current Date' in viewbag");
            }

            catch (Exception ex)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic - " + ex.Message);
            }
            void TestValidations(string validationName,
                                Dictionary<string, string> RequiredValidations,
                                IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"ServiceBooking entity doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }

            }
        }

        [Test, Order(4)]
        public void Test_IndexAction_CarServicingBookingList()
        {
            string methodName = "Index";
            BookingContext db = new BookingContext();
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { });
                var result = (ViewResult)method.Invoke(GetTypeInstance(), new Type[] { });
                var bookings = (IEnumerable<ServiceBooking>)result.Model;
                Assert.AreEqual(db.ServiceBookings.ToList().Count, bookings.ToList().Count);
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }
        private IList<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, validationResults, true);

            return validationResults;
        }

        [Test, Order(5)]
        public void Test_IndexFilterAction_CarServicingBookingList()
        {
            string methodName = "Index";
            BookingContext db = new BookingContext();
            db.ServiceBookings.RemoveRange(db.ServiceBookings);
            db.SaveChanges();

            List<ServiceBooking> list = new List<ServiceBooking>
            {
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Car Washing" },
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Tyre Checkup" },
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Tyre Checkup" },
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Oil Change" },
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Oil Change" },
                new ServiceBooking{ CustomerName="ABC", MobileNumber="9988776655", BookingDate=new DateTime(2021,01,01), CarRegistrationNumber="AA-11-A-5555" , ServiceType="Oil Change" }
            };
            db.ServiceBookings.AddRange(list);
            db.SaveChanges();

            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(string) });
                var result1 = (ViewResult)method.Invoke(GetTypeInstance(), new object[] { "Car Washing" });
                var bookings1 = (IEnumerable<ServiceBooking>)result1.Model;
                Assert.AreEqual(db.ServiceBookings.Where(s=>s.ServiceType== "Car Washing").ToList().Count, bookings1.ToList().Count);

                var result2 = (ViewResult)method.Invoke(GetTypeInstance(), new object[] { "Tyre Checkup" });
                var bookings2 = (IEnumerable<ServiceBooking>)result2.Model;
                Assert.AreEqual(db.ServiceBookings.Where(s => s.ServiceType == "Tyre Checkup").ToList().Count, bookings2.ToList().Count);

                var result3 = (ViewResult)method.Invoke(GetTypeInstance(), new object[] { "Oil Change" });
                var bookings3 = (IEnumerable<ServiceBooking>)result3.Model;
                Assert.AreEqual(db.ServiceBookings.Where(s => s.ServiceType == "Oil Change").ToList().Count, bookings3.ToList().Count);

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

    }
}
