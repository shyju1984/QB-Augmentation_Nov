﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

// Do not change the namespace
namespace CarServiceBooking.Models
{
     // Do not change the class name
    public class BookingContext:DbContext
    {
       // Implement the code here
    }
}