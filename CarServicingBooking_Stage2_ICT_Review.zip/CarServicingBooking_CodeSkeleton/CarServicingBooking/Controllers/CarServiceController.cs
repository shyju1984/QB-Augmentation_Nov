﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CarServiceBooking.Models;

// Do not change the namespace
namespace CarServiceBooking.Controllers
{
    //Do not change the class name
    public class CarServiceController : Controller
    {
        //Create the BookingContext object here

        // Do not change the method signature
        public ActionResult Index()
        {
            // Implement code here 
        }

        // Implement code here 

        // Do not change the method signature
        public ActionResult Create()
        {
            // Implement code here 
            return View();
        }
        
        // Do not change the method signature
        // Add attributes here
        public ActionResult Create(ServiceBooking serviceBooking)
        {
            // Implement code here
        }
        

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
