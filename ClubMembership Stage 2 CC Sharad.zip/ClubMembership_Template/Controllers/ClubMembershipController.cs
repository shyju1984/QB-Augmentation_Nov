using ClubMembershipApp.Data;
using ClubMembershipApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ClubMembershipApp.Controllers
{
    public class ClubMembershipController : Controller
    {
        static ClubDAO dao = new ClubDAO();
        
        //Implement action methods

    }
}
