﻿using NUnit.Framework;
using ClubMembership.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using DA = System.ComponentModel.DataAnnotations;
using ClubMembershipApp.Models;

namespace ClubMembership.Tests.StructuralTests
{
    [Order(1), TestFixture("ClubMembershipApp", "ClubMembershipApp.Models", "ClubMembership")]
    class ClubMembershipEntity_StructuralTests : TestBase
    {
        public ClubMembershipEntity_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {

        }

        [Test]
        public void PropertiesTest()
        {
            var CurrentProperty = new KeyValuePair<string, string>();
            try
            {
                var Properties = new Dictionary<string, string>
                {
                    { "Name", "String" },
                    { "Gender", "Gender" },
                    { "Mobile", "String" },
                    { "DateOfJoin", "DateTime" },                    
                    { "Bar", "Boolean" },
                    { "Golf", "Boolean" },
                    { "Swimming", "Boolean" },
                    { "Theatre", "Boolean" },
                    { "Billiards", "Boolean" },
                    { "Restaurant", "Boolean" },
                    { "ClubPlans", "ClubPlans" },
                    { "BillAmount", "Int32" }
                };
                foreach (var property in Properties)
                {
                    CurrentProperty = property;
                    var IsFound = HasProperty(property.Key, property.Value);
                    Assert.IsTrue(IsFound,
                                  Messages.GetPropertyNotFoundMessage(property.Key, property.Value));
                }

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: CurrentProperty.Key));
            }
        }

        [Test]
        public void CalculateBillMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("CalculateBill", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines CalculateBill() which accepts nothing as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check CalculateBill() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }


        [Test]
        public void DataAnnotationsTest()
        {
            (string propertyname, string attributename) PropertyUnderTest = ("", "");
            try
            {

                PropertyUnderTest.propertyname = "Name";
                PropertyUnderTest.attributename = "Required";
                RequiredAttributeTest("The Name field is required.");

                PropertyUnderTest.propertyname = "Gender";
                PropertyUnderTest.attributename = "Required";
                PropertyUnderTest.attributename = "Range";
                RangeAttributeTest(1, 3, "Must be selected");

                PropertyUnderTest.propertyname = "Mobile";
                PropertyUnderTest.attributename = "Required";
                RequiredAttributeTest("The Mobile field is required.");

                PropertyUnderTest.propertyname = "DateOfJoin";
                PropertyUnderTest.attributename = "Required";
                RequiredAttributeTest("The DateOfJoin field is required.");
                PropertyUnderTest.attributename = "Display";
                DisplayAttributeTest("Date Of Joining", "DateOfJoin does not have Display attribute");


                PropertyUnderTest.propertyname = "BillAmount";
                PropertyUnderTest.attributename = "Display";
                DisplayAttributeTest("Bill Amount", "BillAmount does not have Display attribute");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing {PropertyUnderTest.propertyname} for {PropertyUnderTest.attributename} attribute in {base.type.Name}");
            }

            #region LocalFunction_KeyAttributeTest
            void KeyAttributeTest()
            {
                string Message = $"Key attribute on {PropertyUnderTest.propertyname} of {base.type.Name} is not found";
                var attribute = GetAttributeFromProperty<DA.KeyAttribute>(PropertyUnderTest.propertyname, typeof(DA.KeyAttribute));
                Assert.IsNotNull(attribute, Message);
            }
            #endregion

            #region LocalFunction_RequiredAttributeTest
            void RequiredAttributeTest(string errorMessage)
            {
                string Message = $"Required attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.RequiredAttribute>(PropertyUnderTest.propertyname, typeof(DA.RequiredAttribute));
                Assert.IsNotNull(attribute, $"Required attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");
                Assert.AreEqual(errorMessage, attribute.ErrorMessage, $"{Message} ErrorMessage={errorMessage}");
            }
            #endregion

            #region LocalFunction_StringLengthAttributeTest
            void StringLengthAttributeTest(string errorMessage = null, int? maxLength = null, int? minLength = null)
            {
                string Message = $"StringLength attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.StringLengthAttribute>(
                                                                            PropertyUnderTest.propertyname,
                                                                            typeof(DA.StringLengthAttribute));

                Assert.IsNotNull(attribute, $"StringLength attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");

                if (errorMessage != null)
                    Assert.AreEqual(errorMessage, attribute.ErrorMessage, $"{Message} ErrorMessage={errorMessage}");
                if (maxLength != null)
                    Assert.AreEqual(maxLength.Value, attribute.MaximumLength, $"{Message} MaximumLength={errorMessage}");

                if (minLength != null)
                    Assert.AreEqual(minLength.Value, attribute.MinimumLength, $"{Message} MinimumLength={errorMessage}");
            }
            #endregion

            #region LocalFunction_RegularExpressionAttributeTest
            void RegularExpressionAttributeTest(string errorMessage)
            {
                string Message = $"RegularExpression attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.RegularExpressionAttribute>(
                                                        PropertyUnderTest.propertyname,
                                                        typeof(DA.RegularExpressionAttribute));
                Assert.IsNotNull(attribute, $"RegularExpression attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");
                Assert.AreEqual(errorMessage, attribute.ErrorMessage, $"{Message} ErrorMessage={errorMessage}");
            }
            #endregion

            #region LocalFunction_RangeAttributeTest
            void RangeAttributeTest(int min, int max, string errorMessage)
            {
                string Message = $"Range attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.RangeAttribute>(
                                                        PropertyUnderTest.propertyname,
                                                        typeof(DA.RangeAttribute));

                Assert.AreEqual(min, attribute.Minimum);
                Assert.AreEqual(max, attribute.Maximum);
                Assert.IsNotNull(attribute, $"Range attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");
                Assert.AreEqual(errorMessage, attribute.ErrorMessage, $"{Message} ErrorMessage={errorMessage}");
            }
            #endregion

            #region LocalFunction_DisplayNameAttributeTest
            void DisplayAttributeTest(string dispName, string errorMessage)
            {
                string Message = $"Display attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.DisplayAttribute>(
                                                        PropertyUnderTest.propertyname,
                                                        typeof(DA.DisplayAttribute));
                Assert.AreEqual(dispName, attribute.Name, $"{Message} ErrorMessage={errorMessage}");
                Assert.IsNotNull(attribute, $"Display attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");
            }
            #endregion

            #region LocalFunction_DisplayFormatAttributeTest
            void DisplayFormatAttributeTest(string dispFormat, string errorMessage)
            {
                string Message = $"Display Format attribute on {PropertyUnderTest.propertyname} of {base.type.Name} class doesnot have ";
                var attribute = GetAttributeFromProperty<DA.DisplayFormatAttribute>(
                                                        PropertyUnderTest.propertyname,
                                                        typeof(DA.DisplayFormatAttribute));
                Assert.AreEqual(dispFormat, attribute.DataFormatString, $"{Message} ErrorMessage={errorMessage}");
                Assert.IsNotNull(attribute, $"Display Format attribute not applied on {PropertyUnderTest.propertyname} of {base.type.Name} class");
            }
            #endregion
        }
    }
}
