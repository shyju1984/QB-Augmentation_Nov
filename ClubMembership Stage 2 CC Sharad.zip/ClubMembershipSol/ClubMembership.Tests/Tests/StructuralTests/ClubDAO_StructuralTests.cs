﻿using NUnit.Framework;
using ClubMembership.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClubMembershipApp.Models;

namespace ClubMembership.Tests.StructuralTests
{
    [Order(4), TestFixture("ClubMembershipApp", "ClubMembershipApp.Data", "ClubDAO")]
    class ClubDAO_StructuralTests : TestBase
    {
        public ClubDAO_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {

        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("Bills", "List`1");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "Bills", fieldType: "List<ClubMembership>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "Bills"));
            }
        }

        [Test]
        public void AddDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddData", new Type[] { typeof(ClubMembershipApp.Models.ClubMembership) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddData() which accepts ClubMembership entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void GetDataMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("GetData", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines GetData() which accepts no parameter");
                Assert.AreEqual(Method.ReturnType, typeof(List<ClubMembershipApp.Models.ClubMembership>), "Return type is not as expected");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check GetData() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

    }
}
