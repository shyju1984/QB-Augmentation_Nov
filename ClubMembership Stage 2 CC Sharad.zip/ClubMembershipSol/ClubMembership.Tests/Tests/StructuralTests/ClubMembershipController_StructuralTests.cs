﻿using NUnit.Framework;
using ClubMembershipApp.Models;
using ClubMembership.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace ClubMembership.Tests.StructuralTests
{
    [Order(5), TestFixture("ClubMembershipApp", "ClubMembershipApp.Controllers", "ClubMembershipController")]
    class ClubMembershipController_StructuralTests : TestBase
    {
        public ClubMembershipController_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {

        }
        [Test]
        public void InheritsFrom_ControllerTest()
        {
            Assert.AreEqual("Controller", type.BaseType.Name, $"{base.type.Name} doesnot inherits from Controller base class");
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("dao", "ClubDAO");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "dao", fieldType: "ClubDAO"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "dao"));
            }
        }

        [Test]
        public void Index_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Index", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Index action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Index action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Create_Get_ActionCreated_Test()
        {
            string methodName = "Create";
            
            try
            {
                var Method = base.type.GetMethod(methodName, new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines {methodName} action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check {methodName} action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Create_Post_ActionCreated_Test()
        {
            string methodName = "Create";
            string paramType = "ClubMembership";
            try
            {
                var Method = base.type.GetMethod(methodName, new Type[] { typeof(ClubMembershipApp.Models.ClubMembership) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines {methodName} action method which accepts {paramType} object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"{methodName} action is not marked with attributes to run on http post request in {base.type.Name} controller");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check {methodName} action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        
    }
}
