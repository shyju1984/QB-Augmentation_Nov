﻿using NUnit.Framework;
using ClubMembershipApp.Models;
using ClubMembership.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ClubMembershipApp.Data;
using ClubMembershipApp.Controllers;
using System.Collections.Specialized;
using System.Globalization;
using System.Web.Mvc;

namespace ClubMembership.Tests.FunctionalTests
{
    [TestFixture]
    class ClubMembershipController_FunctionalTests
    {
        Assembly assembly;
        Type className, dbContextclassName, modelClassName;

        [SetUp]
        public void Setup()
        {
            assembly = Assembly.Load("ClubMembershipApp");
            className = assembly.GetType("ClubMembershipApp.Controllers.ClubMembershipController");
            modelClassName = assembly.GetType("ClubMembershipApp.Models.ClubMembership");
            dbContextclassName = assembly.GetType("ClubMembershipApp.Data.ClubDAO");
        }

        [Test]

        [TestCase(ClubPlans.Family, true, true, true, true, true, true, 6608)]
        [TestCase(ClubPlans.Family, true, true, true, true, true, false, 5664)]
        [TestCase(ClubPlans.Family, true, true, true, true, false, false, 5074)]
        [TestCase(ClubPlans.Family, true, true, true, false, false, false, 4484)]
        [TestCase(ClubPlans.Family, true, true, false, false, false, false, 3540)]
        [TestCase(ClubPlans.Family, true, false, false, false, false, false, 2360)]
        [TestCase(ClubPlans.Family, false, false, false, false, false, false, 1180)]
        [TestCase(ClubPlans.Silver, true, true, true, true, true, true, 6903)]
        [TestCase(ClubPlans.Silver, true, true, true, true, true, false, 5959)]
        [TestCase(ClubPlans.Silver, true, true, true, true, false, false, 5369)]
        [TestCase(ClubPlans.Silver, true, true, true, false, false, false, 4779)]
        [TestCase(ClubPlans.Silver, true, true, false, false, false, false, 3835)]
        [TestCase(ClubPlans.Silver, true, false, false, false, false, false, 2655)]
        [TestCase(ClubPlans.Silver, false, false, false, false, false, false, 1475)]
        [TestCase(ClubPlans.Gold, true, true, true, true, true, true, 7493)]
        [TestCase(ClubPlans.Gold, true, true, true, true, true, false, 6549)]
        [TestCase(ClubPlans.Gold, true, true, true, true, false, false, 5959)]
        [TestCase(ClubPlans.Gold, true, true, true, false, false, false, 5369)]
        [TestCase(ClubPlans.Gold, true, true, false, false, false, false, 4425)]
        [TestCase(ClubPlans.Gold, true, false, false, false, false, false, 3245)]
        [TestCase(ClubPlans.Gold, false, false, false, false, false, false, 2065)]
        [TestCase(ClubPlans.Platinum, true, true, true, true, true, true, 7788)]
        [TestCase(ClubPlans.Platinum, true, true, true, true, true, false, 6844)]
        [TestCase(ClubPlans.Platinum, true, true, true, true, false, false, 6254)]
        [TestCase(ClubPlans.Platinum, true, true, true, false, false, false, 5664)]
        [TestCase(ClubPlans.Platinum, true, true, false, false, false, false, 4720)]
        [TestCase(ClubPlans.Platinum, true, false, false, false, false, false, 3540)]
        [TestCase(ClubPlans.Platinum, false, false, false, false, false, false, 2360)]


        [Order(1)]
        public void ClubMembership_CalculateBill_ShouldCalculateCorrectValue(ClubPlans plan,
                                                bool bar, bool golf, bool swimming,
                                                bool theatre, bool billiards, bool restaurant, int clubBill)
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = modelClassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("CalculateBill"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'CalculateBill' NOT implemented OR check spelling");

                    ClubMembershipApp.Models.ClubMembership bill = new ClubMembershipApp.Models.ClubMembership
                    {
                        Name = "Anubhav",
                        Mobile = "7766889955",
                        Gender = Gender.Male,
                        DateOfJoin = new DateTime(2020, 10, 11),
                        ClubPlans = plan,
                        Bar = bar,
                        Golf = golf,
                        Swimming = swimming,
                        Theatre = theatre,
                        Billiards= billiards,
                        Restaurant= restaurant,
                        BillAmount = 0
                    };

                    object[] parameters = new object[] { };
                    testMethod.Invoke(bill, parameters);

                    Assert.AreEqual(clubBill, bill.BillAmount);
                }
                else
                    Assert.Fail("No class with the name 'ClubDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("CalculateBill not returning correct value");
            }
        }


        [Test]
        [Order(2)]
        public void DAO_GetData_ShouldGetData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            ClubDAO dao = new ClubDAO();

            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("GetData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'GetData' NOT implemented OR check spelling");

                    object[] parameters = new object[] { };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;
                    int user1Count = dao.GetData().Where(u => u.Name == "Anubhav").Count();
                    int user2Count = dao.GetData().Where(u => u.Name == "Manisha").Count();

                    Assert.AreEqual(countAfter, 3);
                    Assert.AreEqual(user1Count, 1);
                    Assert.AreEqual(user2Count, 1);
                }
                else
                    Assert.Fail("No class with the name 'ClubDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Getting ClubMembership data from collection failed. Is original data available?");
            }
        }

        [Test]
        [Order(3)]
        public void DAO_AddData_ShouldAddData()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
            ClubDAO dao = new ClubDAO();
            ClubMembershipApp.Models.ClubMembership bill = new ClubMembershipApp.Models.ClubMembership
            {
                Name = "BBB",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                ClubPlans = ClubPlans.Gold,
                Bar = true,
                Golf = false,
                Swimming = false,
                Theatre = true,
                Billiards = false,
                Restaurant = true,
                BillAmount = 0
            };
            try
            {
                if (dbContextclassName != null)
                {
                    MethodInfo[] testMethods = dbContextclassName.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.Name.Equals("AddData"))
                        {
                            testMethod = item;
                            break;
                        }
                    }

                    Assert.IsNotNull(testMethod, "Method 'AddData' NOT implemented OR check spelling");

                    int countBefore = dao.GetData().Count;
                    object[] parameters = new object[] { bill };
                    testMethod.Invoke(dao, parameters);
                    int countAfter = dao.GetData().Count;

                    Assert.AreEqual(countAfter, countBefore + 1);
                }
                else
                    Assert.Fail("No class with the name 'ClubDAO' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data to the collection failed.");
            }
        }


        //////----------------------------- Check ClubMembershipController -------------------------------------------

        [Test]
        [Order(4)]
        public void IndexAction_When_Invoked_Return_SortedList()
        {
            //Arrange 
            ClubDAO dao = new ClubDAO();
            ClubDAO.Bills.Clear();
            ClubMembershipApp.Models.ClubMembership bill1 = new ClubMembershipApp.Models.ClubMembership
            {
                Name = "AAA",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                ClubPlans = ClubPlans.Gold,
                Bar = true,
                Golf = false,
                Swimming = false,
                Theatre = true,
                Billiards = false,
                Restaurant = true,
                BillAmount = 0
            };
            ClubMembershipApp.Models.ClubMembership bill2 = new ClubMembershipApp.Models.ClubMembership
            {
                Name = "CCC",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                ClubPlans = ClubPlans.Gold,
                Bar = true,
                Golf = false,
                Swimming = false,
                Theatre = true,
                Billiards = false,
                Restaurant = true,
                BillAmount = 0
            };
            ClubMembershipApp.Models.ClubMembership bill3 = new ClubMembershipApp.Models.ClubMembership
            {
                Name = "BBB",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                ClubPlans = ClubPlans.Gold,
                Bar = true,
                Golf = false,
                Swimming = false,
                Theatre = true,
                Billiards = false,
                Restaurant = true,
                BillAmount = 0
            };
            ClubDAO.Bills.Add(bill1);
            ClubDAO.Bills.Add(bill2);
            ClubDAO.Bills.Add(bill3);

            try
            {
                if (className != null)
                {
                    MethodInfo testMethod = className.GetMethods().Where(x => x.Name.Equals("Index")
                                           && x.GetParameters().Count() == 0
                                           && x.ReturnType == typeof(ActionResult)).FirstOrDefault();

                    Assert.IsNotNull(testMethod,
                        "Action 'Index' GET NOT implemented with return type 'ActionResult' OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });

                    var viewResult = (ViewResult)testMethod.Invoke(classObject, new object[] { });
                    var list = (IEnumerable<ClubMembershipApp.Models.ClubMembership>)viewResult.ViewData.Model;

                    Assert.AreEqual(3, list.Count(),
                        "Verify whether you fetched the data from the collection correctly or not");

                    //to test list is sorted
                    var dataList = dao.GetData().OrderBy(b => b.Name).ToList();

                    bool isSorted = dataList.SequenceEqual(list);
                    Assert.That(isSorted, "List should be sorted properly");
                }
                else
                    Assert.Fail("No class with the name 'ClubMembershipController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown. Please check the application logic");
            }
        }

        [Test]
        [Order(5)]
        public void CreateBill_Should_Be_Valid_When_All_Properties_Correct()
        {
            //Arrange 
            var allBindings = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

            var gymBillingController = new ClubMembershipController();
            ClubDAO db = new ClubDAO();

            ClubMembershipApp.Models.ClubMembership bill = new ClubMembershipApp.Models.ClubMembership
            {
                Name = "DDD",
                Mobile = "7766889955",
                Gender = Gender.Male,
                DateOfJoin = new DateTime(2020, 10, 11),
                ClubPlans = ClubPlans.Gold,
                Bar = true,
                Golf = false,
                Swimming = false,
                Theatre = true,
                Billiards = false,
                Restaurant = true,
                BillAmount = 0
            };

            //Initialize ModelState 
            var modelBinder = new ModelBindingContext()
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(
                                  () => bill, bill.GetType()),
                ValueProvider = new NameValueCollectionValueProvider(
                                    new NameValueCollection(), CultureInfo.InvariantCulture)
            };
            var binder = new DefaultModelBinder().BindModel(
                             new ControllerContext(), modelBinder);

            try
            {
                className = assembly.GetType("ClubMembershipApp.Controllers.ClubMembershipController");

                if (className != null)
                {
                    MethodInfo[] testMethods = className.GetMethods(allBindings);
                    MethodInfo testMethod = default;

                    foreach (var item in testMethods)
                    {
                        if (item.CustomAttributes.Count() > 0)
                        {
                            if (item.IsGenericMethod == false && item.Name.Equals("Create")
                                && item.CustomAttributes.First().AttributeType
                                .Name.Equals("HttpPostAttribute"))
                            {
                                testMethod = item;
                                break;
                            }
                        }
                    }

                    Assert.IsNotNull(testMethod, "Action 'Create' NOT implemented OR check spelling");

                    ConstructorInfo classConstructor = className.GetConstructor(Type.EmptyTypes);
                    object classObject = classConstructor.Invoke(new object[] { });
                    ((Controller)classObject).ModelState.Clear();
                    ((Controller)classObject).ModelState.Merge(modelBinder.ModelState);

                    Assert.IsTrue(((Controller)classObject).ModelState.IsValid, "Verify the model state values");
                }
                else
                    Assert.Fail("No class with the name 'ClubMembershipController' is implemented OR Did you change the class name");
            }
            catch (Exception)
            {
                Assert.Fail("Adding new data failed. verify the state of model object");
            }
        }
    }
}
