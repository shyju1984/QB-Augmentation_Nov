﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System;
using System.Diagnostics;
using System.IO;

namespace ClubMembership.Tests.UITests
{
    [TestFixture]
    public abstract class IISServerTest
    {
        private const int WebAppPort = 51509;

        private Process _webHostProcess;
        private readonly string _applicationName;

        protected IISServerTest(string applicationName)
        {
            _applicationName = applicationName;
        }

        [SetUp]
        public void TestInitialize()
        {
            // Start IISExpress here
            StartIIS();

            Initialize();
        }

        [TearDown]
        public void TestCleanup()
        {
            Cleanup();
            // Make sure that IISExpress is stopped here
            if (_webHostProcess.HasExited == false)
            {
                _webHostProcess.Kill();
            }
        }

        public abstract void Initialize();

        public abstract void Cleanup();

        private void StartIIS()
        {
            var applicationPath = GetApplicationPath(_applicationName);
            var key = Environment.Is64BitOperatingSystem ? "programfiles(x86)" : "programfiles";
            var programfiles = Environment.GetEnvironmentVariable(key);

            var iisExpressStartInfo = new ProcessStartInfo
            {
                WindowStyle = ProcessWindowStyle.Normal,
                ErrorDialog = true,
                LoadUserProfile = true,
                CreateNoWindow = false,
                UseShellExecute = false,
                Arguments = String.Format("/path:\"{0}\" /port:{1}", applicationPath, WebAppPort),
                FileName = string.Format("{0}\\IIS Express\\iisexpress.exe", programfiles)
            };
            _webHostProcess = Process.Start(iisExpressStartInfo);
        }

        protected virtual string GetApplicationPath(string applicationName)
        {
            var solutionFolder = Path.GetDirectoryName(Path.GetDirectoryName(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)));
            return Path.Combine(solutionFolder, applicationName);
        }

        public string GetAbsoluteUrl(string relativeUrl)
        {
            return String.Format(@"http://localhost:{0}/{1}", WebAppPort, relativeUrl);
        }
    }

    public abstract class SeleniumTest : IISServerTest
    {
        private RemoteWebDriver _remoteWebDriver;
        protected IWebDriver WebDriver
        {
            get { return _remoteWebDriver; }
        }

        protected SeleniumTest(string applicationName) : base(applicationName)
        {
        }

        public override void Initialize()
        {
            _remoteWebDriver = new ChromeDriver();
        }

        public override void Cleanup()
        {
            _remoteWebDriver.Dispose();
        }
    }

    [TestFixture]
    public class ClubMembershipUITests : SeleniumTest, IDisposable
    {
        public ClubMembershipUITests() : base("Club Membership")
        {

        }


        [Test]
        [Order(1)]
        public void Test_IndexView()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("ClubMembership/Index"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("Club Membership"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));

                Assert.AreEqual("Index - Club Membership", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Mobile')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date Of Joining')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Bar')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Golf')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Swimming')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Theatre')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Billiards')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Restaurant')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Club Plan')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Bill Amount')]"));

                var link = WebDriver.FindElement(By.LinkText("Create New"));
                link.Click();
                Assert.AreEqual("Create - Club Membership", WebDriver.Title);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }


        [Test]
        [Order(2)]
        public void Test_CreateView()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("ClubMembership/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("Club Membership"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));

                Assert.AreEqual("Create - Club Membership", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Mobile']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date Of Joining']"));

                WebDriver.FindElement(By.XPath("//*[text() = 'Bar']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Golf']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Swimming']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Theatre']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Billiards']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Restaurant']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Club Plan']"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                btnSubmit.Click();
                WebDriver.FindElement(By.XPath("//*[text() = 'The Name field is required.']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Must be selected']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'The Mobile field is required.']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'The DateOfJoin field is required.']"));

                int count = WebDriver.FindElements(By.XPath("//*[text() = 'Must be selected']")).Count;
                Assert.AreEqual(2, count, "2 drop downs must be selected ");

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(3)]
        public void Test_CreateViewValidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("ClubMembership/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("Club Membership"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));

                Assert.AreEqual("Create - Club Membership", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Mobile']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date Of Joining']"));

                WebDriver.FindElement(By.XPath("//*[text() = 'Bar']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Golf']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Swimming']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Theatre']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Billiards']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Restaurant']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Club Plan']"));

                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                WebDriver.FindElement(By.Id("Name")).Clear();
                WebDriver.FindElement(By.Id("Name")).SendKeys("ABC");

                WebDriver.FindElement(By.Id("Gender")).SendKeys("Male");

                WebDriver.FindElement(By.Id("Mobile")).Clear();
                WebDriver.FindElement(By.Id("Mobile")).SendKeys("9988776655");

                WebDriver.FindElement(By.Id("DateOfJoin")).Clear();
                WebDriver.FindElement(By.Id("DateOfJoin")).SendKeys("11-11-2020");

                WebDriver.FindElement(By.Id("ClubPlans")).SendKeys("Family");


                btnSubmit = WebDriver.FindElement(By.Id("submit"));
                btnSubmit.Click();

                Assert.AreEqual("Index - Club Membership", WebDriver.Title);
                                
                heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Name')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Gender')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Mobile')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Date Of Joining')]"));

                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Bar')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Golf')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Swimming')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Theatre')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Billiards')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Restaurant')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Club Plan')]"));
                WebDriver.FindElement(By.XPath("//th[contains(text(), 'Bill Amount')]"));

                var name = WebDriver.FindElements(By.XPath("//td[contains(text(),'ABC')]"));
                Assert.AreEqual(name.Count, 1);
            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        [Test]
        [Order(4)]
        public void Test_CreateViewInvalidData()
        {
            WebDriver.Navigate().GoToUrl(GetAbsoluteUrl("ClubMembership/Create"));
            //Maximize the window
            WebDriver.Manage().Window.Maximize();

            try
            {
                WebDriver.FindElement(By.LinkText("Club Membership"));
                WebDriver.FindElement(By.LinkText("Show All Data"));
                WebDriver.FindElement(By.LinkText("Create"));

                Assert.AreEqual("Create - Club Membership", WebDriver.Title);

                string heading = WebDriver.FindElement(By.TagName("h2")).GetCssValue("color");
                Assert.AreEqual(heading, "rgba(0, 0, 255, 1)");

                WebDriver.FindElement(By.XPath("//*[text() = 'Name']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Gender']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Mobile']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Date Of Joining']"));

                WebDriver.FindElement(By.XPath("//*[text() = 'Bar']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Golf']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Swimming']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Theatre']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Billiards']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Restaurant']"));
                WebDriver.FindElement(By.XPath("//*[text() = 'Club Plan']"));
                IWebElement btnSubmit = WebDriver.FindElement(By.Id("submit"));

                WebDriver.FindElement(By.Id("Name")).Clear();
                WebDriver.FindElement(By.Id("Name")).SendKeys("ABC");

                WebDriver.FindElement(By.Id("Gender")).SendKeys("Male");

                WebDriver.FindElement(By.Id("Mobile")).Clear();
                WebDriver.FindElement(By.Id("Mobile")).SendKeys("9988776655");

                WebDriver.FindElement(By.Id("DateOfJoin")).Clear();
                WebDriver.FindElement(By.Id("DateOfJoin")).SendKeys("11-11-2020");

                btnSubmit = WebDriver.FindElement(By.Id("submit"));
                btnSubmit.Click();

                Assert.AreEqual("Create - Club Membership", WebDriver.Title);

                WebDriver.FindElement(By.XPath("//*[text() = 'Must be selected']"));

            }
            catch (Exception)
            {
                Assert.Fail("Exception should not occur here. Implementations are not done as required");
            }
        }

        public void Dispose()
        {
            WebDriver.Quit();
            WebDriver.Dispose();
        }
    }
}
