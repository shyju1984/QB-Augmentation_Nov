﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ClubMembershipApp.Models
{
    public enum Gender { Select, Male, Female, Others }
    public enum ClubPlans { Select, Family, Silver, Gold, Platinum };

    public class ClubMembership
    {
        [Required(ErrorMessage = "The Name field is required.")]
        public string Name { get; set; }
        [Required]
        [Range(1, 3, ErrorMessage = "Must be selected")]
        public Gender Gender { get; set; }

        [Required(ErrorMessage = "The Mobile field is required.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "The DateOfJoin field is required.")]
        [Display(Name = "Date Of Joining")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfJoin { get; set; }

        //Services 
        public bool Bar { get; set; }
        public bool Golf { get; set; }
        public bool Swimming { get; set; }
        public bool Theatre { get; set; }
        public bool Billiards { get; set; }
        public bool Restaurant { get; set; }        

        [Required]
        [Display(Name = "Club Plan")]
        [Range(1, 4, ErrorMessage = "Must be selected")]
        public ClubPlans ClubPlans { get; set; }

        [Display(Name = "Bill Amount")]
        public int BillAmount { get; set; }

        public void CalculateBill()
        {
            BillAmount = 0;

            int monthlyServices = 0;

            if (Bar == true) monthlyServices += 1000;
            if (Golf == true) monthlyServices += 1000;            
            if (Swimming == true) monthlyServices += 800;            
            if (Theatre == true) monthlyServices += 500;
            if (Billiards == true) monthlyServices += 500;
            if (Restaurant == true) monthlyServices += 800;                   

            BillAmount += monthlyServices + 500;

            int servicesCost = 0;
            switch ((int)ClubPlans)
            {
                case 1:
                    servicesCost = 500;
                    break;
                case 2:
                    servicesCost = 750;
                    break;
                case 3:
                    servicesCost = 1250;
                    break;
                case 4:
                    servicesCost = 1500;
                    break;
            }
            BillAmount += servicesCost;

            int gst = (int)(BillAmount * 18.0 / 100);
            BillAmount += gst;
        }
    }
}

