using ClubMembershipApp.Data;
using ClubMembershipApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ClubMembershipApp.Controllers
{
    public class ClubMembershipController : Controller
    {
        static ClubDAO dao = new ClubDAO();
        public ActionResult Index()
        {
            var data = dao.GetData().OrderBy(b => b.Name).ToList();
            return View(data);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(ClubMembership clubMembership)
        {
            if (ModelState.IsValid)
            {
                clubMembership.CalculateBill();
                dao.AddData(clubMembership);
                return RedirectToAction("Index");
            }
            else
                return View();
        }

    }
}
