﻿using ClubMembershipApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClubMembershipApp.Data
{
    public class ClubDAO
    {
        public static List<ClubMembership> Bills = null;

        public ClubDAO()
        {
            Bills = new List<ClubMembership>
            {
                new ClubMembership{  Name ="Anubhav", Mobile = "7766889955", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,10,11),
                                         ClubPlans  = ClubPlans.Family,
                                          Bar = true, Golf=true, Swimming=true,
                                             Theatre=true, Billiards=true, Restaurant=true, BillAmount=6608
                            },
                new ClubMembership{  Name ="Suresh", Mobile = "7687987665", Gender =  Gender.Male, DateOfJoin=new DateTime(2020,09,05),
                                         ClubPlans  = ClubPlans.Silver,
                                             Bar = true, Golf=true, Swimming=true,
                                             Theatre=false, Billiards=false, Restaurant=false, BillAmount=4779
                            },
                new ClubMembership{  Name ="Manisha", Mobile = "9758674859", Gender =  Gender.Female, DateOfJoin=new DateTime(2020,10,05),
                                         ClubPlans  = ClubPlans.Platinum,
                                             Bar = false, Golf=false, Swimming=false,
                                             Theatre=true, Billiards=true, Restaurant=true, BillAmount=4484
                            }
            };
        }

        public List<ClubMembership> GetData()
        {
            return Bills;
        }

        public void AddData(ClubMembership clubMembership)
        {

            Bills.Add(clubMembership);
        }
    }
}