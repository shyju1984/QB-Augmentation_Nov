﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace PropertyLocatorApp.Models
{
    // Do not change the class name
    public class PropertyLocatorRepository
    {
        // Create fields here

        public PropertyLocatorRepository()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public bool AddProperty(PropertyLocator property)
        {
            bool IsAdded = false;

            // Implement code here 

            return IsAdded;
        }

        // Do not change the method signature
        public List<PropertyLocator> Search(string city, string propertyCategory)
        {
            // Implement code here 
        }

        // Do not change the method signature
        public List<PropertyLocator> ListProperties()
        {
            // Implement code here 
        }
    }
}