﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PropertyLocatorApp.Models
{
    public class SearchPropertyViewModel
    {
        [Required(ErrorMessage = "Please provide city name to search")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")]
        public string PropertyCity { get; set; }

        [Required(ErrorMessage = "Please provide property category to search")]
        public string PropertyCategory { get; set; }

        public List<PropertyLocator> Properties { get; set; }
    }
}