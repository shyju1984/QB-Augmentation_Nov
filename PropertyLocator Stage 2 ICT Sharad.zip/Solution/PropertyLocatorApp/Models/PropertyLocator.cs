﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PropertyLocatorApp.Models
{
    public class PropertyLocator
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide property detail")]
        [StringLength(25, ErrorMessage = "Property detail cannot exceed 25 characters")]
        [Display(Name= "Property Detail")]
        public string PropertyDetail { get; set; }

        [Required(ErrorMessage = "Please provide property category")]
        [StringLength(30)]
        [Display(Name ="Property Category")]
        public string PropertyCategory { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Available Date")]
        public DateTime AvailableDate { get; set; }

        [Required(ErrorMessage = "Please provide mobile number")]
        [RegularExpression("^[\\d]{10}$", ErrorMessage = "Please enter 10 digit mobile number")]
        [StringLength(10)]
        [Display(Name = "Contact Mobile No.")]
        public string ContactMobileNo { get; set; }

        [Required(ErrorMessage = "Please provide city name")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")]
        [Display(Name = "Property City")]
        public string PropertyCity { get; set; }

    }
}