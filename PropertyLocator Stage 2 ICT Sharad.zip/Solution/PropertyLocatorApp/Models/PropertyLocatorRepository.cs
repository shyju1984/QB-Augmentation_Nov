﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PropertyLocatorApp.Models
{
    public class PropertyLocatorRepository
    {
        PropertyLocatorContext context;

        public PropertyLocatorRepository()
        {
            context = new PropertyLocatorContext();
        }

        public bool AddProperty(PropertyLocator property)
        {
            bool IsAdded = false;

            var isPropertyPresent = context.Properties.SingleOrDefault(d => d.ContactMobileNo == property.ContactMobileNo
                                                        && d.PropertyCity == property.PropertyCity
                                                        && property.PropertyDetail == property.PropertyDetail);
            if (isPropertyPresent != null)
                return IsAdded;

            context.Properties.Add(property);
            IsAdded = context.SaveChanges() > 0;

            return IsAdded;
        }

        public List<PropertyLocator> Search(string city, string propertyCategory)
        {
            var PropertiesList = from property in context.Properties
                             where property.PropertyCity.ToLower().Contains(city.ToLower())
                             && property.PropertyCategory.Equals(propertyCategory)
                             select property;
            return PropertiesList.ToList();
        }

        public List<PropertyLocator> ListProperties()
        {
            var PropertiesList = from property in context.Properties
                                   select property;
            return PropertiesList.ToList();
        }
    }
}