﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PropertyLocatorApp.Models
{
    public class PropertyLocatorContext : DbContext
    {
        public PropertyLocatorContext() : base("PropertyLocatorConnection")
        {

        }

        public DbSet<PropertyLocator> Properties { get; set; }
    }
}