﻿using PropertyLocatorApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PropertyLocatorApp.Controllers
{
    public class PropertyLocatorController : Controller
    {
        PropertyLocatorRepository repository;
        static List<string> PropertyCategories = new List<string> 
        { "Kothi", "Flat", "Society Flat", "Bungalow", "Residential Land", "Govt Scheme", "Auction"};
        public PropertyLocatorController()
        {
            repository = new PropertyLocatorRepository();
        }

        public ActionResult Index()
        {            
            var list = repository.ListProperties();
            return View(list);
        }

        public ActionResult Add()
        {        
            ViewBag.PropertyCategories = new SelectList(PropertyCategories);
            return View();
        }

        [HttpPost]
        public ActionResult Add(PropertyLocator property)
        {            
            ViewBag.PropertyCategories = new SelectList(PropertyCategories);

            if (!ModelState.IsValid)
                return View(property);
 
            var Added = repository.AddProperty(property);
            if (Added)
                ViewBag.Message = "Property details added successfully";
            else
                ViewBag.Message = "Failed to add property details. Try again later";

            return View(property);
        }

        public ActionResult Search()
        {            
            ViewBag.PropertyCategories = new SelectList(PropertyCategories);
            return View(new SearchPropertyViewModel());
        }

        [HttpPost]
        public ActionResult Search(SearchPropertyViewModel model)
        {
            ViewBag.PropertyCategories = new SelectList(PropertyCategories);

            if (!ModelState.IsValid)
                return View(model);

            model.Properties = repository.Search(model.PropertyCity, model.PropertyCategory);
            return View(model);
        }
    }
}