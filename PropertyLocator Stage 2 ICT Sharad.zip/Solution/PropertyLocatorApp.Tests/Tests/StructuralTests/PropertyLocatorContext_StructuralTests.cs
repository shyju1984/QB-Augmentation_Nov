﻿using NUnit.Framework;
using PropertyLocatorApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyLocatorApp.StructuralTests
{
    
    [Order(2), TestFixture("PropertyLocatorApp", "PropertyLocatorApp.Models", "PropertyLocatorContext")]
    public class PropertyLocatorContext_StructuralTests : TestBase
    {
        public PropertyLocatorContext_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void DbSet_Property_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("Properties", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("Properties", "DbSet<Property>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "Properties"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} doesnot inherits from DbContext base class");
        }
    }
}
