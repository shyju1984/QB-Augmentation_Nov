﻿using NUnit.Framework;
using PropertyLocatorApp.Models;
using PropertyLocatorApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyLocatorApp.StructuralTests
{
     
     [Order(4), TestFixture("PropertyLocatorApp", "PropertyLocatorApp.Models", "PropertyLocatorRepository")]
    public class PropertyLocatorRepository_StructuralTests : TestBase
    {
        public PropertyLocatorRepository_StructuralTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("context", "PropertyLocatorContext");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "context", fieldType: "PropertyLocatorContext"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "context"));
            }
        }

        [Test]
        public void AddProperty_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddProperty", new Type[] { typeof(PropertyLocator) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddProperty() which accepts Property entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddProperty() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(string), typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search() method which accepts 2  string parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void ListProperties_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("ListProperties", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines ListCategories() method which accepts no parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check ListCategories() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
