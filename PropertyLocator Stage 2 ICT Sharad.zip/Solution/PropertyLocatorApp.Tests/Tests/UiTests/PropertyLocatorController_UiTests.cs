﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using PropertyLocatorApp.Models;
using PropertyLocatorApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace PropertyLocatorApp.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    public class PropertyLocatorController_UiTests
    {
        private readonly string appURL;
        private IWebDriver driver;

        public PropertyLocatorController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }


        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Add", title, $"Application doesnot start with the page titled Add");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(2)]
        public void AddProperty_SearchProperty_NavigationLinksTest()
        {
            try
            {
                driver.ClickElement("lnkSearch");
                string SearchPageTitle = driver.Title;

                driver.ClickElement("lnkAdd");
               
                string AddPageTitle = driver.Title;


                StringAssert.Contains("Add", AddPageTitle, $"Application doesnot navigates to Add page on clicking Add Property hyperlink");

                StringAssert.Contains("Search", SearchPageTitle, $"Application doesnot navigates to Search page on clicking Search Property hyperlink");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Add Property and Search property navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }


        [Test, Order(3)]
        [Rollback]
        public void AddProperty_Test()
        {
            try
            {
                var ExpectedSuccessMessage = "Property details added successfully";
                var ExpectedFailureMessage = "Failed to add property details. Try again later";
                driver.ClickElement("lnkAdd");
                
                var Element = driver.FindElement(By.Id("PropertyCategory"));
                Assert.IsNotNull(Element, $"Add Properties page doesn't displays the dropdown list for property category types");
                var DropDown = new SelectElement(Element);
               
                var PropertyCategories = new List<string> { "Select Property Category", "Kothi", "Flat", "Society Flat", "Bungalow", "Residential Land", "Govt Scheme", "Auction" };
                foreach (var group in PropertyCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"PropertyCategories dropdown doesn't contains the value {group}");
                }
                string MobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8);
                driver.SetElementText("PropertyDetail", "abcde");
                driver.SetElementText("AvailableDate", DateTime.Now.Date.ToShortDateString());
                driver.SetElementText("ContactMobileNo", MobileNo);
                driver.SetElementText("PropertyCity", "Pune");
                driver.SelectDropDownItemByText("PropertyCategory", "Flat");

                driver.ClickElement("btnSubmit");
               
                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Add property page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid property object");

                driver.ClickElement("btnSubmit");
                
                ActualMessage= driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedFailureMessage, ActualMessage, $"Add property page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag on trying to save a duplicate property object");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save property details from Add Property page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        public void SearchProperty_Test()
        {
            try
            {
                var WelcomeMessage = "Provide the search criteria to start looking for a property";
                var notFound = "No property found with the given search criteria";
                driver.ClickElement("lnkSearch");             
             

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(WelcomeMessage, ActualMessage, $"Search property page doesnot displays the message - '{WelcomeMessage}' in h2 tag on opening the page");

                var Element = driver.FindElement(By.Id("PropertyCategory"));
                Assert.IsNotNull(Element, $"Search Properties page doesn't displays the dropdown list for property category types");
                var DropDown = new SelectElement(Element);

                var PropertyCategories = new List<string> {"Select Property Category", "Kothi", "Flat", "Society Flat", "Bungalow", "Residential Land", "Govt Scheme", "Auction" };
                foreach (var group in PropertyCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"PropertyCategories dropdown doesn't contains the value {group}");
                }

                
                driver.SetElementText("PropertyCity", "Test City");
                driver.SelectDropDownItemByText("PropertyCategory", "Flat");
                driver.ClickElement("btnSubmit");

                ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(notFound, ActualMessage, $"Search property page doesnot displays the message - '{notFound}' in h2 tag when there are no Properties for given search criteria");

                driver.SetElementText("PropertyCity", "Noida");
                driver.SelectDropDownItemByText("PropertyCategory", "Kothi");
                driver.ClickElement("btnSubmit");

                var context = new PropertyLocatorContext();
                var counts = context.Properties.Count(d => d.PropertyCity.ToLower() == "noida" && d.PropertyCategory == "kothi");

                var TableRowCount = driver.GetTableRowsCount("tblProperties") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search property page doesnot includes all the records in tblProperties html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search property details from Search Property page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(5)]
        public void Index_Test()
        {
            try
            {
                driver.ClickElement("lnkIndex");

                var context = new PropertyLocatorContext();                
                var counts = context.Properties.Count();

                var TableRowCount = driver.GetTableRowsCount("tblProperties") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search property page doesnot includes all the records in tblProperties html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search property details from Search Property page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
