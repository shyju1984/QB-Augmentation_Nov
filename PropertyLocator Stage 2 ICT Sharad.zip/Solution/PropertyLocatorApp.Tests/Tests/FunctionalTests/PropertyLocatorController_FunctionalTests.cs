﻿using NUnit.Framework;
using PropertyLocatorApp.Models;
using PropertyLocatorApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace PropertyLocatorApp.FunctionalTests
{
    [Order(7), TestFixture("PropertyLocatorApp", "PropertyLocatorApp.Controllers", "PropertyLocatorController")]
    public class PropertyLocatorController_FunctionalTests : TestBase
    {
        public PropertyLocatorController_FunctionalTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        [TestCase("Add")]
        [TestCase("Search")]
        [TestCase("Index")]
        public void GetRequestTest(string methodName)
        {
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { });

                var result = (ViewResult)method.Invoke(GetTypeInstance(), new Type[] { });
                Assert.IsNotNull(result, $"{methodName} httpget action method of class {typeName} doesnot returns a view.");

                Assert.IsNotNull(result.ViewBag.PropertyCategories, $"{methodName} http get action of {typeName} controller doesnot stores PropertyCategories in the ViewBag.PropertyCategories property");

                Assert.IsInstanceOf<SelectList>(result.ViewBag.PropertyCategories, $"{methodName} http get action of {typeName} controller doesnot stores a SelectList in ViewBag's PropertyCategories property");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(2)]
        public void Add_ValidProperty_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(PropertyLocator) });
                var Obj = new PropertyLocator
                {
                    PropertyDetail = "Property",
                    PropertyCategory = "Flat",
                    AvailableDate = DateTime.Now,
                    PropertyCity = "IndiaCity",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on saving a valid property object.");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Property details added successfully", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Property details added successfully' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(3)]
        public void Add_DuplicateProperty_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(PropertyLocator) });
                var context = new PropertyLocatorContext();
                var Obj = context.Properties.First();
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on trying to save a duplicate property object");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Failed to add property details. Try again later", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Failed to add property details. Try again later' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(4)]
        public void Add_InvalidProperty_PostRequestTest()
        {
            try
            {
                var Obj = new PropertyLocator
                {
                    PropertyDetail = null,
                    PropertyCategory = null,
                    AvailableDate = DateTime.Now,
                    PropertyCity = null,
                    ContactMobileNo = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "PropertyDetail", "Please provide property detail" },
                    { "PropertyCategory", "Please provide property category" },
                    { "ContactMobileNo", "Please provide mobile number" },
                    { "PropertyCity", "Please provide city name" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "PropertyDetail", "Property detail cannot exceed 25 characters" },
                    { "PropertyCity", "City name must not exceed 25 characters" }
                };

                Obj.PropertyDetail = "abcdefghijklmnopqrstuvwxyz";
                Obj.PropertyCity = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);

                Obj.PropertyDetail = "Property";
                Obj.PropertyCity = "Pune";
                Obj.PropertyCategory = "Flat";
                Obj.Id = 0;
                Obj.AvailableDate = DateTime.Now;
                Obj.ContactMobileNo = "123456789";
                var RegularExpressionValidations = new Dictionary<string, string>
                {
                    { "ContactMobileNo", "Please enter 10 digit mobile number" }
                };

                Results = ValidateModel(Obj);
                TestValidations("RegularExpression", RegularExpressionValidations, Results);
            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"Property entity doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(5)]
        public void Search_Validation_PostRequestTest()
        {
            try
            {
                var Obj = new SearchPropertyViewModel
                {                 
                    PropertyCategory = null,
                    PropertyCity = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "PropertyCategory", "Please provide property category to search" },
                    { "PropertyCity", "Please provide city name to search" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "PropertyCity", "City name must not exceed 25 characters" }
                };

               
                Obj.PropertyCity = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);


            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"SearchPropertyViewModel doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(6)]
        public void Search_ValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchPropertyViewModel) });
                var Obj = new SearchPropertyViewModel
                {
                    PropertyCity = "Kochi",
                    PropertyCategory = "abcde"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchPropertyViewModel;
                Assert.IsNotNull(model.Properties, $"{methodName} httppost action of {typeName} doesnot assigns Properties property of SearchPropertyViewModel for valid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(7)]
        public void Search_InValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchPropertyViewModel) });
                var Obj = new SearchPropertyViewModel
                {
                    PropertyCity = "Xyz",
                    PropertyCategory = "abcde"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchPropertyViewModel;
                Assert.AreEqual(0, model.Properties.Count, $"{methodName} httppost action of {typeName} assigns Properties property of SearchPropertyViewModel for invalid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        private IList<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, validationResults, true);

            return validationResults;
        }
    }


}
