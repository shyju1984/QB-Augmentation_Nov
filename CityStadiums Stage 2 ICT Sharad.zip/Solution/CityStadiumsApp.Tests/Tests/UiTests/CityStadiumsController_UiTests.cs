﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using CityStadiumsApp.Models;
using CityStadiumsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace CityStadiumsApp.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    public class CityStadiumsController_UiTests
    {
        private readonly string appURL;
        private IWebDriver driver;

        public CityStadiumsController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }


        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Add", title, $"Application doesnot start with the page titled Add");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(2)]
        public void AddStadium_SearchStadium_NavigationLinksTest()
        {
            try
            {
                driver.ClickElement("lnkSearch");
                string SearchPageTitle = driver.Title;

                driver.ClickElement("lnkAdd");
               
                string AddPageTitle = driver.Title;


                StringAssert.Contains("Add", AddPageTitle, $"Application doesnot navigates to Add page on clicking Add Stadium hyperlink");

                StringAssert.Contains("Search", SearchPageTitle, $"Application doesnot navigates to Search page on clicking Search Stadium hyperlink");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Add Stadium and Search stadium navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }


        [Test, Order(3)]
        [Rollback]
        public void AddStadium_Test()
        {
            try
            {
                var ExpectedSuccessMessage = "Stadium details added successfully";
                var ExpectedFailureMessage = "Failed to add stadium details. Try again later";
                driver.ClickElement("lnkAdd");
                
                var Element = driver.FindElement(By.Id("StadiumCategory"));
                Assert.IsNotNull(Element, $"Add Stadiums page doesn't displays the dropdown list for Stadium Category types");
                var DropDown = new SelectElement(Element);
               
                var StadiumCategories = new List<string> { "Select Stadium Category", "Cricket", "Football", "Hockey", "Swimming", "Athletics", "Indoor", "ShootingRange", "MultiPurpose" };
                foreach (var group in StadiumCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"StadiumCategories dropdown doesn't contains the value {group}");
                }
                string MobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8);
                driver.SetElementText("StadiumName", "Jojo Jose");
                driver.SetElementText("StartDate", DateTime.Now.Date.ToShortDateString());
                driver.SetElementText("ContactMobileNo", MobileNo);
                driver.SetElementText("City", "Delhi");
                driver.SelectDropDownItemByText("StadiumCategory", "Hockey");

                driver.ClickElement("btnSubmit");
               
                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Add stadium page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid stadium object");

                driver.ClickElement("btnSubmit");
                
                ActualMessage= driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedFailureMessage, ActualMessage, $"Add stadium page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag on trying to save a duplicate stadium object");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save stadium details from Add Stadium page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        public void SearchStadium_Test()
        {
            try
            {
                var WelcomeMessage = "Provide the search criteria to start looking for a stadium";
                var notFound = "No stadium found with the given search criteria";
                driver.ClickElement("lnkSearch");             
             

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(WelcomeMessage, ActualMessage, $"Search stadium page doesnot displays the message - '{WelcomeMessage}' in h2 tag on opening the page");

                var Element = driver.FindElement(By.Id("StadiumCategory"));
                Assert.IsNotNull(Element, $"Search Stadiums page doesn't displays the dropdown list for Stadium Category types");
                var DropDown = new SelectElement(Element);

                var StadiumCategories = new List<string> {"Select Stadium Category", "Cricket", "Football", "Hockey", "Swimming", "Athletics", "Indoor", "ShootingRange", "MultiPurpose" };
                foreach (var group in StadiumCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"StadiumCategories dropdown doesn't contains the value {group}");
                }

                
                driver.SetElementText("City", "Test City");
                driver.SelectDropDownItemByText("StadiumCategory", "Hockey");
                driver.ClickElement("btnSubmit");

                ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(notFound, ActualMessage, $"Search stadium page doesnot displays the message - '{notFound}' in h2 tag when there are no Stadiums for given search criteria");

                driver.SetElementText("City", "Delhi");
                driver.SelectDropDownItemByText("StadiumCategory", "Hockey");
                driver.ClickElement("btnSubmit");

                var context = new CityStadiumsContext();
                var counts = context.Stadiums.Count(d => d.City.ToLower() == "delhi" && d.StadiumCategory == "hockey");

                var TableRowCount = driver.GetTableRowsCount("tblStadiums") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search stadium page doesnot includes all the records in tblStadiums html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search stadium details from Search Stadium page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(5)]
        public void Index_Test()
        {
            try
            {
                driver.ClickElement("lnkIndex");

                var context = new CityStadiumsContext();                
                var counts = context.Stadiums.Count();

                var TableRowCount = driver.GetTableRowsCount("tblStadiums") - 1;
                Assert.AreEqual(counts, TableRowCount, $"Search stadium page doesnot includes all the records in tblStadiums html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search stadium details from Search Stadium page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
