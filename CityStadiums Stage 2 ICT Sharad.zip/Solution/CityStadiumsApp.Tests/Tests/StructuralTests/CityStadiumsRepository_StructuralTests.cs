﻿using NUnit.Framework;
using CityStadiumsApp.Models;
using CityStadiumsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CityStadiumsApp.StructuralTests
{     
     [Order(4), TestFixture("CityStadiumsApp", "CityStadiumsApp.Models", "CityStadiumsRepository")]
    public class CityStadiumsRepository_StructuralTests : TestBase
    {
        public CityStadiumsRepository_StructuralTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("context", "CityStadiumsContext");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "context", fieldType: "CityStadiumsContext"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "context"));
            }
        }

        [Test]
        public void AddStadium_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddStadium", new Type[] { typeof(CityStadiums) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddStadium() which accepts Stadium entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddStadium() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(string), typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search() method which accepts 2  string parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void ListStadiums_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("ListStadiums", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines ListStadiums() method which accepts no parameters");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check ListStadiums() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
