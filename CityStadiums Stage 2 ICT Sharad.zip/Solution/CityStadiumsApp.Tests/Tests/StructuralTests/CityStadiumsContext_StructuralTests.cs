﻿using NUnit.Framework;
using CityStadiumsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CityStadiumsApp.StructuralTests
{
    
    [Order(2), TestFixture("CityStadiumsApp", "CityStadiumsApp.Models", "CityStadiumsContext")]
    public class CityStadiumsContext_StructuralTests : TestBase
    {
        public CityStadiumsContext_StructuralTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void DbSet_Property_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("Stadiums", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("Stadiums", "DbSet<Stadium>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "Stadiums"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} doesnot inherits from DbContext base class");
        }
    }
}
