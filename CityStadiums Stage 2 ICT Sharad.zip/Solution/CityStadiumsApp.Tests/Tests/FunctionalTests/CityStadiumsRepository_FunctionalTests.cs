﻿using NUnit.Framework;
using CityStadiumsApp.Models;
using CityStadiumsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CityStadiumsApp.FunctionalTests
{
    [Order(6), TestFixture("CityStadiumsApp", "CityStadiumsApp.Models", "CityStadiumsRepository")]
    class CityStadiumsRepository_FunctionalTests : TestBase
    {
        public CityStadiumsRepository_FunctionalTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        public void AddStadium_Test()
        {
            string MethodName = "AddStadium";
            try
            {
                var Obj = new CityStadiums
                {
                    StadiumName = "Stadium",
                    StadiumCategory = "Hockey",
                    StartDate = DateTime.Now,
                    City = "Kochi",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.IsTrue(Result, $"{MethodName} method of class {typeName} doesnot returns true on saving the data");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(2)]
        public void Add_DuplicateStadium_Test()
        {
            string MethodName = "AddStadium";
            try
            {
                var Context = new CityStadiumsContext();

                var Obj = Context.Stadiums.First();
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.False(Result, $"{MethodName} method of class {typeName} doesnot returns false on trying to add a duplicate stadium");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(3)]
        public void Search_Test()
        {
            string MethodName = "Search";
            try
            {

                var Result = InvokeMethod<List<CityStadiums>>(MethodName, type, new object[] { "Delhi", "Hockey" });
                Assert.IsNotNull(Result, $"{MethodName} method of class {typeName} doesnot returns list of Stadiums saved in the database");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(4)]
        public void AddStadium_Search_Test()
        {
            string MethodName = "AddStadium";
            string MethodName1 = "Search";
            try
            {

                var CountBeforeAdd = InvokeMethod<List<CityStadiums>>(MethodName1, type, "Pune", "Hockey").Count;

                var Obj = new CityStadiums
                {
                    StadiumName = "Stadium",
                    StadiumCategory = "Hockey",
                    StartDate = DateTime.Now,
                    City = "Pune",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var AddResult = InvokeMethod<bool>(MethodName, type, Obj);

                var CountAfterAdd = InvokeMethod<List<CityStadiums>>(MethodName1, type, "Pune", "Hockey").Count;

                Assert.AreEqual(CountBeforeAdd + 1, CountAfterAdd, $"{MethodName} method of class {typeName} doesnot returns newly added records.");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName + " and " + MethodName1));
            }
        }

    }
}
