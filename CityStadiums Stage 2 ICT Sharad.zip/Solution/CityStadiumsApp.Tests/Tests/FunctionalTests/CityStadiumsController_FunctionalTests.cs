﻿using NUnit.Framework;
using CityStadiumsApp.Models;
using CityStadiumsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace CityStadiumsApp.FunctionalTests
{
    [Order(7), TestFixture("CityStadiumsApp", "CityStadiumsApp.Controllers", "CityStadiumsController")]
    public class CityStadiumsController_FunctionalTests : TestBase
    {
        public CityStadiumsController_FunctionalTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        [TestCase("Add")]
        [TestCase("Search")]
        [TestCase("Index")]
        public void GetRequestTest(string methodName)
        {
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { });

                var result = (ViewResult)method.Invoke(GetTypeInstance(), new Type[] { });
                Assert.IsNotNull(result, $"{methodName} httpget action method of class {typeName} doesnot returns a view.");

                Assert.IsNotNull(result.ViewBag.StadiumCategories, $"{methodName} http get action of {typeName} controller doesnot stores StadiumCategories in the ViewBag.StadiumCategories property");

                Assert.IsInstanceOf<SelectList>(result.ViewBag.StadiumCategories, $"{methodName} http get action of {typeName} controller doesnot stores a SelectList in ViewBag's StadiumCategories property");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(2)]
        public void Add_ValidStadium_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(CityStadiums) });
                var Obj = new CityStadiums
                {
                    StadiumName = "Stadium",
                    StadiumCategory = "Hockey",
                    StartDate = DateTime.Now,
                    City = "IndiaCity",
                    ContactMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on saving a valid stadium object.");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Stadium details added successfully", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Stadium details added successfully' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(3)]
        public void Add_DuplicateStadium_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(CityStadiums) });
                var context = new CityStadiumsContext();
                var Obj = context.Stadiums.First();
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on trying to save a duplicate stadium object");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Failed to add stadium details. Try again later", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Failed to add stadium details. Try again later' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(4)]
        public void Add_InvalidStadium_PostRequestTest()
        {
            try
            {
                var Obj = new CityStadiums
                {
                    StadiumName = null,
                    StadiumCategory = null,
                    StartDate = DateTime.Now,
                    City = null,
                    ContactMobileNo = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "StadiumName", "Please provide stadium name" },
                    { "StadiumCategory", "Please provide stadium category" },
                    { "ContactMobileNo", "Please provide mobile number" },
                    { "City", "Please provide city name" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "StadiumName", "Stadium name cannot exceed 25 characters" },
                    { "City", "City name must not exceed 25 characters" }
                };

                Obj.StadiumName = "abcdefghijklmnopqrstuvwxyz";
                Obj.City = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);

                Obj.StadiumName = "Stadium";
                Obj.City = "Pune";
                Obj.StadiumCategory = "Hockey";
                Obj.Id = 0;
                Obj.StartDate = DateTime.Now;
                Obj.ContactMobileNo = "123456789";
                var RegularExpressionValidations = new Dictionary<string, string>
                {
                    { "ContactMobileNo", "Please enter 10 digit mobile number" }
                };

                Results = ValidateModel(Obj);
                TestValidations("RegularExpression", RegularExpressionValidations, Results);
            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"Stadium entity doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(5)]
        public void Search_Validation_PostRequestTest()
        {
            try
            {
                var Obj = new SearchStadiumViewModel
                {                 
                    StadiumCategory = null,
                    City = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "StadiumCategory", "Please provide Stadium Category to search" },
                    { "City", "Please provide city name to search" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "City", "City name must not exceed 25 characters" }
                };

               
                Obj.City = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);


            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"SearchStadiumViewModel doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(6)]
        public void Search_ValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchStadiumViewModel) });
                var Obj = new SearchStadiumViewModel
                {
                    City = "Delhi",
                    StadiumCategory = "Hockey"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchStadiumViewModel;
                Assert.IsNotNull(model.Stadiums, $"{methodName} httppost action of {typeName} doesnot assigns Stadiums property of SearchStadiumViewModel for valid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(7)]
        public void Search_InValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchStadiumViewModel) });
                var Obj = new SearchStadiumViewModel
                {
                    City = "Xyz",
                    StadiumCategory = "abcde"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchStadiumViewModel;
                Assert.AreEqual(0, model.Stadiums.Count, $"{methodName} httppost action of {typeName} assigns Stadiums property of SearchStadiumViewModel for invalid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        private IList<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, validationResults, true);

            return validationResults;
        }
    }


}
