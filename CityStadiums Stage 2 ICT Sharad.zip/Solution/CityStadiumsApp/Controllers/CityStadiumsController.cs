﻿using CityStadiumsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CityStadiumsApp.Controllers
{
    public class CityStadiumsController : Controller
    {
        CityStadiumsRepository repository;
        static List<string> StadiumCategories = new List<string> 
        { "Cricket", "Football", "Hockey", "Swimming", "Athletics", "Indoor", "ShootingRange", "MultiPurpose"};
        public CityStadiumsController()
        {
            repository = new CityStadiumsRepository();
        }

        public ActionResult Index()
        {            
            var list = repository.ListStadiums();
            return View(list);
        }

        public ActionResult Add()
        {        
            ViewBag.StadiumCategories = new SelectList(StadiumCategories);
            return View();
        }

        [HttpPost]
        public ActionResult Add(CityStadiums stadium)
        {            
            ViewBag.StadiumCategories = new SelectList(StadiumCategories);

            if (!ModelState.IsValid)
                return View(stadium);
 
            var Added = repository.AddStadium(stadium);
            if (Added)
                ViewBag.Message = "Stadium details added successfully";
            else
                ViewBag.Message = "Failed to add stadium details. Try again later";

            return View(stadium);
        }

        public ActionResult Search()
        {            
            ViewBag.StadiumCategories = new SelectList(StadiumCategories);
            return View(new SearchStadiumViewModel());
        }

        [HttpPost]

        public ActionResult Search(SearchStadiumViewModel model)
        {
            ViewBag.StadiumCategories = new SelectList(StadiumCategories);

            if (!ModelState.IsValid)
                return View(model);

            model.Stadiums = repository.Search(model.City, model.StadiumCategory);
            return View(model);
        }
    }
}