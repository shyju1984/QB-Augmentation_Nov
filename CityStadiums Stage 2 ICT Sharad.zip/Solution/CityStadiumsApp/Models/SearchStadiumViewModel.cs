﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CityStadiumsApp.Models
{
    public class SearchStadiumViewModel
    {
        [Required(ErrorMessage = "Please provide city name to search")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")] 
        public string City { get; set; }

        [Required(ErrorMessage = "Please provide Stadium Category to search")]        
        public string StadiumCategory { get; set; }

        public List<CityStadiums> Stadiums { get; set; }
    }
}