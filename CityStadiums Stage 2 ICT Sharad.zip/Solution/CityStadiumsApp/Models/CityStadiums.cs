﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CityStadiumsApp.Models
{
    public class CityStadiums
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide stadium name")]
        [StringLength(25, ErrorMessage = "Stadium name cannot exceed 25 characters")]
        [Display(Name= "Stadium Name")]
        public string StadiumName { get; set; }

        [Required(ErrorMessage = "Please provide stadium category")]
        [StringLength(30)]
        [Display(Name ="Stadium Category")]
        public string StadiumCategory { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Please provide mobile number")]
        [RegularExpression("^[\\d]{10}$", ErrorMessage = "Please enter 10 digit mobile number")]
        [StringLength(10)]
        [Display(Name = "Contact Mobile No.")]
        public string ContactMobileNo { get; set; }

        [Required(ErrorMessage = "Please provide city name")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")]
        [Display(Name = "City")]
        public string City { get; set; }

    }
}