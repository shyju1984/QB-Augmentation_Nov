﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CityStadiumsApp.Models
{
    public class CityStadiumsRepository
    {
        CityStadiumsContext context;

        public CityStadiumsRepository()
        {
            context = new CityStadiumsContext();
        }

        public bool AddStadium(CityStadiums stadium)
        {
            bool IsAdded = false;

            var isPresent = context.Stadiums.SingleOrDefault(d => d.ContactMobileNo == stadium.ContactMobileNo
                                                        && d.City == stadium.City
                                                        && stadium.StadiumName == stadium.StadiumName);
            if (isPresent != null)
                return IsAdded;

            context.Stadiums.Add(stadium);
            IsAdded = context.SaveChanges() > 0;

            return IsAdded;
        }

        public List<CityStadiums> Search(string city, string category)
        {
            var StadiumsList = from stadium in context.Stadiums
                             where stadium.City.ToLower().Contains(city.ToLower())
                             && stadium.StadiumCategory.Equals(category)
                             select stadium;
            return StadiumsList.ToList();
        }

        public List<CityStadiums> ListStadiums()
        {
            var StadiumsList = from stadium in context.Stadiums
                                   select stadium;
            return StadiumsList.ToList();
        }
    }
}