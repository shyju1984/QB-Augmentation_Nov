﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace CityStadiumsApp.Models
{
    // Do not change the class name
    public class CityStadiums
    {
        // Implement the properties here

    }
}