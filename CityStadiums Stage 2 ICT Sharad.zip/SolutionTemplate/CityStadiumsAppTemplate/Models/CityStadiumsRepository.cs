﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace CityStadiumsApp.Models
{
    // Do not change the class name
    public class CityStadiumsRepository
    {
        // Create fields here

        public CityStadiumsRepository()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public bool AddStadium(CityStadiums stadium)
        {
            bool IsAdded = false;

            // Implement code here 

            return IsAdded;
        }

        // Do not change the method signature
        public List<CityStadiums> Search(string city, string category)
        {
            // Implement code here 
        }

        // Do not change the method signature
        public List<CityStadiums> ListStadiums()
        {
            // Implement code here 
        }
    }
}