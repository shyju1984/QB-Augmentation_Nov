﻿using CityStadiumsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

// Do not change the namespace
namespace CityStadiumsApp.Controllers
{
    // Do not change the class name
    public class CityStadiumsController : Controller
    {        
        CityStadiumsRepository repository;
        static List<string> StadiumCategories = new List<string>
        { "Cricket", "Football", "Hockey", "Swimming", "Athletics", "Indoor", "ShootingRange", "MultiPurpose"};

        public CityStadiumsController()
        {
            // Initialize fields here
        }
                
        public ActionResult Add()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Add(CityStadiums stadium)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Search()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Search(SearchStadiumViewModel model)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Index()
        {
            // Implement code here 
            return View();
        }

    }
}