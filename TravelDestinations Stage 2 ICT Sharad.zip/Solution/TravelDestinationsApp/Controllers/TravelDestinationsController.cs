﻿using TravelDestinationsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TravelDestinationsApp.Controllers
{
    public class TravelDestinationsController : Controller
    {
        TravelDestinationsRepository repository;
        static List<string> TravelCategories = new List<string> 
        { "WeekEnd", "Group", "Package", "Cruise", "Cultural", "Religious", "CollegeTour"};
        public TravelDestinationsController()
        {
            repository = new TravelDestinationsRepository();
        }

        public ActionResult Index()
        {            
            var list = repository.ListDestinations();
            return View(list);
        }

        public ActionResult Add()
        {        
            ViewBag.TravelCategories = new SelectList(TravelCategories);
            return View();
        }

        [HttpPost]
        public ActionResult Add(TravelDestinations destination)
        {            
            ViewBag.TravelCategories = new SelectList(TravelCategories);

            if (!ModelState.IsValid)
                return View(destination);
 
            var Added = repository.AddDestination(destination);
            if (Added)
                ViewBag.Message = "Destination details added successfully";
            else
                ViewBag.Message = "Failed to add destination details. Try again later";

            return View(destination);
        }

        public ActionResult Search()
        {            
            ViewBag.TravelCategories = new SelectList(TravelCategories);
            return View(new SearchDestinationViewModel());
        }

        [HttpPost]

        public ActionResult Search(SearchDestinationViewModel model)
        {
            ViewBag.TravelCategories = new SelectList(TravelCategories);

            if (!ModelState.IsValid)
                return View(model);

            model.Destinations = repository.Search(model.DestinationCity, model.TravelCategory);
            return View(model);
        }
    }
}