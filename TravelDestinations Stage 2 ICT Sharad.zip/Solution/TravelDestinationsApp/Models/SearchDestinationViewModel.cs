﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TravelDestinationsApp.Models
{
    public class SearchDestinationViewModel
    {
        [Required(ErrorMessage = "Please provide city name to search")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")] 
        public string DestinationCity { get; set; }

        [Required(ErrorMessage = "Please provide travel category to search")]        
        public string TravelCategory { get; set; }

        public List<TravelDestinations> Destinations { get; set; }
    }
}