﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TravelDestinationsApp.Models
{
    public class TravelDestinationsRepository
    {
        TravelDestinationsContext context;

        public TravelDestinationsRepository()
        {
            context = new TravelDestinationsContext();
        }

        public bool AddDestination(TravelDestinations destination)
        {
            bool IsAdded = false;

            var isDestinationPresent = context.Destinations.SingleOrDefault(d => d.BookingMobileNo == destination.BookingMobileNo
                                                        && d.DestinationCity == destination.DestinationCity
                                                        && destination.DestinationName == destination.DestinationName);
            if (isDestinationPresent != null)
                return IsAdded;

            context.Destinations.Add(destination);
            IsAdded = context.SaveChanges() > 0;

            return IsAdded;
        }

        public List<TravelDestinations> Search(string city, string travelCategory)
        {
            var DestinationsList = from destination in context.Destinations
                             where destination.DestinationCity.ToLower().Contains(city.ToLower())
                             && destination.TravelCategory.Equals(travelCategory)
                             select destination;
            return DestinationsList.ToList();
        }

        public List<TravelDestinations> ListDestinations()
        {
            var DestinationsList = from destination in context.Destinations
                                   select destination;
            return DestinationsList.ToList();
        }
    }
}