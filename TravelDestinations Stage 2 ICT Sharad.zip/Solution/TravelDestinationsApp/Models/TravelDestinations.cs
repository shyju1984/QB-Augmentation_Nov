﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TravelDestinationsApp.Models
{
    public class TravelDestinations
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide destination name")]
        [StringLength(25, ErrorMessage = "Destination name cannot exceed 25 characters")]
        [Display(Name= "Destination Name")]
        public string DestinationName { get; set; }

        [Required(ErrorMessage = "Please provide travel category")]
        [StringLength(30)]
        [Display(Name ="Travel Category")]
        public string TravelCategory { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Please provide mobile number")]
        [RegularExpression("^[\\d]{10}$", ErrorMessage = "Please enter 10 digit mobile number")]
        [StringLength(10)]
        [Display(Name = "Booking Mobile No.")]
        public string BookingMobileNo { get; set; }

        [Required(ErrorMessage = "Please provide city name")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")]
        [Display(Name = "Destination City")]
        public string DestinationCity { get; set; }

    }
}