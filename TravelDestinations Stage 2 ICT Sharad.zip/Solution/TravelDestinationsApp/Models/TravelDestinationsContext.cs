﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace TravelDestinationsApp.Models
{
    public class TravelDestinationsContext : DbContext
    {
        public TravelDestinationsContext() : base("TravelDestinationsConnection")
        {

        }

        public DbSet<TravelDestinations> Destinations { get; set; }
    }
}