﻿using NUnit.Framework;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelDestinationsApp.StructuralTests
{
    
    [Order(2), TestFixture("TravelDestinationsApp", "TravelDestinationsApp.Models", "TravelDestinationsContext")]
    public class TravelDestinationsContext_StructuralTests : TestBase
    {
        public TravelDestinationsContext_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void DbSet_Property_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("Destinations", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("Destinations", "DbSet<Destination>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "Destinations"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} doesnot inherits from DbContext base class");
        }
    }
}
