﻿using NUnit.Framework;
using TravelDestinationsApp.Models;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelDestinationsApp.StructuralTests
{
     
     [Order(4), TestFixture("TravelDestinationsApp", "TravelDestinationsApp.Models", "TravelDestinationsRepository")]
    public class DestinationRepository_StructuralTests : TestBase
    {
        public DestinationRepository_StructuralTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("context", "TravelDestinationsContext");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "context", fieldType: "TravelDestinationsContext"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "context"));
            }
        }

        [Test]
        public void AddDestinations_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddDestination", new Type[] { typeof(TravelDestinations) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddDestination() which accepts Destination entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddDestination() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(string), typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search() method which accepts 2  string parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void ListDestinations_Method_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("ListDestinations", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines ListDestinations() method which accepts no parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check ListDestinations() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
