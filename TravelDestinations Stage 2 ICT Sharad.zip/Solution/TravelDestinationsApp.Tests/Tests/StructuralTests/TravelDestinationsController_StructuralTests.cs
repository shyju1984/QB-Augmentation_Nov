﻿using NUnit.Framework;
using TravelDestinationsApp.Models;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace TravelDestinationsApp.StructuralTests
{
    [Order(5), TestFixture("TravelDestinationsApp", "TravelDestinationsApp.Controllers", "TravelDestinationsController")]
    public class DestinationsController_StructuralTests : TestBase
    {
        public DestinationsController_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void InheritsFrom_ControllerTest()
        {
            Assert.AreEqual("Controller", type.BaseType.Name, $"{base.type.Name} doesnot inherits from Controller base class");
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("repository", "TravelDestinationsRepository");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "repository", fieldType: "TravelDestinationsRepository"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "repository"));
            }
        }

        
        [Test]
        public void Add_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Add", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Add action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Add action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Add_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Add", new Type[] { typeof(TravelDestinations) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Add action method which accepts over object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Add action is not marked with attributes to run on http post request in {base.type.Name} controller");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Add action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(SearchDestinationViewModel) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search action method which accepts SearchDestinationViewModel object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Search action is not marked with attributes to run on http post request in {base.type.Name} controller");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Index_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Index", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Index action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Index action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

    }
}
