﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using TravelDestinationsApp.Models;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace TravelDestinationsApp.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    public class DestinationsController_UiTests
    {
        private readonly string appURL;
        private IWebDriver driver;

        public DestinationsController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }


        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Add", title, $"Application doesnot start with the page titled Add");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(2)]
        public void AddDestination_SearchDestination_NavigationLinksTest()
        {
            try
            {
                driver.ClickElement("lnkSearch");
                string SearchPageTitle = driver.Title;

                driver.ClickElement("lnkAdd");
               
                string AddPageTitle = driver.Title;


                StringAssert.Contains("Add", AddPageTitle, $"Application doesnot navigates to Add page on clicking Add Destination hyperlink");

                StringAssert.Contains("Search", SearchPageTitle, $"Application doesnot navigates to Search page on clicking Search Destination hyperlink");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Add Destination and Search destination navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }


        [Test, Order(3)]
        [Rollback]
        public void AddDestination_Test()
        {
            try
            {
                var ExpectedSuccessMessage = "Destination details added successfully";
                var ExpectedFailureMessage = "Failed to add destination details. Try again later";
                driver.ClickElement("lnkAdd");
                
                var Element = driver.FindElement(By.Id("TravelCategory"));
                Assert.IsNotNull(Element, $"Add Destinations page doesn't displays the dropdown list for travel category types");
                var DropDown = new SelectElement(Element);
               
                var TravelCategories = new List<string> { "Select Travel Category", "WeekEnd", "Group", "Package", "Cruise", "Cultural", "Religious", "CollegeTour" };
                foreach (var group in TravelCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"TravelCategories dropdown doesn't contains the value {group}");
                }
                string MobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8);
                driver.SetElementText("DestinationName", "Jojo Jose");
                driver.SetElementText("StartDate", DateTime.Now.Date.ToShortDateString());
                driver.SetElementText("BookingMobileNo", MobileNo);
                driver.SetElementText("DestinationCity", "Pune");
                driver.SelectDropDownItemByText("TravelCategory", "Cruise");

                driver.ClickElement("btnSubmit");
               
                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Add destination page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid destination object");

                driver.ClickElement("btnSubmit");
                
                ActualMessage= driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedFailureMessage, ActualMessage, $"Add destination page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag on trying to save a duplicate destination object");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save destination details from Add Destination page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        public void SearchDestination_Test()
        {
            try
            {
                var WelcomeMessage = "Provide the search criteria to start looking for a destination";
                var DestinationsNotFound = "No destination found with the given search criteria";
                driver.ClickElement("lnkSearch");             
             

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(WelcomeMessage, ActualMessage, $"Search destination page doesnot displays the message - '{WelcomeMessage}' in h2 tag on opening the page");

                var Element = driver.FindElement(By.Id("TravelCategory"));
                Assert.IsNotNull(Element, $"Search Destinations page doesn't displays the dropdown list for travel category types");
                var DropDown = new SelectElement(Element);

                var TravelCategories = new List<string> {"Select Travel Category", "WeekEnd", "Group", "Package", "Cruise", "Cultural", "Religious", "CollegeTour" };
                foreach (var group in TravelCategories)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"TravelCategories dropdown doesn't contains the value {group}");
                }

                
                driver.SetElementText("DestinationCity", "Test City");
                driver.SelectDropDownItemByText("TravelCategory", "Cruise");
                driver.ClickElement("btnSubmit");

                ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(DestinationsNotFound, ActualMessage, $"Search destination page doesnot displays the message - '{DestinationsNotFound}' in h2 tag when there are no Destinations for given search criteria");

                driver.SetElementText("DestinationCity", "Amritsar");
                driver.SelectDropDownItemByText("TravelCategory", "Religious");
                driver.ClickElement("btnSubmit");

                var context = new TravelDestinationsContext();
                var DestinationsCounts = context.Destinations.Count(d => d.DestinationCity.ToLower() == "amritsar" && d.TravelCategory == "religious");

                var TableRowCount = driver.GetTableRowsCount("tblDestinations") - 1;
                Assert.AreEqual(DestinationsCounts, TableRowCount, $"Search destination page doesnot includes all the records in tblDestinations html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search destination details from Search Destination page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(5)]
        public void Index_Test()
        {
            try
            {
                driver.ClickElement("lnkIndex");

                var context = new TravelDestinationsContext();                
                var DestinationsCounts = context.Destinations.Count();

                var TableRowCount = driver.GetTableRowsCount("tblDestinations") - 1;
                Assert.AreEqual(DestinationsCounts, TableRowCount, $"Search destination page doesnot includes all the records in tblDestinations html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search destination details from Search Destination page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
