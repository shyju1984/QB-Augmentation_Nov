﻿using NUnit.Framework;
using TravelDestinationsApp.Models;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;

namespace TravelDestinationsApp.FunctionalTests
{
    [Order(7), TestFixture("TravelDestinationsApp", "TravelDestinationsApp.Controllers", "TravelDestinationsController")]
    public class TravelDestinationsController_FunctionalTests : TestBase
    {
        public TravelDestinationsController_FunctionalTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        [TestCase("Add")]
        [TestCase("Search")]
        [TestCase("Index")]
        public void GetRequestTest(string methodName)
        {
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { });

                var result = (ViewResult)method.Invoke(GetTypeInstance(), new Type[] { });
                Assert.IsNotNull(result, $"{methodName} httpget action method of class {typeName} doesnot returns a view.");

                Assert.IsNotNull(result.ViewBag.TravelCategories, $"{methodName} http get action of {typeName} controller doesnot stores TravelCategories in the ViewBag.TravelCategories property");

                Assert.IsInstanceOf<SelectList>(result.ViewBag.TravelCategories, $"{methodName} http get action of {typeName} controller doesnot stores a SelectList in ViewBag's TravelCategories property");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(2)]
        public void Add_ValidDestination_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(TravelDestinations) });
                var Obj = new TravelDestinations
                {
                    DestinationName = "Destination",
                    TravelCategory = "Cruise",
                    StartDate = DateTime.Now,
                    DestinationCity = "IndiaCity",
                    BookingMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on saving a valid destination object.");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Destination details added successfully", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Destination details added successfully' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(3)]
        public void Add_DuplicateDestination_PostRequestTest()
        {
            string methodName = "Add";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(TravelDestinations) });
                var context = new TravelDestinationsContext();
                var Obj = context.Destinations.First();
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                Assert.IsNotNull(result, $"{methodName} httppost action method of class {typeName} doesnot returns a view on trying to save a duplicate destination object");
                Assert.IsNotNull(result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores a message in viewbag");
                Assert.AreEqual("Failed to add destination details. Try again later", result.ViewBag.Message, $"{methodName} httppost action method of class {typeName} doesnot stores the message 'Failed to add destination details. Try again later' in viewbag");
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(4)]
        public void Add_InvalidDestination_PostRequestTest()
        {
            try
            {
                var Obj = new TravelDestinations
                {
                    DestinationName = null,
                    TravelCategory = null,
                    StartDate = DateTime.Now,
                    DestinationCity = null,
                    BookingMobileNo = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "DestinationName", "Please provide destination name" },
                    { "TravelCategory", "Please provide travel category" },
                    { "BookingMobileNo", "Please provide mobile number" },
                    { "DestinationCity", "Please provide city name" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "DestinationName", "Destination name cannot exceed 25 characters" },
                    { "DestinationCity", "City name must not exceed 25 characters" }
                };

                Obj.DestinationName = "abcdefghijklmnopqrstuvwxyz";
                Obj.DestinationCity = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);

                Obj.DestinationName = "Destination";
                Obj.DestinationCity = "Pune";
                Obj.TravelCategory = "abcde";
                Obj.Id = 0;
                Obj.StartDate = DateTime.Now;
                Obj.BookingMobileNo = "123456789";
                var RegularExpressionValidations = new Dictionary<string, string>
                {
                    { "BookingMobileNo", "Please enter 10 digit mobile number" }
                };

                Results = ValidateModel(Obj);
                TestValidations("RegularExpression", RegularExpressionValidations, Results);
            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"Destination entity doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(5)]
        public void Search_Validation_PostRequestTest()
        {
            try
            {
                var Obj = new SearchDestinationViewModel
                {                 
                    TravelCategory = null,
                    DestinationCity = null
                };

                var RequiredValidations = new Dictionary<string, string>
                {
                    { "TravelCategory", "Please provide travel category to search" },
                    { "DestinationCity", "Please provide city name to search" }
                };

                var Results = ValidateModel(Obj);

                TestValidations("Required", RequiredValidations, Results);

                var StringLengthValidations = new Dictionary<string, string>
                {
                    { "DestinationCity", "City name must not exceed 25 characters" }
                };

               
                Obj.DestinationCity = "abcdefghijklmnopqrstuvwxyz";

                Results = ValidateModel(Obj);
                TestValidations("StringLength", StringLengthValidations, Results);


            }

            catch (Exception)
            {
                Assert.Fail("Exception should not be thrown here, verify the program logic");
            }

            void TestValidations(string validationName,
                                 Dictionary<string, string> RequiredValidations,
                                 IList<ValidationResult> Results)
            {
                bool IsInvalid = false;
                foreach (var item in RequiredValidations)
                {
                    IsInvalid = Results.Any(m => m.MemberNames.Contains(item.Key) && m.ErrorMessage.Contains(item.Value));
                    Assert.IsTrue(IsInvalid, $"SearchDestinationViewModel doesnot display the validation message {item.Value} for {validationName} validation failure for {item.Key} property");
                }


            }
        }

        [Test, Order(6)]
        public void Search_ValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchDestinationViewModel) });
                var Obj = new SearchDestinationViewModel
                {
                    DestinationCity = "Kochi",
                    TravelCategory = "abcde"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchDestinationViewModel;
                Assert.IsNotNull(model.Destinations, $"{methodName} httppost action of {typeName} doesnot assigns Destinations property of SearchDestinationViewModel for valid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        [Test, Order(7)]
        public void Search_InValidCriteria_Test()
        {
            string methodName = "Search";
            try
            {
                var method = base.type.GetMethod(methodName, new Type[] { typeof(SearchDestinationViewModel) });
                var Obj = new SearchDestinationViewModel
                {
                    DestinationCity = "Xyz",
                    TravelCategory = "abcde"

                };
                var result = method.Invoke(GetTypeInstance(), new object[] { Obj }) as ViewResult;
                var model = result.Model as SearchDestinationViewModel;
                Assert.AreEqual(0, model.Destinations.Count, $"{methodName} httppost action of {typeName} assigns Destinations property of SearchDestinationViewModel for invalid search criteria");


            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: methodName));
            }
        }

        private IList<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, validationResults, true);

            return validationResults;
        }
    }


}
