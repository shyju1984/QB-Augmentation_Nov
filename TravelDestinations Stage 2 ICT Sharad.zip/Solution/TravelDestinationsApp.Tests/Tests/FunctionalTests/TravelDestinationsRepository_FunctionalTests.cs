﻿using NUnit.Framework;
using TravelDestinationsApp.Models;
using TravelDestinationsApp.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelDestinationsApp.FunctionalTests
{
    [Order(6), TestFixture("TravelDestinationsApp", "TravelDestinationsApp.Models", "TravelDestinationsRepository")]
    class TravelDestinationsRepository_FunctionalTests : TestBase
    {
        public TravelDestinationsRepository_FunctionalTests(string assemblyName, string namespaceName, string typeName) 
            : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        public void AddDestination_Test()
        {
            string MethodName = "AddDestination";
            try
            {
                var Obj = new TravelDestinations
                {
                    DestinationName = "Destination",
                    TravelCategory = "abcde",
                    StartDate = DateTime.Now,
                    DestinationCity = "Kochi",
                    BookingMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.IsTrue(Result, $"{MethodName} method of class {typeName} doesnot returns true on saving the data");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(2)]
        public void Add_DuplicateDestination_Test()
        {
            string MethodName = "AddDestination";
            try
            {
                var Context = new TravelDestinationsContext();

                var Obj = Context.Destinations.First();
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.False(Result, $"{MethodName} method of class {typeName} doesnot returns false on trying to add a duplicate destination");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(3)]
        public void Search_Test()
        {
            string MethodName = "Search";
            try
            {

                var Result = InvokeMethod<List<TravelDestinations>>(MethodName, type, new object[] { "Kochi", "O+" });
                Assert.IsNotNull(Result, $"{MethodName} method of class {typeName} doesnot returns list of Destinations saved in the database");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(4)]
        public void AddDestination_Search_Test()
        {
            string MethodName = "AddDestination";
            string MethodName1 = "Search";
            try
            {

                var CountBeforeAdd = InvokeMethod<List<TravelDestinations>>(MethodName1, type, "Pune", "abcde").Count;

                var Obj = new TravelDestinations
                {
                    DestinationName = "Destination",
                    TravelCategory = "abcde",
                    StartDate = DateTime.Now,
                    DestinationCity = "Pune",
                    BookingMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var AddResult = InvokeMethod<bool>(MethodName, type, Obj);

                var CountAfterAdd = InvokeMethod<List<TravelDestinations>>(MethodName1, type, "Pune", "abcde").Count;

                Assert.AreEqual(CountBeforeAdd + 1, CountAfterAdd, $"{MethodName} method of class {typeName} doesnot returns newly added records.");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName + " and " + MethodName1));
            }
        }

    }
}
