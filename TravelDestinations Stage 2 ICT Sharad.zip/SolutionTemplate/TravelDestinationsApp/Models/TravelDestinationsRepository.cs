﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// Do not change the namespace
namespace TravelDestinationsApp.Models
{
    // Do not change the class name
    public class TravelDestinationsRepository
    {
        // Create fields here

        public TravelDestinationsRepository()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public bool AddDestination(TravelDestinations destination)
        {
            bool IsAdded = false;

            // Implement code here 

            return IsAdded;
        }

        // Do not change the method signature
        public List<TravelDestinations> Search(string city, string travelCategory)
        {
            // Implement code here 
        }

        // Do not change the method signature
        public List<TravelDestinations> ListDestinations()
        {
            // Implement code here 
        }
    }
}