﻿using TravelDestinationsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

// Do not change the namespace
namespace TravelDestinationsApp.Controllers
{
    // Do not change the class name
    public class TravelDestinationsController : Controller
    {
        // Create fields here

        public TravelDestinationsController()
        {
            // Initialize fields here
        }
                
        public ActionResult Add()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Add(TravelDestinations destination)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Search()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Search(SearchDestinationViewModel model)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Index()
        {
            // Implement code here 
            return View();
        }

    }
}