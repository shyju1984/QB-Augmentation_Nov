﻿using PlasmaDonorTracker.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PlasmaDonorTracker.Controllers
{
    public class DonorsController : Controller
    {
        DonorRepository repository;
        public DonorsController()
        {
            repository = new DonorRepository();
        }
        // GET: Donors
        public ActionResult Add()
        {
            var BloodGroups = new List<string> { "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" };
            ViewBag.BloodGroups = new SelectList(BloodGroups);

            return View();
        }

        [HttpPost]
        public ActionResult Add(Donor donor)
        {
            var BloodGroups = new List<string> { "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" };
            ViewBag.BloodGroups = new SelectList(BloodGroups);

            if (!ModelState.IsValid)
                return View(donor);
 
            var Added = repository.AddDonor(donor);
            if (Added)
                ViewBag.Message = "Donor details added successfully";
            else
                ViewBag.Message = "Failed to add donor details. Try again later";

            return View(donor);
        }

        public ActionResult Search()
        {
            var BloodGroups = new List<string> { "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" };
            ViewBag.BloodGroups = new SelectList(BloodGroups);
            return View(new SearchDonorViewModel());
        }

        [HttpPost]

        public ActionResult Search(SearchDonorViewModel model)
        {
            var BloodGroups = new List<string> { "A+", "A-", "B+", "B-", "O+", "O-", "AB", "AB+", "AB-" };
            ViewBag.BloodGroups = new SelectList(BloodGroups);

            if (!ModelState.IsValid)
                return View(model);

            model.Donors = repository.Search(model.DonorCity, model.BloodGroup);
            return View(model);
        }
    }
}