﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PlasmaDonorTracker.Models
{
    public class PlasmaBankContext : DbContext
    {
        public PlasmaBankContext() : base("PlasmaBankConnection")
        {

        }

        public DbSet<Donor> Donors { get; set; }
    }
}