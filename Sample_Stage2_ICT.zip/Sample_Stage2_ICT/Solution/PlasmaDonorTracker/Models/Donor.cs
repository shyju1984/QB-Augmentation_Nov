﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PlasmaDonorTracker.Models
{
    public class Donor
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide donor name")]
        [StringLength(25, ErrorMessage = "Donor name cannot exceed 25 characters")]
        [Display(Name="Donor Name")]
        public string DonorName { get; set; }

        [Required(ErrorMessage = "Please provide donor blood group")]
        [StringLength(3)]
        [Display(Name ="Blood Group")]
        public string BloodGroup { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Recovery Date")]
        public DateTime RecoveryDate { get; set; }

        [Required(ErrorMessage = "Please provide donor mobile number")]
        [RegularExpression("^[\\d]{10}$", ErrorMessage = "Please enter 10 digit mobile number")]
        [StringLength(10)]
        [Display(Name = "Donor Mobile No.")]
        public string DonorMobileNo { get; set; }

        [Required(ErrorMessage = "Please provide donor city name")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")]
        [Display(Name = "Donor City")]
        public string DonorCity { get; set; }

    }
}