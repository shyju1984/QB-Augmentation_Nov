﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PlasmaDonorTracker.Models
{
    public class SearchDonorViewModel
    {
        [Required(ErrorMessage = "Please provide city name to search")]
        [StringLength(25, ErrorMessage = "City name must not exceed 25 characters")] 
        public string DonorCity { get; set; }

        [Required(ErrorMessage = "Please provide blood group to search")]        
        public string BloodGroup { get; set; }

        public List<Donor> Donors { get; set; }
    }
}