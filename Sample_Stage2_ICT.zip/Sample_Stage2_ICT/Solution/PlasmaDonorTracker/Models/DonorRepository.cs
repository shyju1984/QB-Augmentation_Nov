﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PlasmaDonorTracker.Models
{
    public class DonorRepository
    {
        PlasmaBankContext context;

        public DonorRepository()
        {
            context = new PlasmaBankContext();
        }

        public bool AddDonor(Donor donor)
        {
            bool IsAdded = false;

            var isDonorPresent = context.Donors.SingleOrDefault(d => d.DonorMobileNo == donor.DonorMobileNo
                                                        && d.DonorCity == donor.DonorCity
                                                        && donor.DonorName == donor.DonorName);
            if (isDonorPresent != null)
                return IsAdded;

            context.Donors.Add(donor);
            IsAdded = context.SaveChanges() > 0;

            return IsAdded;
        }

        public List<Donor> Search(string city, string bloodgroup)
        {
            var DonorsList = from donor in context.Donors
                             where donor.DonorCity.ToLower().Contains(city.ToLower())
                             && donor.BloodGroup.Equals(bloodgroup)
                             select donor;
            return DonorsList.ToList();
        }
    }
}