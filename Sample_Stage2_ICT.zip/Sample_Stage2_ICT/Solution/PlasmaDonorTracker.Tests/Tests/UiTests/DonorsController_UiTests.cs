﻿using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using PlasmaDonorTracker.Models;
using PlasmaDonorTracker.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;

namespace PlasmaDonorTracker.UiTests
{
    public class RollbackAttribute : Attribute, ITestAction
    {
        private TransactionScope transaction;

        public void BeforeTest(ITest test)
        {
            transaction = new TransactionScope();
        }
        public void AfterTest(ITest test)
        {
            transaction.Dispose();
        }

        public ActionTargets Targets
        {
            get { return ActionTargets.Test; }
        }
    }
    [Order(8), TestFixture("http://localhost:4300/")]
    public class DonorsController_UiTests 
    {
        private readonly string appURL;
        private IWebDriver driver;

        public DonorsController_UiTests(string applicationURL)
        {
            this.appURL = applicationURL;

        }

        [OneTimeSetUp]
        public void Init()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(appURL);
        }

        [OneTimeTearDown]
        public void Destroy()
        {
            driver.Close();
            driver.Dispose();
        }


        [Test, Order(1)]
        public void StartPage_Test()
        {
            try
            {
                driver.Navigate().GoToUrl(appURL);
                string title = driver.Title;
                StringAssert.Contains("Add", title, $"Application doesnot start with the page titled Add");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing application start page title. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(2)]
        public void AddDonor_SearchDonor_NavigationLinksTest()
        {
            try
            {
                driver.ClickElement("lnkSearch");
                string SearchPageTitle = driver.Title;

                driver.ClickElement("lnkAdd");
               
                string AddPageTitle = driver.Title;


                StringAssert.Contains("Add", AddPageTitle, $"Application doesnot navigates to Add page on clicking Add Donor hyperlink");

                StringAssert.Contains("Search", SearchPageTitle, $"Application doesnot navigates to Search page on clicking Search Donor hyperlink");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while testing Add Donor and Search donor navigation links. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }


        [Test, Order(3)]
        [Rollback]
        public void AddDonor_Test()
        {
            try
            {
                var ExpectedSuccessMessage = "Donor details added successfully";
                var ExpectedFailureMessage = "Failed to add donor details. Try again later";
                driver.ClickElement("lnkAdd");
                
                var Element = driver.FindElement(By.Id("BloodGroup"));
                Assert.IsNotNull(Element, $"Add Donors page doesn't displays the dropdown list for blood group types");
                var DropDown = new SelectElement(Element);
               
                var BloodGroups = new List<string> { "Select Blood Group","A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" };
                foreach (var group in BloodGroups)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"BloodGroups dropdown doesn't contains the value {group}");
                }
                string MobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8);
                driver.SetElementText("DonorName", "Jojo Jose");
                driver.SetElementText("RecoveryDate", DateTime.Now.Date.ToShortDateString());
                driver.SetElementText("DonorMobileNo", MobileNo);
                driver.SetElementText("DonorCity", "Pune");
                driver.SelectDropDownItemByText("BloodGroup", "A+");

                driver.ClickElement("btnSubmit");
               
                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedSuccessMessage, ActualMessage, $"Add donor page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag after saving a valid donor object");

                driver.ClickElement("btnSubmit");
                
                ActualMessage= driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(ExpectedFailureMessage, ActualMessage, $"Add donor page doesnot displays the message - '{ExpectedSuccessMessage}' in h2 tag on trying to save a duplicate donor object");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to save donor details from Add Donor page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }

        [Test, Order(4)]
        public void SearchDonor_Test()
        {
            try
            {
                var WelcomeMessage = "Provide the search criteria to start looking for a donor";
                var DonorsNotFound = "No donor found with the given search criteria";
                driver.ClickElement("lnkSearch");             
             

                var ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(WelcomeMessage, ActualMessage, $"Search donor page doesnot displays the message - '{WelcomeMessage}' in h2 tag on opening the page");

                var Element = driver.FindElement(By.Id("BloodGroup"));
                Assert.IsNotNull(Element, $"Search Donors page doesn't displays the dropdown list for blood group types");
                var DropDown = new SelectElement(Element);

                var BloodGroups = new List<string> {"Select Blood Group","A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" };
                foreach (var group in BloodGroups)
                {
                    var Found = DropDown.Options.Any(option => option.Text == group);
                    Assert.IsTrue(Found, $"BloodGroups dropdown doesn't contains the value {group}");
                }

                
                driver.SetElementText("DonorCity", "Test City");
                driver.SelectDropDownItemByText("BloodGroup", "O+");
                driver.ClickElement("btnSubmit");

                ActualMessage = driver.GetElementInnerText("h2", "@Id='Message'");
                Assert.AreEqual(DonorsNotFound, ActualMessage, $"Search donor page doesnot displays the message - '{DonorsNotFound}' in h2 tag when there are no donors for given search criteria");

                driver.SetElementText("DonorCity", "Pune");
                driver.SelectDropDownItemByText("BloodGroup", "A+");
                driver.ClickElement("btnSubmit");

                var context = new PlasmaBankContext();
                var DonorsCounts = context.Donors.Count(d => d.DonorCity.ToLower() == "pune" && d.BloodGroup == "A+");

                var TableRowCount = driver.GetTableRowsCount("tblDonors") - 1;
                Assert.AreEqual(DonorsCounts, TableRowCount, $"Search donor page doesnot includes all the records in tblDonors html table for given criteria. Rows count mis-match between database and html table.");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception trying to search donor details from Search Donor page. \nException :\n{ex.InnerException?.Message}\nStack trace : \n{ex.InnerException?.StackTrace}");
            }
        }
    }
}
