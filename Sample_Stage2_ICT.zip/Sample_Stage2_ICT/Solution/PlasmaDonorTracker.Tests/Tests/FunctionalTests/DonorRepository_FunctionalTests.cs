﻿using NUnit.Framework;
using PlasmaDonorTracker.Models;
using PlasmaDonorTracker.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaDonorTracker.FunctionalTests
{
    [Order(6), TestFixture("PlasmaDonorTracker", "PlasmaDonorTracker.Models", "DonorRepository")]
    class DonorRepository_FunctionalTests : TestBase
    {
        public DonorRepository_FunctionalTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test, Order(1)]
        public void AddDonor_Test()
        {
            string MethodName = "AddDonor";
            try
            {
                var Obj = new Donor
                {
                    DonorName = "Jojo Jose",
                    BloodGroup = "O+",
                    RecoveryDate = DateTime.Now,
                    DonorCity = "Kochi",
                    DonorMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.IsTrue(Result, $"{MethodName} method of class {typeName} doesnot returns true on saving the data");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(2)]
        public void Add_DuplicateDonor_Test()
        {
            string MethodName = "AddDonor";
            try
            {
                var Context = new PlasmaBankContext();

                var Obj = Context.Donors.First();
                bool Result = InvokeMethod<bool>(MethodName, type, Obj);
                Assert.False(Result, $"{MethodName} method of class {typeName} doesnot returns false on trying to add a duplicate donor");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(3)]
        public void Search_Test()
        {
            string MethodName = "Search";
            try
            {

                var Result = InvokeMethod<List<Donor>>(MethodName, type, new object[] { "Kochi", "O+" });
                Assert.IsNotNull(Result, $"{MethodName} method of class {typeName} doesnot returns list of donors saved in the database");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName));
            }
        }

        [Test, Order(4)]
        public void AddDonor_Search_Test()
        {
            string MethodName = "AddDonor";
            string MethodName1 = "Search";
            try
            {

                var CountBeforeAdd = InvokeMethod<List<Donor>>(MethodName1, type, "Pune", "A+").Count;

                var Obj = new Donor
                {
                    DonorName = "Samuel",
                    BloodGroup = "A+",
                    RecoveryDate = DateTime.Now,
                    DonorCity = "Pune",
                    DonorMobileNo = DateTime.UtcNow.Ticks.ToString().Substring(8)
                };
                var AddResult = InvokeMethod<bool>(MethodName, type, Obj);

                var CountAfterAdd = InvokeMethod<List<Donor>>(MethodName1, type, "Pune", "A+").Count;

                Assert.AreEqual(CountBeforeAdd + 1, CountAfterAdd, $"{MethodName} method of class {typeName} doesnot returns newly added records.");

            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, methodName: MethodName + " and " + MethodName1));
            }
        }

    }
}
