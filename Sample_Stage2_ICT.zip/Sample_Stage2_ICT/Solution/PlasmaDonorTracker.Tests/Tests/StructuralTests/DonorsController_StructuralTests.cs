﻿using NUnit.Framework;
using PlasmaDonorTracker.Models;
using PlasmaDonorTracker.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace PlasmaDonorTracker.StructuralTests
{
    [Order(5), TestFixture("PlasmaDonorTracker", "PlasmaDonorTracker.Controllers", "DonorsController")]
    public class DonorsController_StructuralTests : TestBase
    {
        public DonorsController_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void InheritsFrom_ControllerTest()
        {
            Assert.AreEqual("Controller", type.BaseType.Name, $"{base.type.Name} doesnot inherits from Controller base class");
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("repository", "DonorRepository");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "repository", fieldType: "DonorRepository"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "repository"));
            }
        }

        [Test]
        public void Add_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Add", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Add action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Add action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Add_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Add", new Type[] { typeof(Donor) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Add action method which accepts over object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Add action is not marked with attributes to run on http post request in {base.type.Name} controller");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Add action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Get_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search action method");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void Search_Post_ActionCreated_Test()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(SearchDonorViewModel) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search action method which accepts SearchDonorViewModel object as parameter");
                var attr = Method.GetCustomAttribute<HttpPostAttribute>();
                Assert.IsNotNull(attr, $"Search action is not marked with attributes to run on http post request in {base.type.Name} controller");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search action method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
