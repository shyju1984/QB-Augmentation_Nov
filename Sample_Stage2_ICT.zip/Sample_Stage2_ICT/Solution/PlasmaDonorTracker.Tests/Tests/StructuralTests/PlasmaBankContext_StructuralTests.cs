﻿using NUnit.Framework;
using PlasmaDonorTracker.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaDonorTracker.StructuralTests
{
    
    [Order(2), TestFixture("PlasmaDonorTracker", "PlasmaDonorTracker.Models", "PlasmaBankContext")]
    public class PlasmaBankContext_StructuralTests : TestBase
    {
        public PlasmaBankContext_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void DbSet_Property_CreationTest()
        {
            try
            {
                var IsFound = HasProperty("Donors", "DbSet`1");
                Assert.IsTrue(IsFound,
                              Messages.GetPropertyNotFoundMessage("Donors", "DbSet<Donor>"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, propertyName: "Donors"));
            }
        }

        [Test]
        public void InheritsFrom_DbContextTest()
        {
            Assert.AreEqual("DbContext", type.BaseType.Name, $"{base.type.Name} doesnot inherits from DbContext base class");
        }
    }
}
