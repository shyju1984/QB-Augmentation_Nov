﻿using NUnit.Framework;
using PlasmaDonorTracker.Models;
using PlasmaDonorTracker.Tests.TestExtensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlasmaDonorTracker.StructuralTests
{
     
     [Order(4), TestFixture("PlasmaDonorTracker", "PlasmaDonorTracker.Models", "DonorRepository")]
    public class DonorRepository_StructuralTests : TestBase
    {
        public DonorRepository_StructuralTests(string assemblyName, string namespaceName, string typeName) : base(assemblyName, namespaceName, typeName)
        {
        }

        [Test]
        public void Field_CreationTest()
        {
            try
            {
                var IsFound = HasField("context", "PlasmaBankContext");
                Assert.IsTrue(IsFound,
                              Messages.GetFieldNotFoundMessage(fieldName: "context", fieldType: "PlasmaBankContext"));
            }
            catch (Exception ex)
            {
                Assert.Fail(Messages.GetExceptionMessage(ex, fieldName: "context"));
            }
        }

        [Test]
        public void AddOverDetailsMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("AddDonor", new Type[] { typeof(Donor) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines AddDonor() which accepts Donor entity object as parameter");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check AddDonor() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }

        [Test]
        public void GetOversReportMethod_CreationTest()
        {
            try
            {
                var Method = base.type.GetMethod("Search", new Type[] { typeof(string), typeof(string) });
                Assert.IsNotNull(Method, $"{base.type.Name} doesnot defines Search() method which accepts 2  string parameters");

            }
            catch (Exception ex)
            {
                Assert.Fail($"Exception while check Search() method is present or not in {base.type.Name}. \nException message : {ex.InnerException?.Message} \nStack trace : {ex.InnerException.StackTrace}");
            }
        }
    }
}
