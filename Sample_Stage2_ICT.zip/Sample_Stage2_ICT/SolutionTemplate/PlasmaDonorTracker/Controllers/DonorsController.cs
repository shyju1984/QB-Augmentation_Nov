﻿using PlasmaDonorTracker.Models;
using System.Collections.Generic;
using System.Web.Mvc;

// Do not change the namespace
namespace PlasmaDonorTracker.Controllers
{
    // Do not change the class name
    public class DonorsController : Controller
    {
        // Create fields here

        public DonorsController()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public ActionResult Add()
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        // Add attributes here
        public ActionResult Add(Donor donor)
        {
            // Implement code here 
            return View();
        }

        // Do not change the method signature
        public ActionResult Search()
        {
            // Implement code here 
            return View();
        }


        // Do not change the method signature
        // Add attributes here
        public ActionResult Search(SearchDonorViewModel model)
        {
            // Implement code here 
            return View();
        }
    }
}