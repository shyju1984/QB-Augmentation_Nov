﻿using System.Collections.Generic;
using System.Linq;

// Do not change the namespace
namespace PlasmaDonorTracker.Models
{
    // Do not change the class name
    public class DonorRepository
    {
        // Create fields here

        public DonorRepository()
        {
            // Initialize fields here
        }

        // Do not change the method signature
        public bool AddDonor(Donor donor)
        {
            bool IsAdded = false;

            // Implement code here 

            return IsAdded;
        }

        // Do not change the method signature
        public List<Donor> Search(string city, string bloodgroup)
        {
            List<Donor> Donors = new List<Donor>();

            // Implement code here 

            return Donors;
        }
    }
}