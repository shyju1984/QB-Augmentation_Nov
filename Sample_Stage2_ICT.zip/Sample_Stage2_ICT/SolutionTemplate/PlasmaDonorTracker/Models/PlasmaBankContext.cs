﻿using System.Data.Entity;

// Do not change the namespace
namespace PlasmaDonorTracker.Models
{
    // Do not change the class name
    public class PlasmaBankContext 
    {
        // Implement the code here
    }
}