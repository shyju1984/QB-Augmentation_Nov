﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

// Do not change the namespace
namespace PlasmaDonorTracker.Models
{
    // Do not change the class name
    public class SearchDonorViewModel
    {
       // Implement the properties here
    }
}