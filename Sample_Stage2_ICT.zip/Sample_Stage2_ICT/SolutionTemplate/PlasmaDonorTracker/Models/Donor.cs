﻿using System;
using System.ComponentModel.DataAnnotations;

// Do not change the namespace
namespace PlasmaDonorTracker.Models
{
    // Do not change the class name
    public class Donor
    {
       // Implement the properties here
    }
}